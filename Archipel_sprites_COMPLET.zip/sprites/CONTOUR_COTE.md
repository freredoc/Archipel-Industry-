# Contour de cote + falaises sud (semi top-down)

## Couche 1 — ecume (overlays sur la tuile MER, generiques toutes iles)
25 pieces. L'ecume pointe vers la terre.
- ligne (n/e/s/w) : 1 bord terre
- coin (ne/se/sw/nw) : coin convexe (1 coin terre diagonal)
- L (ne/se/sw/nw) : crique / coin concave (2 bords adjacents)
- U (n/e/s/w) : crique 3 bords (cote nomme = ouverture eau)
- dcoin (n/e/s/w) : 2 coins convexes adjacents
- **ligne_ns / ligne_ew** : chenal (2 bords opposes)
- **dcoin_ne_sw / dcoin_nw_se** : 2 coins convexes diagonaux
- **lac** : lac 1 tuile (4 bords terre)

## Couche 2 - falaise (semi top-down, relief 3 faces)
Posee PAR-DESSUS l'ecume. SUD pleine (~10px), EST/OUEST plus fines (~6px), NORD rien.
- falaise_s : face sud pleine - terre N
- falaise_w / falaise_e : faces laterales (terre a l O / a l E)
- falaise_coin_se / falaise_coin_sw : coins convexes BAS, fondent 10px(sud)->6px(lateral) en quart d ellipse - terre NO/NE diag
- falaise_coin_ne / falaise_coin_nw : coins HAUT, la falaise laterale s eteint en biseau vers la face nord
- falaise_crique_se / falaise_crique_sw : criques (angles concaves) sud+ouest / sud+est - terre N+O / N+E
- falaise_s_ew : falaise sud 1 tuile

## Auto-placement falaise (par tuile mer), dans l ordre
N=terre nord, E=terre est, O=terre ouest, S=terre sud (bords)
1. N+E+O           -> [falaise_U_s]            (cove sud : sud pleine + 2 murs, ecume sud ENTRE les murs)
2. N+O (sans E)    -> [crique_se]
3. N+E (sans O)    -> [crique_sw]
4. E+O (sans N)    -> 2 murs lateraux (chenal / U_n) : par mur, coin_ne/nw si sommet (pas de terre au-dessus du mur) sinon falaise_w/e
5. sinon, cumuler :
   - N            -> falaise_s
   - O            -> falaise_w (ou coin_ne si sommet de face et pas N)
   - E            -> falaise_e (ou coin_nw si sommet de face et pas N)
   - NO diag seul -> coin_se ;  NE diag seul -> coin_sw
Faces : SUD pleine (~10px, ecume epaisse), EST/OUEST fines (~6px), NORD aucune (fondu par coin_ne/nw).


L ecume des pieces de falaise est calee sur le contour (ligne/coin) -> continuite sans coupure.


## Auto-placement (par tuile mer)
1) Ecume : compter bords terre (n/e/s/w) -> ligne / L / U / lac / chenal ;
   sinon coins terre -> coin / dcoin (adjacent ou diagonal).
2) Falaise : si terre au nord, poser falaise_s[_e/_w/_ew] par-dessus
   (left = mer voisine ouest a terre au nord ; right = idem est).

Seules les faces SUD ont une falaise ; N/E/O gardent l'ecume (convention semi top-down).

## Transition cote <-> terre (triangles d'angle)
20 sprites (5 iles x 4 coins) : tile_iX_coast_tri_{ne,se,sw,nw}.
Triangle rectangle isocele = cote dans le coin nomme, terre normale sur le reste.
A poser sur la tuile d'angle INTERIEUR pour biseauter la frontiere cote/terre
(coin interieur NO -> tri_nw, NE -> tri_ne, etc.). Donne des angles coupes (octogone)
au lieu de coins carres.

## Falaises par ile
Chaque piece de falaise est declinee i1..i5 (ex: i3_falaise_s.png). La roche/terre est
teintee selon le climat de l'ile (ile3 plus chaude, iles4-5 plus froides) ; l'ecume reste claire/commune.

## Ecume animee (contour)
anim/coast_<piece>_anim.png : spritesheet 128x32, 4 frames, ~4 fps. Onde diagonale tres legere
(periode 16 px -> se raccorde parfaitement entre tuiles, boucle propre sur 4 frames).
A utiliser a la place des coast_<piece>.png statiques pour faire vivre le littoral.

## Overlays terrain (accidente / ressource / petrole)
overlay_obstacle.png, overlay_resource.png, overlay_petrole.png : sprites TRANSPARENTS 32x32.
A composer sur une base tile_iX_land OU tile_iX_coast (n'importe quelle ile) -> plus besoin de
tuiles cuites par ile. Les anciennes tile_iX_obstacle/resource/petrole sont depreciees.

## Ecume de base des falaises animee
anim/iX_falaise_<piece>_anim.png (5 iles x 11 pieces) : meme onde tres legere que le contour
(periode 16, 4 frames), appliquee uniquement a l'ecume ; la roche reste statique.

## Triangles de transition cote/terre ANIMES (brise)
anim/tile_iX_coast_tri_{ne,se,sw,nw}_breeze_sheet.png (5 iles x 4 coins, 128x32, 4 frames).
Version animee des triangles : la moitie cote et la moitie terre ondulent (meme brise que
tile_iX_{land,coast}_breeze). A utiliser a la place des tile_iX_coast_tri_* statiques quand la brise est active.
