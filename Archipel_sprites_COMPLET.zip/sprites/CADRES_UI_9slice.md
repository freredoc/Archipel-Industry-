# Cadres UI 9-slice

`ui_cadre_sobre_9slice.png` et `ui_cadre_rivets_9slice.png` — 17x17, **inset = 8px**
sur les 4 cotes (coins 8x8 fixes, 1px central etirable). 1 sprite = toutes les tailles.

Palette : bord `#0d0d1a`, bordure `#2a2a4a`, biseau `#3a3a6a` (haut/gauche),
ombre `#1c1c38` (bas/droite), fond `#15152a`, rivets `#f0d060`. Coins arrondis 1px.

## CSS (border-image)
```css
.panneau {
  border: 8px solid transparent;
  border-image: url('ui_cadre_sobre_9slice.png') 8 fill repeat;
  image-rendering: pixelated;   /* garder le pixel net */
}
```

## Canvas 2D (9-slice manuel)
Decouper la source en 9 zones avec inset=8 et les dessiner :
4 coins 8x8 a taille fixe, 4 bords (bande 1px) etires, centre (1px) etire.
Mettre ctx.imageSmoothingEnabled=false pour la nettete.

Astuce : pour un rendu pixel-perfect, etirer par multiples entiers du pixel source.

## Nouveaux cadres (17x17, inset 8 — même usage border-image / draw9slice)
- `ui_cadre_metal_9slice.png` : cadre MÉTALLIQUE à rivets dorés aux 4 angles (biseau acier
  clair haut-gauche / sombre bas-droite). Pour panneaux, menus, barres, onglet actif. Rivets `#e8c252`.
- `ui_cadre_bouton_9slice.png` : cadre SIMPLE sans rivets, en relief, surface `#262c46`.
  Pour les BOUTONS, à superposer par-dessus le panneau (même border-image `8 fill stretch`).
- `ui_cadre_inox_9slice.png` : variante MÉTALLIQUE inox gris (chromé), rivets aciers `#b8bcc4`.
  Même usage que `ui_cadre_metal` ; 2 styles métal au choix (bleuté / inox).

## Texture tôle larmée inox (fond de panneau)
`ui_tex_inox_larme.png` — 32×32, **tileable sans couture**. Fond métallique antidérapant (losanges en relief).
Usage : fond de panneau répété + bordure métallique 9-slice par-dessus. Pour voir la texture au
centre, utiliser le cadre **SANS `fill`** :
```css
.panneau-inox {
  background: url('ui_tex_inox_larme.png') repeat;
  image-rendering: pixelated;
  border: 8px solid transparent;
  border-image: url('ui_cadre_inox_9slice.png') 8 stretch;   /* pas de 'fill' -> centre transparent */
  padding: 10px;
}
```

## Boutons (4 états) & Onglets (actif/inactif)
9-slice 17x17 inset 8, mêmes règles border-image.
- `ui_bouton_normal_9slice.png` / `ui_bouton_survol_9slice.png` / `ui_bouton_enfonce_9slice.png` (biseau inversé) / `ui_bouton_desactive_9slice.png`
- `ui_onglet_actif_9slice.png` (accent or en haut) / `ui_onglet_inactif_9slice.png`
Logique : survol au pointeur, enfoncé au mousedown (+décaler le contenu 1px vers le bas), désactivé = pas de pointer-events.

## Fond brillant bleu (thème bleu)
`ui_tex_bleu_brillant.png` — 64×64 tileable, chrome poli bleu, sheen en diagonale. Fond de zone du
thème BLEU (équivalent de la tôle larmée pour l'inox). Combiner avec cadre `ui_cadre_metal` (sans fill).
Alternative CSS (plus lisse, un seul balayage par panneau, recommandée) :
```css
/* un seul reflet diagonal */
.zone-brillant {
  background: linear-gradient(135deg,#14182e 0%,#2a3a5e 30%,#aebfe0 48%,#d6e0f4 52%,#aebfe0 56%,#2a3a5e 74%,#14182e 100%);
}
/* OU bandes répétées facon brossé */
.zone-brillant-bandes {
  background: repeating-linear-gradient(135deg,#14182e 0px,#2a3a5e 30px,#c2ceea 50px,#2a3a5e 70px,#14182e 100px);
}
```
