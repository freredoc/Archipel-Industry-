#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rotation RIGIDE du disque entier (contour inclus) : rotation 90/180/270
sans perte + masque circulaire couvrant tout le rond. frame0 = statique."""
import numpy as np
from PIL import Image, ImageDraw
from anim_energie import load, to_arr, from_arr, mask_green, pulse, save_sheet

def spin_full_disc(img, cx, cy, r, angle):
    if angle % 360 == 0:
        return img
    box = (cx - r, cy - r, cx + r + 1, cy + r + 1)
    reg = img.crop(box)
    rot = reg.rotate(angle, resample=Image.NEAREST, center=(r, r), expand=False)
    mask = Image.new('L', reg.size, 0)
    ImageDraw.Draw(mask).ellipse([0, 0, 2 * r, 2 * r], fill=255)
    out = img.copy()
    out.paste(rot, box, mask)
    return out

def restamp_green(img, base):
    """Remet les pixels verts d'origine (glow central) par-dessus, pour qu'il
    reste fixe pendant que les tambours tournent."""
    a = to_arr(img); b = to_arr(base)
    m = mask_green(b)
    a[m] = b[m]
    return from_arr(a)

ANG = [0, 90, 180, 270]
GLOW = [1.0, 1.45, 1.15, 0.75]

def gen_broyeur(cle, src, green=False):
    base = load(src)
    drums = [(10, 10, 6), (21, 10, 6)]
    frames = []
    for i, ang in enumerate(ANG):
        f = base
        for (cx, cy, r) in drums:
            f = spin_full_disc(f, cx, cy, r, ang)
        if green:
            f = restamp_green(f, base)       # glow uranium reste central
            f = pulse(f, mask_green, GLOW[i])
        frames.append(f)
    return save_sheet(cle, frames)

def gen_fab():
    base = load('bat_fab_processeur')
    frames = [spin_full_disc(base, 12, 20, 8, a) for a in ANG]
    return save_sheet('fab_processeur', frames)

if __name__ == '__main__':
    gen_broyeur('broyeur', 'bat_broyeur')
    gen_broyeur('broyeur_uranium', 'bat_broyeur_uranium', green=True)
    gen_fab()
    print('OK')
