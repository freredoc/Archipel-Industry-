#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genere les spritesheets 4-frames pour la batch ENERGIE + NUCLEAIRE.
Methode: on part du PNG statique existant. frame 0 = sprite statique EXACT.
frames 1..3 = transformation d'une sous-region selon le type de mouvement.
Sheet horizontale = (W*4) x H. Fond transparent conserve."""
import os, math
import numpy as np
from PIL import Image, ImageDraw

SRC = 'sprites'
OUT = 'anim'
os.makedirs(OUT, exist_ok=True)

def load(name):
    return Image.open(os.path.join(SRC, name + '.png')).convert('RGBA')

def to_arr(img):
    return np.array(img, dtype=np.int16)

def from_arr(arr):
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), 'RGBA')

# ---------- masques couleur ----------
def mask_green(a):
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    return (al > 30) & (g > 120) & (g > r + 25) & (g > b + 25)

def mask_warm(a):
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    return (al > 30) & (r > 160) & (r >= g) & (g > b + 15)

def mask_cyan(a):
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    return (al > 30) & (b > 150) & (g > 110) & (r < 130)

# ---------- effets ----------
def pulse(img, mask_fn, factor):
    """Multiplie la luminosite des pixels masques par factor (clip 255)."""
    a = to_arr(img)
    m = mask_fn(a)
    for c in range(3):
        ch = a[..., c]
        ch[m] = np.clip(ch[m] * factor, 0, 255)
    return from_arr(a)

def spin_disc(img, cx, cy, r, angle):
    """Tourne un disque (masque cercle inscrit) autour de (cx,cy)."""
    if angle == 0:
        return img
    box = (cx - r, cy - r, cx + r, cy + r)
    reg = img.crop(box)
    rot = reg.rotate(angle, resample=Image.NEAREST, center=(r, r))
    mask = Image.new('L', reg.size, 0)
    ImageDraw.Draw(mask).ellipse([0, 0, 2 * r - 1, 2 * r - 1], fill=255)
    out = img.copy()
    out.paste(rot, box, mask)
    return out

def flicker_region(img, x0, y0, x1, y1, factor, dy=0):
    """Flamme/foyer: brille/baisse les pixels chauds d'une region + decalage vertical optionnel."""
    a = to_arr(img)
    sub = a[y0:y1, x0:x1]
    m = mask_warm(sub)
    for c in range(3):
        ch = sub[..., c]
        ch[m] = np.clip(ch[m] * factor, 0, 255)
    a[y0:y1, x0:x1] = sub
    img2 = from_arr(a)
    if dy != 0:
        # remonte les pixels chauds de la region de dy (jitter de flamme)
        a2 = to_arr(img2)
        sub = a2[y0:y1, x0:x1].copy()
        m = mask_warm(sub)
        ys, xs = np.where(m)
        for yy, xx in zip(ys, xs):
            ny = yy + dy
            if 0 <= ny < sub.shape[0]:
                a2[y0 + ny, x0 + xx] = sub[yy, xx]
        img2 = from_arr(a2)
    return img2

def add_puffs(img, puffs):
    """puffs = liste (x,y,alpha,size). Dessine des bouffees claires (vapeur/fumee)."""
    out = img.copy()
    d = ImageDraw.Draw(out)
    for (x, y, al, s) in puffs:
        col = (210, 214, 222, al)
        if s <= 1:
            out.putpixel((x, y), col)
        else:
            d.ellipse([x, y, x + s - 1, y + s - 1], fill=col)
    return out

def scroll_cyan_border(img, shift):
    """Decale les pixels cyan (LED en pointilles) horizontalement pour un effet de course."""
    if shift == 0:
        return img
    a = to_arr(img)
    m = mask_cyan(a)
    out = a.copy()
    ys, xs = np.where(m)
    # eteint (assombrit) puis rallume decale -> illusion de defilement
    for yy, xx in zip(ys, xs):
        out[yy, xx, :3] = np.clip(out[yy, xx, :3] * 0.45, 0, 255)
    for yy, xx in zip(ys, xs):
        nx = xx + shift
        # cherche le prochain pixel cyan voisin a +shift (sur la meme ligne) -> on rallume
        if 0 <= nx < a.shape[1] and m[yy, nx]:
            out[yy, nx, :3] = a[yy, xx, :3]
    return from_arr(out)

# ---------- montage sheet ----------
def build_sheet(frames):
    w, h = frames[0].size
    sheet = Image.new('RGBA', (w * len(frames), h), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        sheet.paste(f, (i * w, 0))
    return sheet

def save_sheet(name, frames):
    sheet = build_sheet(frames)
    path = os.path.join(OUT, name + '_sheet.png')
    sheet.save(path)
    print(f'  {name:26s} -> {sheet.size}')
    return path

# =====================================================================
#  DEFINITIONS PAR BATIMENT
# =====================================================================
GLOW = [1.0, 1.45, 1.15, 0.75]   # courbe de respiration (frame0 = 1.0)
GLOW2 = [1.0, 0.8, 1.3, 1.05]     # dephasee

def gen_refroidisseur():
    base = load('bat_refroidisseur')
    angles = [0, 30, 60, 90]      # ventilateur 4 pales -> 90deg = retour visuel
    fans = [(13, 16, 5), (20, 16, 5)]  # (cx,cy,r) approx
    frames = []
    for ang in angles:
        f = base
        for (cx, cy, r) in fans:
            f = spin_disc(f, cx, cy, r, ang)
        frames.append(f)
    return save_sheet('refroidisseur', frames)

def gen_broyeur_uranium():
    base = load('bat_broyeur_uranium')
    angles = [0, 40, 80, 120]
    drums = [(10, 10, 6), (20, 10, 6)]
    frames = []
    for i, ang in enumerate(angles):
        f = base
        for (cx, cy, r) in drums:
            f = spin_disc(f, cx, cy, r, ang)
        f = pulse(f, mask_green, GLOW[i])   # glow uranium qui respire
        frames.append(f)
    return save_sheet('broyeur_uranium', frames)

def gen_centrale_charbon():
    base = load('bat_centrale_charbon')
    facs = [1.0, 1.5, 1.1, 0.7]
    dys = [0, -1, 0, 0]
    # bouffees de fumee au sommet de cheminee (mouth ~ x23-26 y0-2)
    smoke = [
        [],
        [(24, 0, 120, 1), (23, 1, 90, 1)],
        [(25, 0, 150, 1), (24, 0, 90, 1)],
        [(23, 0, 110, 1), (25, 1, 80, 1)],
    ]
    frames = []
    for i in range(4):
        f = flicker_region(base, 4, 16, 11, 28, facs[i], dys[i])  # foyer
        f = add_puffs(f, smoke[i])
        frames.append(f)
    return save_sheet('centrale_charbon', frames)

def gen_centrale_diesel():
    base = load('bat_centrale_diesel')
    frames = []
    for i in range(4):
        f = pulse(base, mask_cyan, GLOW[i])           # diagnostics cyan
        f = pulse(f, mask_warm, GLOW2[i])             # echappement orange
        frames.append(f)
    return save_sheet('centrale_diesel', frames)

def gen_accumulateur():
    base = load('bat_accumulateur')
    # cycle de charge sigmoid: la barre verte + le "+" montent en intensite
    facs = [1.0, 1.2, 1.42, 1.42]
    frames = [pulse(base, mask_green, facs[i]) for i in range(4)]
    return save_sheet('accumulateur', frames)

def gen_centrale_enrichissement():
    base = load('bat_centrale_enrichissement')
    facs = [1.0, 1.4, 1.1, 0.8]
    frames = [pulse(base, mask_green, facs[i]) for i in range(4)]
    return save_sheet('centrale_enrichissement', frames)

def gen_usine_moteur_nucleaire():
    base = load('bat_usine_moteur_nucleaire')
    facs = [1.0, 1.5, 1.2, 0.8]
    shifts = [0, 1, 2, 3]
    frames = []
    for i in range(4):
        f = pulse(base, mask_green, facs[i])          # coeur vert pulse
        f = scroll_cyan_border(f, shifts[i])          # liseré cyan defile
        frames.append(f)
    return save_sheet('usine_moteur_nucleaire', frames)

def gen_centrale_nucleaire():
    base = load('bat_centrale_nucleaire')  # 64x64
    facs = [1.0, 1.35, 1.1, 0.8]
    # vapeur au sommet de la tour (~ x30-36, y2-12)
    steam = [
        [],
        [(31, 8, 110, 1), (33, 6, 90, 1), (32, 4, 60, 1)],
        [(32, 6, 130, 1), (34, 4, 90, 1), (31, 2, 60, 1)],
        [(30, 7, 100, 1), (33, 5, 80, 1), (35, 3, 55, 1)],
    ]
    frames = []
    for i in range(4):
        f = pulse(base, mask_green, facs[i])          # reacteur respire
        f = add_puffs(f, steam[i])
        frames.append(f)
    return save_sheet('centrale_nucleaire', frames)

if __name__ == '__main__':
    print('Generation batch energie + nucleaire :')
    gens = [gen_refroidisseur, gen_broyeur_uranium, gen_centrale_charbon,
            gen_centrale_diesel, gen_accumulateur, gen_centrale_enrichissement,
            gen_usine_moteur_nucleaire, gen_centrale_nucleaire]
    for g in gens:
        g()
    print('Termine.')
