#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Anime tous les batiments restants. Reutilise les helpers d'anim_energie.
frame 0 = sprite statique EXACT ; frames 1..3 = transformation de region."""
import os, math
import numpy as np
from PIL import Image, ImageDraw
from anim_energie import (load, to_arr, from_arr, mask_green, mask_warm, mask_cyan,
                          pulse, spin_disc, save_sheet)

# ---------- effets supplementaires ----------
def warm_flicker(img, factor, jitter_up=0):
    """Pulse tous les pixels chauds (flamme/foyer/coulee) + jitter vertical optionnel."""
    a = to_arr(img)
    m = mask_warm(a)
    for c in range(3):
        ch = a[..., c]; ch[m] = np.clip(ch[m] * factor, 0, 255)
    img2 = from_arr(a)
    if jitter_up:
        a2 = to_arr(img2); src = to_arr(img2); m2 = mask_warm(src)
        ys, xs = np.where(m2)
        for y, x in zip(ys, xs):
            ny = y - jitter_up
            if 0 <= ny < a2.shape[0]:
                a2[ny, x] = src[y, x]
        img2 = from_arr(a2)
    return img2

def cyan_flicker(img, factor):
    a = to_arr(img); m = mask_cyan(a)
    for c in range(3):
        ch = a[..., c]; ch[m] = np.clip(ch[m] * factor, 0, 255)
    return from_arr(a)

def water_shimmer(img, phase):
    a = to_arr(img); m = mask_cyan(a)
    ys, xs = np.where(m)
    for y, x in zip(ys, xs):
        f = 1.0 + 0.32 * math.sin((x + phase) * 0.9 + y * 0.4)
        a[y, x, :3] = np.clip(a[y, x, :3] * f, 0, 255)
    return from_arr(a)

def scan_band(img, x0, x1, y0, y1, col):
    """Bande de surbrillance verticale qui balaie une fenetre (pixels verts/clairs)."""
    a = to_arr(img)
    for x in (col, col + 1):
        if x0 <= x < x1:
            for y in range(y0, y1):
                px = a[y, x]
                if px[3] > 30 and (px[1] > 90 or (px[0] > 150 and px[1] > 150)):
                    a[y, x, :3] = np.clip(px[:3] * 1.6, 0, 255)
    return from_arr(a)

def rock(img, angle, cx, cy):
    if angle == 0: return img
    return img.rotate(angle, resample=Image.NEAREST, center=(cx, cy), expand=False)

def add_puffs(img, puffs):
    out = img.copy(); d = ImageDraw.Draw(out)
    for (x, y, al) in puffs:
        out.putpixel((x, y), (210, 214, 222, al))
    return out

GLOW = [1.0, 1.5, 1.15, 0.72]
GLOW_S = [1.0, 1.35, 1.1, 0.82]

# ============================ ROTATION ============================
def gen_broyeur():
    base = load('bat_broyeur'); angles = [0, 40, 80, 120]
    drums = [(10, 10, 6), (20, 10, 6)]
    frames = [base]
    for ang in angles[1:]:
        f = base
        for (cx, cy, r) in drums: f = spin_disc(f, cx, cy, r, ang)
        frames.append(f)
    return save_sheet('broyeur', frames)

def gen_usine_polymere():
    base = load('bat_usine_polymere'); angles = [0, 30, 60, 90]
    frames = []
    for i, ang in enumerate(angles):
        f = spin_disc(base, 24, 19, 4, ang)        # engrenage cyan
        if i: f = pulse(f, mask_warm, GLOW_S[i])   # billes orange convoyeur
        frames.append(f)
    return save_sheet('usine_polymere', frames)

def gen_fab_processeur():
    base = load('bat_fab_processeur'); angles = [0, 25, 50, 75]
    frames = [spin_disc(base, 12, 19, 7, a) for a in angles]   # wafer dore tourne
    return save_sheet('fab_processeur', frames)

# ============================ TORCHERES / FLAMMES ============================
def gen_raffinerie():
    base = load('bat_raffinerie'); facs = [1.0, 1.6, 1.1, 0.7]; ju = [0, 1, 0, 0]
    frames = [warm_flicker(base, facs[i], ju[i]) for i in range(4)]
    return save_sheet('raffinerie', frames)

def gen_puits_petrole():
    base = load('puits_petrole_v1'); facs = [1.0, 1.55, 1.1, 0.75]; ju = [0, 1, 0, 0]
    frames = [warm_flicker(base, facs[i], ju[i]) for i in range(4)]
    return save_sheet('puits_petrole_v1', frames)

def gen_plateforme():
    base = load('bat_plateforme_petroliere'); facs = [1.0, 1.6, 1.05, 0.7]
    frames = []
    for i in range(4):
        f = warm_flicker(base, facs[i], 1 if i == 1 else 0)
        f = pulse(f, mask_cyan, GLOW_S[i])
        frames.append(f)
    return save_sheet('plateforme_petroliere', frames)

# ============================ FOURS (glow fusion) ============================
def gen_glow(cle, src):
    base = load(src); facs = [1.0, 1.45, 1.15, 0.8]
    frames = [warm_flicker(base, facs[i]) for i in range(4)]
    return save_sheet(cle, frames)

# ============================ FOURS A ARC ============================
def gen_arc(cle, src):
    base = load(src); arc = [1.0, 1.7, 0.45, 1.35]; mol = [1.0, 1.3, 1.1, 0.85]
    frames = []
    for i in range(4):
        f = cyan_flicker(base, arc[i])     # arc electrique qui claque
        if i: f = warm_flicker(f, mol[i])  # bain en fusion
        frames.append(f)
    return save_sheet(cle, frames)

# ============================ COULEES / FONDERIES ============================
def gen_acierie():
    return gen_glow('acierie', 'bat_acierie')
def gen_fonderie_or():
    return gen_glow('fonderie_or', 'bat_fonderie_or')
def gen_raffineur_silicium():
    base = load('bat_raffineur_silicium'); facs = [1.0, 1.5, 1.15, 0.8]
    smoke = [[], [(11, 1, 110)], [(11, 0, 130), (12, 1, 80)], [(10, 1, 90)]]
    frames = [add_puffs(warm_flicker(base, facs[i]), smoke[i]) for i in range(4)]
    return save_sheet('raffineur_silicium', frames)

# ============================ CHIMIE ============================
def gen_distillerie():
    base = load('bat_distillerie'); facs = [1.0, 1.4, 1.1, 0.8]
    frames = []
    for i in range(4):
        f = warm_flicker(base, facs[i])        # alambic cuivre
        f = pulse(f, mask_green, GLOW_S[i])    # sortie verte
        frames.append(f)
    return save_sheet('distillerie', frames)

def gen_cablerie():
    base = load('bat_cablerie'); facs = [1.0, 1.45, 1.1, 0.78]
    frames = []
    for i in range(4):
        f = warm_flicker(base, facs[i])        # bobineuse orange chauffe
        f = pulse(f, mask_cyan, GLOW_S[i])
        frames.append(f)
    return save_sheet('cablerie', frames)

def gen_atelier_meca():
    base = load('bat_atelier_meca'); angles = [0, 30, 60, 90]
    frames = []
    for i, ang in enumerate(angles):
        f = spin_disc(base, 16, 18, 4, ang)    # rotule/engrenage du bras
        if i: f = pulse(f, mask_warm, GLOW_S[i])
        frames.append(f)
    return save_sheet('atelier_meca', frames)

# ============================ ELECTRONIQUE ============================
def gen_circuit():
    base = load('bat_circuit')
    cols = [None, 9, 16, 23]  # position du balayage
    frames = []
    for i in range(4):
        f = pulse(base, mask_green, [1.0, 1.25, 1.1, 1.2][i])
        if cols[i] is not None:
            f = scan_band(f, 5, 28, 8, 22, cols[i])
        frames.append(f)
    return save_sheet('circuit', frames)

# ============================ LIQUIDES ============================
def gen_pompe_eau():
    base = load('bat_pompe_eau'); phases = [None, 2, 5, 8]
    frames = [base if p is None else water_shimmer(base, p) for p in phases]
    return save_sheet('pompe_eau', frames)

def gen_bateau_cargo():
    base = load('bateau_cargo'); angles = [0, 2, 0, -2]
    frames = [rock(base, a, 16, 30) for a in angles]
    return save_sheet('bateau_cargo', frames)

# ============================ CARRIERES (scintillement minerai) ============================
def gen_carriere(cle, src):
    base = load(src); facs = [1.0, 1.4, 0.85, 1.2]
    frames = [warm_flicker(base, facs[i]) for i in range(4)]
    return save_sheet(cle, frames)

if __name__ == '__main__':
    print('Generation batch RESTE :')
    gen_broyeur(); gen_usine_polymere(); gen_fab_processeur()
    gen_raffinerie(); gen_puits_petrole(); gen_plateforme()
    gen_glow('four_fer_v1', 'four_fer_v1'); gen_glow('four_fer_v2', 'four_fer_v2')
    gen_glow('four_cuivre_v1', 'four_cuivre_v1'); gen_glow('four_cuivre_v2', 'four_cuivre_v2')
    gen_arc('four_arc_acier', 'four_arc_acier'); gen_arc('four_arc_cable', 'four_arc_cable')
    gen_arc('four_arc_meca', 'four_arc_meca')
    gen_acierie(); gen_fonderie_or(); gen_raffineur_silicium()
    gen_distillerie(); gen_cablerie(); gen_atelier_meca()
    gen_circuit(); gen_pompe_eau(); gen_bateau_cargo()
    gen_carriere('carriere_v1', 'carriere_v1'); gen_carriere('carriere_v2', 'carriere_v2')
    gen_carriere('carriere_v3', 'carriere_v3')
    print('Termine.')
