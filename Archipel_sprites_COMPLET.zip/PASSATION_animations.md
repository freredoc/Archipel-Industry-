# Passation — Session animations de sprites

## Livré
- **55 spritesheets 4-frames** au total (20 préexistantes : 2 éoliennes + 18 mines ;
  + nouvelles : énergie/nucléaire + reste du jeu). **Tous les bâtiments sont animés.**
- Cargo : **animation retirée** (manifest + pack).
- `sprites_manifest.json` section `animations` à jour (55) + `animations_manifest.csv`.
- Fichiers : `animations_pack_complet.zip`, `tuiles_brise_echantillon.zip`.

## Conventions (respectées sur tout)
- Sheet horizontale `W*4 x H`, lecture G→D en boucle.
- **frame 0 = sprite statique EXACT** (vérifié pixel-par-pixel sur chaque sheet).
- Fond transparent. Toutes dérivées des PNG statiques existants.
- 128x32 partout, sauf `centrale_nucleaire` = **256x64** (tuile 2x2).
- `fps_suggere` par anim dans le manifest (rotation ~8-10, glow ~6-7, brise ~2-4).

## Méthodes par type de mouvement
- **Rotation** (broyeur, broyeur_uranium, fab_processeur, usine_polymere…) :
  rotation RIGIDE du disque entier (rotate 90/180/270 sans perte + masque circulaire,
  rayon couvrant tout le rond). NE PAS ne tourner que l'intérieur (effet d'anneau fixe = bizarre).
  Uranium : glow vert central re-stampé fixe pendant que les tambours tournent.
- **Torchères / fours / coulées** : pulse des pixels chauds (warm mask) + jitter vertical.
- **Fours à arc** : flicker cyan (arc qui claque) + warm pulse (bain).
- **Glow nucléaire/élec** (réacteur, accumulateur, moteur, circuit) : pulse couleur (vert/cyan).
- **Vapeur/fumée** : petites bouffées claires ajoutées au-dessus (frame0 sans fumée).
- **Eau** (pompe_eau) : shimmer cyan en vague.

## Tuiles "brise" (échantillon, à valider)
- `tile_i1_land_breeze`, `tile_i1_water_breeze` : scintillement herbe/eau, 4 frames.
- **2px de bord identiques sur toutes les frames** → tiling sans couture quelle que soit
  la frame de chaque tuile. (Contrainte clé à conserver si on étend.)
- Intensité actuelle : herbe ±14%, eau ±22% (réglable).
- À étendre si validé : coast, petrole, îles 2-5.

## À FAIRE — intégration (session Opus, code du jeu)
1. Charger les sheets via le manifest ; mapper `cle_jeu` → sheet d'anim.
2. Jouer l'anim par bâtiment au `fps_suggere` ; gérer la nucléaire 256x64 (2x2).
3. Supprimer toute logique d'animation du cargo (sprite statique uniquement).
4. Tuiles brise : système de PHASE par tuile —
   `frame = (t + i + j) % 4` (bourrasque diagonale) ou phase aléatoire (scintillement),
   compteur `t` lent (~2-4 fps).

## Points faibles notés (validation mobile)
- `atelier_meca` (rotule seule), `betonniere` (tambour creux → pulse), `cablerie`
  (glow plutôt que rotation), `carrieres` (scintillement très discret).
