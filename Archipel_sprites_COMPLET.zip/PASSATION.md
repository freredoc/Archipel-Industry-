# PASSATION — Archipel Industry / sprites (fin de session)

## Où en est le travail
Le pack **`archipel_sprites_livraison.zip`** est complet et vérifié. Il contient
tout l'art du jeu + une police bitmap + des icônes d'état + 2 animations de démo.

### Contenu du ZIP
- `sprites/` — **349 PNG statiques** (fond transparent sauf terrains & port_terre)
  - 28 terrains (5 îles × 5 types + 2 port + tuile pétrole île 3)
  - 192 réseaux (route/tuyau/cable × 4 niveaux × 16 connexions, largeur réduite à 70%)
  - 24 jonctions (6 paires × 4 versions, hiérarchie fixe câble>route>tuyau)
  - ~40 fichiers bâtiments (mines, fours, usines, énergie, nucléaire…)
  - 29 items (16×16), 14 UI (16×16), 6 états (32×32)
- `anim/` — **20 spritesheets** (4 frames de 32px) : éolienne, éolienne_offshore, 18 mines
- `font/` (95→122 glyphes) + `font_sheet.png` + `font_manifest.json`
- `sprites_manifest.json` / `.csv` — catalogue (clé de jeu → fichier + métadonnées)
- `README.md`, `build_manifest.py`

### Conventions clés (rappel)
- Tuile = 32×32. Exception : centrale nucléaire = 64×64 (2×2).
- Réseaux : bitmask N=1 E=2 S=4 O=8, suffixe `_NN_XXXX`.
- Jonctions : tuyau toujours dessous, câble toujours dessus.
- Animations : spritesheet horizontale, frames de 32px, lire G→D, boucler ; frame 0 = sprite statique.
- Intégration single-file : inliner les PNG en base64 (sinon écran noir en file://).
- `cle_jeu` = nom xlsx normalisé (minuscules, underscores).

## Reste à faire (si on continue)
1. **Animer d'autres bâtiments** (le principe est validé sur éolienne + mines) :
   broyeurs (cylindres), centrifugeuses (enrichissement), bras robots (circuit/
   processeur/moteur), torchères (puits/raffinerie/plateforme), cœur nucléaire
   (pulse), eau (ondulation), bateau (tangage). Même méthode : ajouter un paramètre
   `frame` au script du bâtiment, sortir une spritesheet 128×32, ajouter au manifest
   section `animations`.
2. **Intégration dans le jeu** (autre session/Opus) : charger les sprites via le
   manifest, brancher l'animation par spritesheet, mapper `cle_jeu` aux bâtiments.

## Règles de travail (à garder)
- Sessions en français. Discuter d'abord, générer ensuite.
- Sprites dessinés pixel par pixel via Python/PIL (pas d'IA générative d'images).
- Fond transparent pour tout élément posé ; terrains & port_terre opaques.
- Contour strict 4-voisinage. Rendu jeu = Canvas, PNG = assets.
- Ne pas toucher au code du jeu sans demande explicite.

## Fichiers de travail
Scripts générateurs dans `/home/claude/*.py` (un par famille : mines2.py,
eolienne.py, route_*.py, tuyaux_v.py, cables_v.py, jonctions_v.py, items.py,
ui_icons.py, etats.py, font.py, climates_noborder.py, mines_anim.py, eolienne_anim.py…).
Le pack final est assemblé dans `/home/claude/livraison/` puis zippé.
