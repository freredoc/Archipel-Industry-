# Intégration UI complète — Archipel Industry (PROMPT MAÎTRE)

Habiller toute l'interface du jeu avec le kit UI du pack : cadres, boutons (4 états), onglets,
texture, icônes, police. **Rendu/UI uniquement, aucune logique de jeu.** Ce prompt remplace les
précédents prompts UI. Détails 9-slice dans `sprites/CADRES_UI_9slice.md`, liste dans `sprites_manifest.json`.

⚠️ Netteté partout : `image-rendering: pixelated;` (DOM) et `ctx.imageSmoothingEnabled=false` (Canvas).

---

## 0) Concept 9-slice (à comprendre absolument)

Il n'existe AUCUNE image de menu finie. Chaque cadre est un mini sprite **17×17, inset 8** qui
s'étire en n'importe quelle taille via CSS `border-image` : les 4 coins 8×8 restent fixes, les
bords (1px) et le centre (1px) s'étirent. **1 sprite = tous les panneaux/boutons/onglets, toutes tailles.**

```css
/* gabarit commun à TOUS les cadres ci-dessous */
.cadre {
  border: 8px solid transparent;
  border-image: url('<sprite>') 8 fill stretch;   /* 'fill' = peint le fond du sprite */
  image-rendering: pixelated;
  padding: 8px;                                    /* espace pour le contenu, en plus du cadre */
}
```
Ne JAMAIS utiliser `background-image` pour un cadre (ça déforme). Sans `fill` → centre transparent
(utile pour laisser voir une texture, voir §4).

---

## 1) Deux ambiances de menu (au choix)

| ambiance | panneaux | accent / barre / onglet actif | fond optionnel |
|----------|----------|-------------------------------|----------------|
| **Sobre** (d'origine) | `ui_cadre_sobre_9slice` | `ui_cadre_rivets_9slice` | — |
| **Métal / industriel** | `ui_cadre_metal_9slice` (bleuté) ou `ui_cadre_inox_9slice` (gris) | idem | `ui_tex_inox_larme` (tôle larmée) |

Choisis-en une par défaut (ou rends-la configurable). Les **boutons et onglets** ci-dessous sont
neutres et marchent dans les deux.

---

## 2) Boutons — 4 états (interactifs)

Tous 9-slice 17×17 inset 8. Un bouton = un cadre dont on **change la source selon l'état** :

| état | sprite | quand |
|------|--------|-------|
| normal   | `ui_bouton_normal_9slice`    | par défaut |
| survol   | `ui_bouton_survol_9slice`    | pointeur au-dessus (`:hover`) |
| enfoncé  | `ui_bouton_enfonce_9slice`   | bouton pressé (`:active` / mousedown) |
| désactivé| `ui_bouton_desactive_9slice` | action indisponible |

```css
.btn          { border:8px solid transparent; border-image:url('ui_bouton_normal_9slice.png') 8 fill stretch; image-rendering:pixelated; padding:6px 12px; cursor:pointer; color:#ebeef5; }
.btn:hover    { border-image:url('ui_bouton_survol_9slice.png') 8 fill stretch; }
.btn:active   { border-image:url('ui_bouton_enfonce_9slice.png') 8 fill stretch; }
.btn:active > * { transform: translateY(1px); }       /* le contenu s'enfonce de 1px */
.btn[disabled]{ border-image:url('ui_bouton_desactive_9slice.png') 8 fill stretch; cursor:default; pointer-events:none; color:#7c8090; }
```
Le contenu du bouton = icône 16×16 (`ui_*`) + libellé (police), centrés.

## 3) Onglets — actif / inactif

| état | sprite |
|------|--------|
| actif   | `ui_onglet_actif_9slice` (relief clair + **liseré or en haut**) |
| inactif | `ui_onglet_inactif_9slice` (sombre, en retrait) |

```css
.onglet         { border:8px solid transparent; border-image:url('ui_onglet_inactif_9slice.png') 8 fill stretch; image-rendering:pixelated; padding:5px 12px; cursor:pointer; color:#9aa2b0; }
.onglet--actif  { border-image:url('ui_onglet_actif_9slice.png') 8 fill stretch; color:#ebeef5; }
```
Onglet = icône 16×16 + libellé. L'onglet actif est celui de la vue affichée.

## 4) Texture tôle larmée inox (fond de panneau/contenu)

`ui_tex_inox_larme.png` — 32×32 **tileable**. Fond métallique répété + bordure métal **sans `fill`**
(sinon le cadre recouvre la texture) :

```css
.panneau-inox {
  background: url('ui_tex_inox_larme.png') repeat;
  image-rendering: pixelated;
  border: 8px solid transparent;
  border-image: url('ui_cadre_inox_9slice.png') 8 stretch;   /* PAS de 'fill' */
  padding: 10px;
}
```

## 5) Icônes & police (contenu des menus)

- **Icônes d'action 16×16** `ui_*` : dans onglets (batiment, route, cable, tuyau, port, recherche)
  et boutons (monter, baisser, configurer, deplacer, copier, demolir, info, pause, batterie).
- **Icônes de ressources 16×16** `item_*` : HUD, recettes, coûts, tooltips (icône avant le nombre).
- **Icônes d'état 32×32** `etat_*` : overlay de statut **sur le bâtiment au Canvas** selon l'état
  déjà calculé (route/tuyau/cable/intrant/courant/arret), une seule à la fois — `ctx.drawImage(img,bx,by,32,32)`.
- **Police bitmap 8×8** (déjà en @font-face) pour le texte d'UI. Couleur `#ebeef5`. Boutons : icône + libellé.

```css
.icon16 { width:16px; height:16px; image-rendering:pixelated; }
```

## 6) Palette

fond panneau `#15152a`, bord `#0d0d1a`, bordure `#2a2a4a`, accent/rivets/or `#f0d060`,
texte `#ebeef5`, texte désactivé `#7c8090`. (Variables CSS du jeu si présentes.)

---

## Checklist

- [ ] Charger : 5 cadres (`sobre, rivets, metal, inox, bouton`), 4 boutons (`normal/survol/enfonce/desactive`), 2 onglets (`actif/inactif`), texture `tex_inox_larme`, icônes `ui_*`/`item_*`/`etat_*`, police.
- [ ] Choisir une ambiance (sobre ou metal/inox) pour les panneaux/menus.
- [ ] Panneaux/menus/tooltips → cadre via `border-image 8 fill stretch` + padding (jamais `background-image`).
- [ ] Boutons → 4 états (hover/active/disabled), contenu enfoncé de 1px à l'état pressé, disabled = `pointer-events:none`.
- [ ] Onglets → actif/inactif, l'actif = vue courante.
- [ ] Panneau texturé → `background: url(tex_inox_larme) repeat` + cadre **sans `fill`**.
- [ ] Icônes 16×16 dans onglets/boutons/HUD ; états 32×32 sur les bâtiments (Canvas) ; police pour le texte.
- [ ] `image-rendering: pixelated` (DOM) + `imageSmoothingEnabled=false` (Canvas) partout.
- [ ] Aucune modif de la logique de jeu.

## Validation

Ouvrir le jeu : panneaux nets à toute taille, barre d'onglets avec un actif (liseré or) et des
inactifs, boutons qui s'éclaircissent au survol / s'enfoncent au clic / se grisent si indisponibles,
panneau tôle larmée si choisi, icônes et ressources affichées, bâtiments en défaut avec leur icône
d'état. Tout reste pixel-net au zoom.
