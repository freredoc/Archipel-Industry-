# Correction UI — passer en FULL INOX cohérent — Archipel Industry

L'intégration actuelle **mélange les styles** (fond tôle larmée gris clair + cartes restées bleu
foncé) → ça jure. À reprendre : **un seul thème inox gris, appliqué PARTOUT**, avec la tôle larmée
en version **légère/discrète**. Rendu/UI uniquement, aucune logique de jeu.

Sprites dans le pack (section `theme_inox` de `sprites_manifest.json`). Mécanisme 9-slice : voir
`sprites/CADRES_UI_9slice.md` (rappel plus bas).

---

## Ce qui ne va pas aujourd'hui (à corriger)

1. ❌ Les **cartes de bâtiment sont restées bleu foncé** sur un fond gris → incohérent.
   ✅ Toutes les cartes/panneaux passent en **inox gris** (mapping ci-dessous).
2. ❌ La **tôle larmée brillante** est mise en fond de tout le menu → trop chargé.
   ✅ Utiliser `ui_tex_inox_larme_leger` (contraste réduit), et seulement en **fond de zone**, texte clair par-dessus.
3. ❌ Les **titres de catégorie** (EXTRACTION, ÉNERGIE, ACTIONS) sont sombres → illisibles sur la larmée.
   ✅ Texte clair partout (`#ebeef5`), labels en gris clair (`#c8ccd2`).
4. ❌ Le style boutons n'est appliqué qu'en bas → **plein de contrôles non stylés**.
   ✅ **Tous** les boutons/onglets/cartes utilisent les sprites inox (y compris barre du haut, îles 1-5, cartes).

---

## Thème inox — mapping sprite → élément

| élément UI | sprite |
|------------|--------|
| panneau / carte / barre / tooltip | `ui_inox_panneau_9slice` (bord gris + fond gunmetal) |
| **carte de bâtiment** (= bouton) | `ui_bouton_inox_normal_9slice` (+ états) |
| bouton normal / survol / enfoncé / désactivé | `ui_bouton_inox_normal` / `_survol` / `_enfonce` / `_desactive` |
| onglet actif / inactif (Inventaire/Production, îles 1-5…) | `ui_onglet_inox_actif` (accent or) / `ui_onglet_inox_inactif` |
| fond de zone (menu construction, grands panneaux) | `ui_tex_inox_larme_leger` (répété, discret) |

Tout le reste du contenu = icônes 16×16 `ui_*` / `item_*` + texte (police bitmap), couleur `#ebeef5`.
Valeurs de ressources : garder les couleurs (vert/orange/rouge) sur le fond gris.

---

## Application

### Panneaux & barres (haut, inventaire, message, actions)
Chaque conteneur → cadre inox, fond plein gris :
```css
.panneau, .barre, .carte {
  border: 8px solid transparent;
  border-image: url('ui_inox_panneau_9slice.png') 8 fill stretch;
  image-rendering: pixelated; padding: 8px; color: #ebeef5;
}
```

### Zone construction → fond larmée légère + cartes-boutons
Le grand panneau du menu construction : fond larmée discret, **cadre sans `fill`** :
```css
.zone-construction {
  background: url('ui_tex_inox_larme_leger.png') repeat;
  image-rendering: pixelated;
  border: 8px solid transparent;
  border-image: url('ui_inox_panneau_9slice.png') 8 stretch;   /* pas de fill -> texture visible */
  padding: 10px;
}
.zone-construction .titre-categorie { color:#c8ccd2; }          /* labels clairs */
```
Chaque **carte de bâtiment = un bouton** (icône + nom + coût) :
```css
.carte-batiment        { border:8px solid transparent; border-image:url('ui_bouton_inox_normal_9slice.png') 8 fill stretch; image-rendering:pixelated; padding:8px; cursor:pointer; color:#ebeef5; }
.carte-batiment:hover  { border-image:url('ui_bouton_inox_survol_9slice.png') 8 fill stretch; }
.carte-batiment:active { border-image:url('ui_bouton_inox_enfonce_9slice.png') 8 fill stretch; }
.carte-batiment:active > * { transform:translateY(1px); }
.carte-batiment[disabled]{ border-image:url('ui_bouton_inox_desactive_9slice.png') 8 fill stretch; pointer-events:none; color:#7c8090; }
```

### Boutons d'action (Bâtiment, Réseau, Copier, Démolir, Améliorer) & onglets
Mêmes sprites boutons (4 états). Onglets (Inventaire/Production, îles 1-5) :
```css
.onglet        { border:8px solid transparent; border-image:url('ui_onglet_inox_inactif_9slice.png') 8 fill stretch; image-rendering:pixelated; padding:5px 10px; color:#9aa2b0; cursor:pointer; }
.onglet--actif { border-image:url('ui_onglet_inox_actif_9slice.png') 8 fill stretch; color:#ebeef5; }
```

---

## Rappel 9-slice (au cas où)
Cadre = sprite 17×17 inset 8 étiré par `border-image: url(...) 8 fill stretch` (les coins 8×8 fixes,
bords/centre étirés). `fill` peint le fond ; **sans** `fill` = centre transparent (pour laisser voir la larmée).
Jamais `background-image` pour un cadre. Toujours `image-rendering: pixelated`.

## Checklist
- [ ] Charger la section `theme_inox` (panneau, 4 boutons, 2 onglets, larmée légère).
- [ ] **Tous** les panneaux/barres/cartes → cadre inox (plus aucun panneau bleu foncé).
- [ ] Cartes de bâtiment = boutons (4 états + clic enfoncé 1px).
- [ ] Boutons d'action + onglets (haut compris, îles 1-5) → sprites inox.
- [ ] Fond menu construction = `ui_tex_inox_larme_leger` (discret) + cadre **sans fill**.
- [ ] Texte clair `#ebeef5`, labels catégorie `#c8ccd2` (lisibles sur larmée).
- [ ] `image-rendering: pixelated` partout ; aucune logique de jeu touchée.

## Validation
Tout l'écran est gris métallique cohérent (haut, inventaire, menu, actions), la tôle larmée est
discrète en fond du menu, les cartes réagissent au survol/clic, les labels sont lisibles, et il ne
reste **aucun panneau bleu** ni bouton non stylé.
