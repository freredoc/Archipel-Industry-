# Archipel Industry — paquet sprites COMPLET

## Contenu
- `sprites/`            349 PNG statiques (bâtiments, tuiles, items, réseaux, UI, badges…)
- `anim/`              57 spritesheets 4-frames : 55 animations de bâtiments/structures
                        + 2 tuiles "brise" (tile_i1_land_breeze, tile_i1_water_breeze)
- `font/`, `font_*`    police bitmap (122 glyphes) + sheet
- `sprites_manifest.json`   manifest principal — sections `animations` (55) et `tuiles_animees` (2) à jour
- `sprites_manifest.csv`    manifest statique (référence)
- `animations_manifest.csv` liste des animations + tuiles (cle, sheet, taille, fps, mouvement, type)
- `build_manifest.py`       script de (re)génération du manifest (origine)
- `_scripts/`               générateurs des animations (reproductibilité)
- `README_animations.md`    conventions + liste des animations
- `README_brise.md`         concept tuiles brise + intégration
- `PASSATION.md`            passation d'origine (sprites statiques)
- `PASSATION_animations.md` passation de la session animations (méthodes + to-do intégration)

## Conventions animations
Sheet horizontale W*4 x H, lecture G→D en boucle, **frame 0 = sprite statique exact**,
fond transparent. 128x32 partout sauf `centrale_nucleaire` = 256x64 (tuile 2x2).
Tuiles brise : 2px de bord identiques sur les 4 frames → tiling sans couture.

## Note
Cargo : sprite statique uniquement (animation retirée). Voir PASSATION_animations.md
pour la to-do d'intégration côté code (session Opus).
