#!/usr/bin/env python3
"""Construit le catalogue/manifest des sprites Archipel Industry.
Chaque entrée mappe une clé de jeu -> fichier PNG + métadonnées.
Le manifest sert de pont entre le xlsx (noms de bâtiments) et les fichiers."""
import os, json
from PIL import Image

SRC="/home/claude"
def size_of(f):
    try:
        with Image.open(os.path.join(SRC,f)) as im: return list(im.size)
    except: return None
def exists(f): return os.path.isfile(os.path.join(SRC,f))

manifest={
  "meta":{
     "projet":"Archipel Industry",
     "tuile_px":32,
     "format":"PNG RGBA, fond transparent (sauf tuiles terrain & port_terre opaques)",
     "convention_reseaux":"bitmask N=1 E=2 S=4 O=8 -> 16 variantes par niveau, fichier *_NN_XXXX.png",
     "hierarchie_jonctions":"recouvrement fixe cable > route > tuyau (tuyau toujours dessous, cable toujours dessus)",
     "note_integration":"rendu jeu = Canvas; ces PNG = assets/reference. Charger via base64 inline pour rester single-file autonome."
  },
  "terrains":[], "reseaux":{"route":[],"tuyau":[],"cable":[]}, "jonctions":[],
  "batiments":[], "items":[], "ui":[], "divers":[]
}

# ---------- TERRAINS (5 îles x 5 types + génériques) ----------
TERR_TYPES=["land","water","coast","resource","obstacle"]
for isle in range(1,6):
    for t in TERR_TYPES:
        f=f"tile_i{isle}_{t}.png"
        if exists(f):
            manifest["terrains"].append({"cle":f"terrain_i{isle}_{t}","ile":isle,"type":t,"fichier":f,"taille":size_of(f),"opaque":True})
# tuiles port
for f,cle in [("tile_port_mer.png","port_mer"),("tile_port_terre.png","port_terre")]:
    if exists(f):
        manifest["terrains"].append({"cle":cle,"type":"port","fichier":f,"taille":size_of(f),
                                     "opaque": cle=="port_terre"})

# ---------- RESEAUX route/tuyau/cable : 4 niveaux x 16 masques ----------
MASKS=["00_iso","01_N","02_E","03_NE","04_S","05_NS","06_ES","07_NES",
       "08_O","09_NO","10_EO","11_NEO","12_SO","13_NSO","14_ESO","15_NESO"]
for net in ["route","tuyau","cable"]:
    for v in range(1,5):
        for m in MASKS:
            f=f"{net}_v{v}_{m}.png"
            if exists(f):
                manifest["reseaux"][net].append({"cle":f"{net}_v{v}_{m}","niveau":v,"masque":m,"fichier":f})

# ---------- JONCTIONS : 6 paires x 4 versions (versionnées = définitives) ----------
PAIRS=[("route","cable"),("cable","route"),("route","tuyau"),
       ("tuyau","route"),("cable","tuyau"),("tuyau","cable")]
for (h,vt) in PAIRS:
    for v in range(1,5):
        f=f"jonction_{h}_{vt}_v{v}.png"
        if exists(f):
            manifest["jonctions"].append({"cle":f"jonction_{h}_{vt}_v{v}","horizontal":h,"vertical":vt,
                                          "niveau":v,"dessus":"cable" if "cable" in (h,vt) else "route","fichier":f})

# ---------- BATIMENTS ----------
# (cle_jeu = nom xlsx normalisé) -> liste de fichiers (avec niveaux si présents)
def add_bat(cle, fichiers, **extra):
    fichiers=[f for f in fichiers if exists(f)]
    if fichiers:
        e={"cle":cle,"fichiers":fichiers}; e.update(extra); manifest["batiments"].append(e)

# extracteurs
for ore in ["fer","cuivre","or","charbon","uranium","pierre"]:
    add_bat(f"mine_{ore}", [f"mine_{ore}_v{v}.png" for v in (1,2,3)], categorie="extraction", niveaux=[1,2,3])
add_bat("carriere", [f"carriere_v{v}.png" for v in (1,2,3)], categorie="extraction", niveaux=[1,2,3])
add_bat("puits_petrole", ["puits_petrole_v1.png"], categorie="extraction", niveaux=[1])
add_bat("plateforme_petroliere", ["bat_plateforme_petroliere.png"], categorie="extraction_offshore")
add_bat("pompe_eau", ["bat_pompe_eau.png"], categorie="extraction")
# fours / metallurgie
add_bat("four_fer", [f"four_fer_v{v}.png" for v in (1,2)], categorie="metallurgie", niveaux=[1,2])
add_bat("four_cuivre", [f"four_cuivre_v{v}.png" for v in (1,2)], categorie="metallurgie", niveaux=[1,2])
add_bat("four_arc_acier", ["four_arc_acier.png"], categorie="metallurgie")
add_bat("four_arc_cable", ["four_arc_cable.png"], categorie="metallurgie")
add_bat("four_arc_meca", ["four_arc_meca.png"], categorie="metallurgie", note="bâtiment futur (pièces méca)")
add_bat("acierie", ["bat_acierie.png"], categorie="metallurgie")
add_bat("cablerie", ["bat_cablerie.png"], categorie="metallurgie")
add_bat("fonderie_or", ["bat_fonderie_or.png"], categorie="metallurgie")
# transformation / chimie
add_bat("cimenterie", ["cimenterie.png"], categorie="materiaux")
add_bat("betonniere", ["betonniere.png"], categorie="materiaux")
add_bat("atelier_meca", ["bat_atelier_meca.png"], categorie="mecanique")
add_bat("raffinerie", ["bat_raffinerie.png"], categorie="chimie")
add_bat("distillerie", ["bat_distillerie.png"], categorie="chimie")
add_bat("usine_polymere", ["bat_usine_polymere.png"], categorie="chimie")
add_bat("broyeur", ["bat_broyeur.png"], categorie="transformation")
add_bat("broyeur_uranium", ["bat_broyeur_uranium.png"], categorie="nucleaire")
add_bat("raffineur_silicium", ["bat_raffineur_silicium.png"], categorie="electronique")
# electronique
add_bat("circuit", ["bat_circuit.png"], categorie="electronique")
add_bat("fab_processeur", ["bat_fab_processeur.png"], categorie="electronique")
# energie
add_bat("eolienne", ["eolienne.png"], categorie="energie")
add_bat("eolienne_offshore", ["eolienne_offshore.png"], categorie="energie")
add_bat("centrale_charbon", ["bat_centrale_charbon.png"], categorie="energie")
add_bat("centrale_diesel", ["bat_centrale_diesel.png"], categorie="energie")
add_bat("accumulateur", ["bat_accumulateur.png"], categorie="energie")
add_bat("centrale_enrichissement", ["bat_centrale_enrichissement.png"], categorie="nucleaire")
add_bat("centrale_nucleaire", ["bat_centrale_nucleaire.png"], categorie="nucleaire", taille_tuiles="2x2", note="64x64px")
add_bat("refroidisseur", ["bat_refroidisseur.png"], categorie="nucleaire")
add_bat("usine_moteur_nucleaire", ["bat_usine_moteur_nucleaire.png"], categorie="nucleaire")
add_bat("antenne", ["bat_antenne.png"], categorie="support")
# transport
add_bat("bateau_cargo", ["bateau_cargo.png"], categorie="transport", note="top-down, orienté Nord, rotable")

# enrichir bâtiments avec taille
for b in manifest["batiments"]:
    b["tailles"]=[size_of(f) for f in b["fichiers"]]

# ---------- ITEMS ----------
ITEM_KEYS=["minerai_fer","minerai_cuivre","minerai_or","charbon","uranium","pierre",
 "lingot_fer","lingot_cuivre","lingot_or","acier","silicium","silicium_raffine",
 "petrole","diesel","acide","polymere","eau","ciment","beton_arme","cable","circuit",
 "processeur","piece_meca","yellow_cake","combustible_u235","element_moteur",
 "acier_irradie","beton_arme_irradie","cable_irradie"]
for k in ITEM_KEYS:
    f=f"item_{k}.png"
    if exists(f):
        manifest["items"].append({"cle":k,"fichier":f,"taille":size_of(f),
                                  "irradie": k.endswith("_irradie")})

# ---------- UI ----------
UI_KEYS=["monter","baisser","demolir","info","deplacer","configurer","pause",
 "copier","route","cable","tuyau","recherche","port","batiment"]
for k in UI_KEYS:
    f=f"ui_{k}.png"
    if exists(f):
        manifest["ui"].append({"cle":k,"fichier":f,"taille":size_of(f)})

# ---------- écriture ----------
out="/home/claude/sprites_manifest.json"
with open(out,"w",encoding="utf-8") as fp:
    json.dump(manifest,fp,ensure_ascii=False,indent=2)

# résumé
print("Manifest écrit:",out)
print("Terrains:",len(manifest["terrains"]))
for net in manifest["reseaux"]: print(f"  Réseau {net}:",len(manifest["reseaux"][net]))
print("Jonctions:",len(manifest["jonctions"]))
print("Bâtiments:",len(manifest["batiments"]))
print("Items:",len(manifest["items"]))
print("UI:",len(manifest["ui"]))
total=(len(manifest["terrains"])+sum(len(v) for v in manifest["reseaux"].values())
       +len(manifest["jonctions"])+sum(len(b["fichiers"]) for b in manifest["batiments"])
       +len(manifest["items"])+len(manifest["ui"]))
print("TOTAL fichiers référencés:",total)
