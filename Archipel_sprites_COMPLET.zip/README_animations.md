# Animations Archipel Industry — pack complet

**56 spritesheets** au total (20 livrees precedemment : eoliennes + 18 mines ;
+36 nouvelles : energie/nucleaire + reste du jeu).

Convention : sheet horizontale (W*4 x H), 4 frames, lecture G->D en boucle,
**frame 0 = sprite statique EXACT** (verifie pixel-par-pixel), fond transparent.
Toutes derivees des PNG statiques existants (rotation, glow, flamme, ondulation, etc.).

Voir `animations_manifest.csv` pour la liste complete (cle, sheet, taille, fps, mouvement)
et la section `animations` de `sprites_manifest.json`.

## Nouvelles animations de ce pack (36)
ENERGIE/NUCLEAIRE : refroidisseur, broyeur_uranium, centrale_charbon, centrale_diesel,
accumulateur, centrale_enrichissement, usine_moteur_nucleaire, centrale_nucleaire (256x64).
RESTE : broyeur, usine_polymere, fab_processeur, raffinerie, puits_petrole_v1,
plateforme_petroliere, four_fer_v1/v2, four_cuivre_v1/v2, four_arc_acier/cable/meca,
acierie, fonderie_or, raffineur_silicium, distillerie, cablerie, atelier_meca, circuit,
pompe_eau, bateau_cargo, carriere_v1/v2/v3, cimenterie, betonniere, antenne.

Seule la centrale_nucleaire est en 256x64 (tuile 2x2), toutes les autres en 128x32.
