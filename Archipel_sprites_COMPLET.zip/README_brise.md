# Tuiles "brise" — couverture complete

16 tuiles animees (4 frames) : land + coast + water des **5 iles** + petrole (i3).
Scintillement herbe/eau pour simuler une brise par changement aleatoire.

Regles : frame 0 = tuile statique exacte ; **2px de bord identiques sur les 4 frames**
-> tiling sans couture quelle que soit la frame de chaque tuile. Tuiles opaques 32x32.

Masque vegetation robuste (vert ET jaune-vert de l'ile 3, sans toucher terre/roche),
masque eau (bleu), masque reflet huileux (petrole).

Integration (jeu) : phase par tuile `frame=(t+i+j)%4` (bourrasque diagonale) ou phase
aleatoire (scintillement disperse) ; compteur t lent (~2-4 fps).

A faire si besoin : herbe des tuiles obstacle/resource (meme masque) pour un champ
100% coherent ; tuiles de l'ile 6 (glaciaire) quand elles existeront.
