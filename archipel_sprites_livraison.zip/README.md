# Archipel Industry — Pack de sprites (livraison)

Ce dossier contient **342 sprites** prêts à intégrer + leur manifest.

## Contenu
- `sprites/` : les 342 fichiers PNG (RGBA, fond transparent sauf tuiles terrain & `tile_port_terre` qui sont opaques)
- `sprites_manifest.json` : catalogue structuré (à utiliser pour le code d'intégration)
- `sprites_manifest.csv` : même catalogue à plat, 1 ligne/fichier (lecture/édition humaine)

## Conventions
- **Tuile de jeu = 32×32 px.** Exception : `bat_centrale_nucleaire.png` = 64×64 (bâtiment 2×2).
- **Réseaux** (route/tuyau/cable) : 4 niveaux × 16 variantes de connexion.
  Bitmask **N=1, E=2, S=4, O=8** → suffixe fichier `_NN_XXXX` (ex. `route_v2_07_NES.png`).
- **Jonctions** : 6 (3 paires × 2 orientations) × 4 versions.
  Hiérarchie de recouvrement **FIXE** : `cable > route > tuyau`
  (le tuyau passe toujours dessous, le câble toujours dessus). Effet pont intégré.
- **Items** : icônes 16×16, symbole seul transparent.
- **UI** : icônes 16×16 sur pastille colorée.

## Clés (`cle_jeu`)
Chaque entrée a une `cle_jeu` qui correspond au nom du bâtiment/item dans
`Archipel-industry-batiment.xlsx` (normalisé : minuscules, underscores).
Ex. `four_fer`, `centrale_nucleaire`, `minerai_or`, `route_v2_07_NES`.

## Bâtiments multi-niveaux
Les mines, carrière, fours fer/cuivre ont plusieurs fichiers (`niveaux`).
Le puits de pétrole n'a qu'un V1 (V2/V3 abandonnés).
Cimenterie/bétonnière = sprite unique (pas de V1/V2).

## Intégration single-file
Le jeu est un HTML autonome (pas de CDN — bug écran noir en file:// sinon).
Pour rester autonome : **encoder les PNG en base64 et les inliner**.
Sinon : dossier `sprites/` à côté du HTML (plus léger mais non autonome).

## Régénération
`build_manifest.py` (fourni séparément) reconstruit le manifest en scannant
les fichiers présents et signale tout manquant/orphelin.

## Exclus volontairement (NE PAS utiliser)
Anciennes versions : `road_*`, `pipe_*`, `wire_*` (remplacés par `route_vN_*`,
`tuyau_vN_*`, `cable_vN_*`), jonctions sans suffixe de version, `puits_petrole_v2/v3`,
tuiles génériques sans île, `montagne_32`, planches d'aperçu `*_x8` / `*_preview`.

## Police bitmap (ajout)
- `font_sheet.png` : planche 16 colonnes, glyphes 8×8, fond transparent.
- `font_manifest.json` : pour chaque caractère → fichier + position (col/row, x/y px) dans la planche.
- `font/` : 95 PNG individuels (un par glyphe).
- Couvre A-Z, a-z, 0-9, ponctuation et accents français (é è ê à â ù û î ï ô ç œ É È À Ç).
- Monospace 8×8, couleur claire — recolorable au rendu par teinte.
