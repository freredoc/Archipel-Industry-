# Archipel Industry — pack de sprites OFFICIEL

Source de vérité : **`Archipel_industry_alpha-7.html`** (SAVE_VERSION 19), extrait du dépôt
le 13/07/2026. Ce pack remplace `Archipel_sprites_COMPLET.zip`.

> **Règle appliquée : le build du jeu prime sur l'ancien ZIP.**
> Là où les deux divergeaient, c'est la version du jeu qui a été retenue.

---

## Arborescence

| dossier | contenu | statut |
|---|---|---|
| `sprites/` | **777** PNG — un par clé de `window.__SPRITE_DATA__` | **dans le build** |
| `anim/` | **179** feuilles — une par clé de `window.__ANIM_DATA__` | **dans le build** |
| `_nouveau_v2/` | 12 statiques + 11 feuilles V2 + bloc JS + brief + GIF | **pas encore intégré** |
|  `_a_integrer/` | 23 PNG présents dans l'ancien ZIP mais référencés nulle part | **à intégrer** (voir brief) |
| `cartes/`, `font/` | inchangés | — |
| `_scripts/`, `_docs/` | scripts et docs de l'ancien ZIP | repris tels quels |

**Nommage — une seule convention désormais :**
- sprite : `sprites/<clé>.png`
- anim : `anim/<clé>_sheet.png`

L'ancien ZIP mélangeait `_sheet.png` (101 fichiers) et `_anim.png` (80). C'est unifié.

Manifestes régénérés depuis le jeu : `MANIFEST.json`, `sprites_manifest.csv`,
`anims_manifest.csv` (avec `frames` / `fw` / `fh` / `fps` issus d'`ANIM_META`).

---

## Réconciliation avec l'ancien ZIP

Détail exhaustif dans `_RECONCILIATION.json`.

### 11 assets où l'ancien ZIP était **périmé** → version du jeu retenue

C'est ce que tu avais repéré. Il y en avait 11, pas 4 :

| sprite | anim |
|---|---|
| `bat_tour_aerorefrigerante` | `betonniere_v2` |
| `cimenterie_v2` | `cimenterie_v2` |
| `pompe_eau_v2` | `centrale_charbon_v2` |
| `centrale_charbon_v2` | `pompe_eau_v2` |
| `betonniere_v2` | `tile_port_mer` |
| | `tile_port_terre` |

Les 4 V2 (`cimenterie`, `pompe_eau`, `centrale_charbon`, `betonniere`) divergeaient sur
**les deux** tableaux : statique *et* feuille d'animation.

### 7 assets **absents** de l'ancien ZIP → ajoutés

Postérieurs au ZIP : `bat_broyeur_v2`, `four_arc_fer`, `four_arc_cuivre`, `tile_i3_oil`,
`ui_reparation`, `ui_sauvegarde`, et l'anim `broyeur_v2`.

### 21 **alias** dédupliqués

Mêmes pixels sous deux noms. La clé canonique du jeu est conservée, l'alias écarté :

- `sprites/centrale_nucleaire.png` → doublon de `bat_centrale_nucleaire`
- 20 × `anim/tile_iN_coast_tri_*_breeze_sheet.png` → renommés en `tile_iN_coast_tri_*`
  dans le jeu (identiques au pixel près, vérifié 20/20)

### 23 **orphelins** → `_a_integrer/`

Assets réels, mais que le build ne référence pas. Conservés plutôt que perdus :

- `fx_explosion`, `fx_boost`, `fx_boost_productivite` (statique + feuilles)
- 20 assets UI : 9-slice (boutons, cadres, onglets, versions « inox ») et textures inox

À trancher : soit ils sont à intégrer, soit ils sont morts et à supprimer.

---

## `_nouveau_v2/` — livraison en attente

Les 12 sprites V2 demandés (centrale diesel, nucléaire, fonderie or, raffinerie, usine
polymère, distillerie, circuit, raffineur silicium, fab processeur, broyeur uranium,
centrale enrichissement, usine moteur nucléaire).

**Volontairement séparés de `sprites/` et `anim/`** : ces dossiers reflètent exactement
le build. Y verser des assets non intégrés casserait cette garantie.

Voir `_nouveau_v2/INTEGRATION_SPRITES_V2.md`. `SAVE_VERSION` inchangé.

---

## Vérification

- 777 sprites + 179 anims recontrôlés **pixel par pixel** contre le base64 du jeu : **0 écart**
- `frame 0 == sprite statique` sur les 11 nouvelles feuilles V2 : **0 écart**
