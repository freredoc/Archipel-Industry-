# Brief — assets (integration technique)

Contre `Archipel_industry_alpha-7.html`, SAVE_VERSION 19. Ancrages par texte, jamais par ligne.

**Portée : assets uniquement.** Aucun `BUILDINGS` / `RES_TIER` / `TIER_NEXT` / `TIER_STEP` /
recette / coût / nœud tech. Équilibrage à la charge d'Ethan.

---

## 1. Coller `assets_data.js`

Ancrage — la ligne unique :

```
window.__ANIM_DATA__["tour_aerorefrigerante"]=
```

Coller le fichier **juste après cette ligne complète** (elle finit par `";`).

⚠️ **Même bloc `<script>`.** `ANIM_INDEX` est construit une seule fois par la boucle
`for (const cle in ANIM_DATA)` : tout ce qui est ajouté après est ignoré.

## 2. Insérer les 17 entrées d'`anim_meta_additions.txt`

Dans le littéral `const ANIM_META = {`, en respectant les virgules.

Les `fps` des V2 reprennent **exactement** ceux de la V1 correspondante.
Les 3 `fx_*` n'avaient **aucune** entrée `ANIM_META` d'origine : les fps (8/8/10) sont
**proposés**, à valider à l'œil.

---

## 3. Contenu

| clé statique | clé anim | note |
|---|---|---|
| `bat_<id>_v2` × 12 | `<id>_v2` × 11 | `usine_moteur_nuc` sans anim, comme sa V1 |
| `bat_separateur_air` | `separateur_air` | nouveau |
| `bat_separateur_air_v2` | `separateur_air_v2` | nouveau |
| `puits_petrole_v2` | `puits_petrole_v2` | pas de préfixe `bat_`, comme `puits_petrole_v1` |
| `item_oxygene` | — | icône 16×16, 4 couleurs |
| 20 orphelins (`fx_explosion`, `ui_*_9slice`) | 3 orphelins (`fx_*`) | ex-`_hors_build` |

## 4. Résolution des clés — aucun code à toucher

Vérifié en simulant le moteur :

```
buildingSpriteKey('separateur_air')     -> bat_separateur_air
buildingSpriteKey('separateur_air_v2')  -> bat_separateur_air_v2
buildingSpriteKey('puits_petrole_v2')   -> puits_petrole_v2
itemSpriteKey('oxygene')                -> item_oxygene
```

→ **ni `BLD_SPRITE_OVERRIDE`, ni `ITEM_SPRITE_OVERRIDE`, ni patch de `buildingSpriteKey`.**

## 5. Invariant moteur

`frame 0` de chaque feuille est **pixel pour pixel identique** au sprite statique.
Vérifié sur les 14 feuilles livrées — 0 écart.

## 6. Validation après collage

- `node --check` sur le bloc extrait
- `__SPRITE_DATA__` : 777 → **813**   |   `__ANIM_DATA__` : 179 → **196**
- `ANIM_INDEX` doit contenir les 17 nouvelles clés
- `SAVE_VERSION` : **inchangé**. Aucune donnée persistée ne bouge tant que les entrées
  `BUILDINGS` ne sont pas créées.

## 7. Point non-asset à connaître

Les 19 `ui_*_9slice` sont en **17×17** (bordure 1 px + centre étirable 15 px). Le jeu n'a
**pas** de fonction de rendu 9-slice : sans elle, ils s'afficheront comme de simples carrés
de 17 px. Les inliner ne suffit pas à les faire servir.
