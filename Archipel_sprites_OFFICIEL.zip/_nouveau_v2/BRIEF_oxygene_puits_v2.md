
---

## Ajout — Séparateur d'Air V2

Clés : statique `bat_separateur_air_v2`, anim `separateur_air_v2`. Aucun override.
`ANIM_META` : `{frames:4, fw:32, fh:32, fps:8}`.

Double colonne (haute + basse pression) = le « tell » V2. Ratios / coûts / paliers : à ta main.
