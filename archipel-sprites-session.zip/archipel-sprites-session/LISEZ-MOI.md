# SPRITES — récapitulatif de session

Base de contrôle : `Alpha 14.88` · `GAME_BUILD = 371` · 3 289 188 octets.

**70 sprites retenus**, plus 15 écartés conservés pour arbitrage. Le statut de chacun n'est pas déclaré de mémoire : il est calculé en re-décodant `SPRITE_DATA` et `ANIM_DATA` de la base 371 et en comparant les SHA-256 au PNG source.

```
integres/     62 sprites déjà en base, identiques au pixel près
  tuiles/       6   tile_i1..i6_remblai
  anim/         5   tile_i1..i5_remblai_breeze
  icones/      51   ui_*
a-integrer/    8 sprites pas encore en base
  tuiles/       2   port en ruine
  overlays/     6   gisements par exclusivité d'île
ecartees/     15   non retenus, joints pour arbitrage seulement
SHA256.txt         empreintes des 70 retenus
```

---

## Ce qui reste à intégrer (8)

### Port en ruine — 2 tuiles

`tile_port_terre_casse` · `tile_port_mer_casse`

⚠ **Aucune mécanique de port cassé n'existe.** L'élévateur passe par `game.elevatorRepaired`, le collisionneur par `colliderRepaired(game)` ; `drawPortExtras` dessine `tile_port_mer` sans condition. Il faut d'abord un drapeau de partie et sa sérialisation — de la mécanique, pas de l'art. Les clés peuvent entrer en base dès maintenant sans risque : une clé non référencée n'est jamais rendue.

### Gisements — 6 overlays

`overlay_resource_i1`, `i2`, `i4`, `i5`, `i6`, `i7`. Silhouette identique au pixel près à `overlay_resource`.

Couleurs prises du champ `color` des bâtiments : charbon `#333333`, cuivre `#B87333`, or `#C9A227`, uranium `#66BB6A`, tungstène `#C2CBD6`, hélium `#4FC3F7`.

**Île 3 absente volontairement** — le pétrole a son terrain propre (`oil`). **`mine_fer` et `carriere` n'ont aucun `exclusiveIsland`** : le fer est sous-entendu partout, seule la ressource exclusive est marquée.

Deux ancres, `count == 1` sur 371 : `const COAST_FEATURE_OVERLAY = {` et `const ov = COAST_FEATURE_OVERLAY[t.terrain];`. La table est indexée par **terrain**, pas par île — le choix doit se faire au site de rendu, où `isl` est disponible, avec repli sur `overlay_resource`. Pas de bump de `SAVE_VERSION`.

---

## Ce qui a été écarté (15)

| Lot | Écartés | Raison |
|---|---|---|
| planche 2 | `bateau`, `maillon`, `nucleaire`, `petrole` | objets figuratifs illisibles à 16 px ; `bateau` et `petrole` repris plus tard sous une autre forme et retenus |
| planche 3 | `melange`, `tutoriel` | fiole et chapeau de diplômé ; `melange` repris plus tard et retenu |
| finale | `diplome`, `maillon`, `retour`, `retour_sablier` | rosette → casque, anneaux → lunettes, croissant → « C » ; le sablier reproduit `ui_attente` |
| sheets | amplitude pleine (5) | arbitrage : amplitude moitié retenue |

---

## Conventions tenues sur toute la session

- Icônes : 16×16, **masque de 193 px identique à `ui_port`**, alpha binaire, contour `#1E2128`, glyphe `#F5F8FC`, 5 à 7 couleurs.
- Tuiles : 32×32, opaque plein. Overlays : alpha binaire, silhouette conservée.
- Sheets : 128×32, 4 frames, **frame 0 pixel-identique au sprite statique**, vérifié sur le HTML patché et non sur les fichiers sources.
- Trait et creux internes de **2 px minimum** — les contours de 1 px disparaissent à la taille de rendu.
- Chaque icône jugée **à taille réelle et sans étiquette**, mélangée à des icônes déjà en base. C'est ce test qui a écarté 15 sprites.
- oxipng `-o max --strip safe` sur toutes les sorties.

## Deux corrections d'analyse faites en cours de session

**`SPRITE_DATA` a deux formes de déclaration** : un littéral d'objet et environ 1330 affectations individuelles. Un premier inventaire qui ne lisait que le littéral comptait 306 clés au lieu de 1445, et concluait à tort que `ui_batterie` manquait.

**Les mines sont bien restreintes par île**, via le champ `exclusiveIsland` — 57 occurrences. Une première recherche portant sur `island`, `islands`, `onlyIsland` avait conclu à l'absence de restriction. La conclusion négative venait d'un mauvais nom de champ, pas d'une absence.
