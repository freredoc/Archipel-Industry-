#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Batiments Ile 6
Source : Archipel-industry-batiment-1.xlsx, feuille Batiments, lignes 72-83.

Conventions relevees sur les sprites officiels (four_arc_acier, bat_atelier_meca,
bat_fab_processeur, bat_centrale_enrichissement, bat_distillerie...) :
  - 32x32 RGBA, fond transparent, bbox inset 1-2 px
  - contour #161A22 systematique
  - 400-780 px opaques, 14-23 couleurs
  - corps inox #2A303C -> #A5A8B2, volume : lumiere en haut/gauche, ombre bas/droite
  - une couleur d'accent SIGNATURE par batiment (cf. vert uranium, or processeur,
    cuivre distillerie) -> permet de distinguer les batiments d'un coup d'oeil
  - trim orange #FF9628 1px = langage V2

Exception : Collisionneur de Hadrons = 2x3 tuiles -> 64x96 (col. Taille de l'Excel).

Accents signature retenus pour l'ile 6 :
  tungstene       #C2CBD6  blanc-metal bleute   (mine, four a arc, machine-outil)
  supraconducteur #4FC3F7  cyan                 (presse UHP)
  quantique       #B47CFF  violet               (fab ordi, data center, collisionneur)
  geothermie      #FF6B3D  orange-rouge chaud   (geothermie)
  he3             #7FE6F0  cyan pale lumineux   (extracteur, separateur cryo)
  methane/gaz     #FFD166  jaune flamme         (centrale a gaz)
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


# ---- palette commune (identique aux sprites officiels)
OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
M3   = hx('#6E7684')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
L4   = hx('#BAC0CC')
WHT  = hx('#D6DCE4')
ORA  = hx('#FF9628')
ORAD = hx('#C46A12')
ORAL = hx('#FFC97A')

# accents signature
TUNG  = hx('#C2CBD6'); TUNGD = hx('#8A94A2')
CYAN  = hx('#4FC3F7'); CYAND = hx('#2A7FA8')
QUAN  = hx('#B47CFF'); QUAND = hx('#6E4AA8')
GEO   = hx('#FF6B3D'); GEOD  = hx('#A83A1C')
HE3   = hx('#7FE6F0'); HE3D  = hx('#3A96A4')
GAS   = hx('#FFD166'); GASD  = hx('#A8802E')
RUST  = hx('#7A4A32')
GRN   = hx('#78D26E')
GOLD  = hx('#BEA046')
DARK  = hx('#0D1016')
ROCK  = hx('#4C423A'); ROCKD = hx('#2A231D')


class Cv:
    def __init__(s, w=32, h=32):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def line(s, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            s.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy; x0 += sx
            if e2 < dx:
                err += dx; y0 += sy

    def disc(s, cx, cy, r, c):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r // 2:
                    s.px(x, y, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2, outline=OUTL):
        """Bloc volumetrique standard : contour + lumiere haut/gauche + ombre bas/droite."""
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, outline)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


# ---------- elements reutilisables ----------
def socle(c, x0=2, x1=29, y0=25, y1=29):
    """Embase sombre commune a la plupart des batiments."""
    c.rect(x0, y0, x1, y1, D1)
    c.frame(x0, y0, x1, y1, OUTL)
    c.hline(x0 + 1, x1 - 1, y0 + 1, M1)
    for x in range(x0 + 2, x1 - 1, 5):
        c.vline(x, y0 + 2, y1 - 1, D0)


def cheminee(c, x, ytop, ybot, w=3, cap=L3):
    c.rect(x, ytop, x + w - 1, ybot, M2)
    c.vline(x, ytop, ybot, OUTL)
    c.vline(x + w - 1, ytop, ybot, OUTL)
    c.hline(x, x + w - 1, ytop, OUTL)
    c.vline(x + 1, ytop + 1, ybot, L1)
    c.hline(x, x + w - 1, ytop + 1, cap)


def cuve(c, cx, cy, r, body=M2, hi=L3, sh=D2, band=None):
    """Cuve/reservoir cylindrique."""
    c.disc(cx, cy, r, body)
    c.disc(cx - 1, cy - 1, max(1, r - 2), hi)
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            d = (x - cx) ** 2 + (y - cy) ** 2
            if r * r + r // 2 < d <= (r + 1) ** 2 + r:
                c.px(x, y, OUTL)
    if band:
        c.hline(cx - r + 1, cx + r - 1, cy + 1, band)


def tuyaux(c, y, x0, x1, col=M1):
    c.hline(x0, x1, y, col)
    c.hline(x0, x1, y + 1, D2)


def voyants(c, pts, col):
    for (x, y) in pts:
        c.px(x, y, col)


# =====================================================================
# SURFACE
# =====================================================================

def mine_tungstene():
    """L72 · Acide -> Minerai de tungstene (+pierre). Chevalement + benne.
    Suit la famille mine_*_v3 : tete de puits + convoyeur + accent minerai."""
    c = Cv()
    socle(c, 2, 29, 24, 29)
    # portique de levage
    c.box(6, 6, 25, 23, M2, L2, D2)
    c.rect(8, 8, 23, 21, D1)
    # rails du derrick
    c.vline(9, 8, 21, M1); c.vline(22, 8, 21, M1)
    c.line(9, 21, 15, 9, M3); c.line(22, 21, 16, 9, M3)
    c.line(10, 21, 15, 10, L1); c.line(21, 21, 16, 10, L1)
    # tete de puits
    c.box(12, 3, 19, 8, M2, L2, D2)
    c.rect(14, 5, 17, 7, D0)
    voyants(c, [(15, 6), (16, 6)], TUNG)
    c.hline(12, 19, 4, ORA)          # trim V2
    # benne de minerai (accent tungstene)
    c.box(4, 17, 11, 23, D2, M1, D0)
    c.rect(5, 18, 10, 20, TUNGD)
    c.hline(5, 10, 18, TUNG)
    c.px(6, 19, TUNG); c.px(9, 19, TUNG)
    # cuve d'acide (intrant)
    cuve(c, 25, 19, 3, hx('#6E8C3A'), hx('#9CC45A'), hx('#3E5220'))
    c.px(25, 18, hx('#C4E67A'))
    voyants(c, [(4, 26), (27, 26)], ORA)
    return c


def four_arc_tungstene():
    """L73 · Acier irradie + minerai -> Alliage de tungstene. 8096 kW.
    Reprend la silhouette four_arc_* : caisson trapu + electrodes + lueur."""
    c = Cv()
    socle(c, 1, 30, 25, 29)
    # caisson du four
    c.box(3, 9, 28, 25, M2, L2, D2)
    c.rect(5, 11, 26, 23, D1)
    # briques refractaires
    for y in range(12, 23, 3):
        for x in range(6, 26, 4):
            c.rect(x, y, x + 2, y + 1, D2)
            c.px(x, y, M1)
    # porte de coulee incandescente (accent tungstene = blanc chaud)
    c.rect(11, 16, 20, 22, hx('#3A2A18'))
    c.frame(11, 16, 20, 22, OUTL)
    c.rect(12, 18, 19, 21, hx('#8A5A20'))
    c.rect(13, 19, 18, 20, TUNGD)
    c.hline(14, 17, 19, TUNG)
    c.px(15, 20, WHT); c.px(16, 20, WHT)
    # electrodes (3, signature four a arc)
    for x in [8, 15, 23]:
        c.vline(x, 3, 10, M1)
        c.vline(x + 1, 3, 10, D2)
        c.px(x, 3, L3); c.px(x + 1, 3, L2)
        c.px(x, 10, TUNG)
    # capot + trim
    c.hline(3, 28, 10, ORA)
    c.box(6, 5, 25, 9, D2, M1, D0)
    voyants(c, [(7, 7), (9, 7)], TUNG)
    voyants(c, [(3, 26), (28, 26)], ORA)
    return c


def machine_outil():
    """L74 · Alliage + piece meca -> Piece de precision. Genere MJ.
    Famille bat_atelier_meca : bati d'usinage + bras + copeaux."""
    c = Cv()
    socle(c, 2, 29, 24, 29)
    # bati de la machine
    c.box(3, 10, 28, 24, M2, L2, D2)
    c.rect(5, 12, 26, 22, D1)
    # table de travail
    c.rect(7, 17, 24, 21, M1)
    c.hline(7, 24, 17, L2)
    for x in range(8, 24, 3):
        c.vline(x, 18, 21, D2)
    # portique + broche verticale
    c.box(10, 4, 21, 12, D2, M1, D0)
    c.rect(12, 6, 19, 10, M2)
    c.hline(12, 19, 6, L2)
    c.vline(15, 12, 16, L3)      # broche
    c.vline(16, 12, 16, M1)
    c.px(15, 16, TUNG); c.px(16, 16, TUNG)   # pointe d'usinage
    # piece en cours (accent tungstene)
    c.rect(13, 17, 18, 18, TUNGD)
    c.hline(14, 17, 17, TUNG)
    # trim V2 + panneau de commande
    c.hline(3, 28, 11, ORA)
    c.box(24, 12, 28, 20, D2, M1, D0)
    voyants(c, [(26, 14), (26, 16)], CYAN)
    c.px(26, 18, ORA)
    # copeaux
    voyants(c, [(6, 23), (9, 23), (22, 23)], TUNGD)
    return c


def presse_uhp():
    """L75 · Cable irradie -> Cable supraconducteur. Sigmoide 128->1024 kW.
    Presse hydraulique massive : colonnes + verin + plateau. Accent cyan."""
    c = Cv()
    socle(c, 1, 30, 25, 29)
    # colonnes laterales massives
    c.box(2, 3, 8, 25, M2, L2, D2)
    c.box(23, 3, 29, 25, M2, L2, D2)
    for y in range(6, 24, 4):
        c.hline(3, 7, y, D2); c.px(3, y, M1)
        c.hline(24, 28, y, D2); c.px(24, y, M1)
    # sommier superieur
    c.box(2, 2, 29, 8, D2, M1, D0)
    c.hline(3, 28, 3, L2)
    c.hline(2, 29, 7, ORA)          # trim V2
    # verin central
    c.rect(13, 8, 18, 14, M3)
    c.frame(13, 8, 18, 14, OUTL)
    c.vline(14, 9, 13, L2)
    c.vline(17, 9, 13, D2)
    # plateau de presse
    c.box(9, 14, 22, 18, M2, L3, D2)
    # chambre de compression (lueur cyan = supraconducteur)
    c.rect(9, 19, 22, 24, D0)
    c.frame(9, 19, 22, 24, OUTL)
    c.rect(11, 20, 20, 23, CYAND)
    c.hline(12, 19, 21, CYAN)
    c.px(14, 22, CYAN); c.px(17, 22, CYAN)
    # bobine de cable en sortie
    cuve(c, 5, 21, 3, D2, M1, D0)
    c.px(5, 21, CYAN); c.px(4, 20, CYAND)
    voyants(c, [(26, 20), (26, 22)], CYAN)
    return c


def fab_ordi_quantique():
    """L76 · Cable supra + processeur + or -> Ordinateur quantique.
    Salle blanche : caisson clair + cryostat + accent violet quantique."""
    c = Cv()
    socle(c, 2, 29, 25, 29)
    # corps salle blanche (clair, comme bat_fab_processeur)
    c.box(2, 8, 29, 25, L4, WHT, L1)
    c.rect(4, 10, 27, 23, hx('#C4CAD4'))
    # bandeau technique
    c.hline(2, 29, 9, ORA)
    c.rect(4, 11, 27, 13, D1)
    voyants(c, [(6, 12), (8, 12)], QUAN)
    voyants(c, [(24, 12), (26, 12)], GOLD)
    # cryostat central suspendu (silhouette lustre quantique)
    c.rect(12, 14, 19, 15, M2)
    c.frame(12, 14, 19, 15, OUTL)
    for i, w in enumerate([7, 5, 3]):
        y = 17 + i * 2
        c.rect(16 - w // 2, y, 15 + w // 2 + w % 2, y, QUAND)
        c.hline(16 - w // 2, 15 + w // 2 + w % 2, y, QUAN if i == 1 else QUAND)
        c.px(15, y, QUAN); c.px(16, y, QUAN)
    c.vline(15, 15, 22, QUAND); c.vline(16, 15, 22, QUAND)
    c.px(15, 22, QUAN); c.px(16, 22, QUAN)
    # baies laterales
    c.box(3, 15, 9, 23, M2, L2, D2)
    c.rect(4, 16, 8, 22, D1)
    voyants(c, [(5, 17), (7, 17), (5, 19), (7, 21)], CYAN)
    c.box(22, 15, 28, 23, M2, L2, D2)
    c.rect(23, 16, 27, 22, D1)
    voyants(c, [(24, 17), (26, 19), (24, 21)], GOLD)
    # cheminee de refroidissement
    cheminee(c, 6, 3, 8, 3, L4)
    cheminee(c, 23, 3, 8, 3, L4)
    return c


def data_center():
    """L77 · Processeur + azote + supra + or -> Information quantique (saveur aleatoire).
    Rangees de racks + ventilation. Accent violet, voyants multicolores = saveurs."""
    c = Cv()
    socle(c, 1, 30, 25, 29)
    # batiment bas et large
    c.box(1, 7, 30, 25, M2, L2, D2)
    c.hline(1, 30, 8, ORA)          # trim V2
    # 3 rangees de racks
    for i, y in enumerate([10, 15, 20]):
        c.rect(3, y, 28, y + 3, D1)
        c.frame(3, y, 28, y + 3, OUTL)
        c.hline(4, 27, y, M1)
        # LEDs : saveurs aleatoires (violet dominant + cyan/or/vert)
        cols = [QUAN, CYAN, GOLD, GRN, QUAN, CYAN]
        for j, x in enumerate(range(5, 28, 4)):
            c.px(x, y + 1, cols[(i * 2 + j) % len(cols)])
            c.px(x + 1, y + 2, cols[(i * 3 + j + 1) % len(cols)])
    # ventilation en toiture
    for x in [6, 16, 25]:
        c.rect(x - 2, 3, x + 2, 7, D2)
        c.frame(x - 2, 3, x + 2, 7, OUTL)
        c.hline(x - 1, x + 1, 4, M2)
        c.px(x, 5, L3)
        c.hline(x - 1, x + 1, 6, D0)
    # conduite d'azote (accent cyan pale)
    c.vline(0, 12, 24, HE3D)
    c.px(0, 14, HE3); c.px(0, 20, HE3)
    return c


def collisionneur():
    """L78 · He3 + info quantique triee -> Matiere exotique. TAILLE 2x3 -> 64x96.
    Megastructure terminale : anneau de collision + halls + tour de controle."""
    c = Cv(64, 96)
    # --- dalle / soubassement
    c.rect(1, 78, 62, 94, D1)
    c.frame(1, 78, 62, 94, OUTL)
    c.hline(2, 61, 79, M1)
    for x in range(4, 60, 7):
        c.vline(x, 80, 93, D0)
    # bandes d'avertissement
    for x in range(3, 61):
        if (x // 3) % 2 == 0:
            c.px(x, 92, ORA)

    # --- anneau de collision (le motif signature)
    cx, cy, R = 32, 44, 26
    for y in range(cy - R - 2, cy + R + 3):
        for x in range(cx - R - 2, cx + R + 3):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if R - 5 <= d <= R:
                c.px(x, y, M2)
            elif R < d <= R + 1.4:
                c.px(x, y, OUTL)
            elif R - 6.4 <= d < R - 5:
                c.px(x, y, OUTL)
    # tube interne lumineux (faisceau violet)
    for y in range(cy - R, cy + R + 1):
        for x in range(cx - R, cx + R + 1):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if R - 3.6 <= d <= R - 1.8:
                c.px(x, y, QUAND)
            elif R - 3.0 <= d <= R - 2.4:
                c.px(x, y, QUAN)
    # aimants supraconducteurs repartis sur l'anneau
    import math
    for k in range(12):
        ang = k * math.pi / 6
        mx = int(round(cx + (R - 2.5) * math.cos(ang)))
        my = int(round(cy + (R - 2.5) * math.sin(ang)))
        c.rect(mx - 2, my - 2, mx + 2, my + 2, D2)
        c.frame(mx - 2, my - 2, mx + 2, my + 2, OUTL)
        c.px(mx, my, CYAN)
        c.px(mx - 1, my, CYAND); c.px(mx + 1, my, CYAND)

    # --- point de collision central (coeur)
    c.disc(cx, cy, 9, D1)
    for y in range(cy - 10, cy + 11):
        for x in range(cx - 10, cx + 11):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if 9 < d <= 10.4:
                c.px(x, y, OUTL)
    c.disc(cx, cy, 6, QUAND)
    c.disc(cx, cy, 4, QUAN)
    c.disc(cx, cy, 2, WHT)
    # rayonnement
    for (dx, dy) in [(0, -8), (0, 8), (-8, 0), (8, 0), (-6, -6), (6, 6), (-6, 6), (6, -6)]:
        c.px(cx + dx, cy + dy, HE3)
    # detecteurs en croix
    c.rect(cx - 1, cy - 14, cx, cy - 11, M2)
    c.rect(cx - 1, cy + 11, cx, cy + 14, M2)
    c.rect(cx - 14, cy - 1, cx - 11, cy, M2)
    c.rect(cx + 11, cy - 1, cx + 14, cy, M2)

    # --- hall technique superieur
    c.box(6, 4, 57, 16, M2, L2, D2)
    c.hline(6, 57, 5, ORA)
    c.rect(9, 7, 54, 14, D1)
    for i, x in enumerate(range(11, 54, 6)):
        c.rect(x, 8, x + 3, 13, D2)
        c.px(x + 1, 9, [QUAN, CYAN, GOLD][i % 3])
        c.px(x + 2, 11, [CYAN, QUAN, HE3][i % 3])
    # tour de controle
    c.box(24, 0, 39, 6, D2, M1, D0)
    c.rect(27, 2, 36, 4, D0)
    voyants(c, [(29, 3), (31, 3), (33, 3)], CYAN)
    c.px(35, 3, ORA)

    # --- cryostat He3 (gauche) et alimentation (droite)
    c.box(1, 30, 8, 58, M2, L2, D2)
    c.rect(2, 32, 7, 56, D1)
    for y in range(34, 55, 5):
        c.hline(3, 6, y, HE3D)
        c.px(4, y, HE3); c.px(5, y, HE3)
    c.hline(1, 8, 31, ORA)

    c.box(55, 30, 62, 58, M2, L2, D2)
    c.rect(56, 32, 61, 56, D1)
    for y in range(34, 55, 5):
        c.hline(57, 60, y, CYAND)
        c.px(58, y, CYAN); c.px(59, y, CYAN)
    c.hline(55, 62, 31, ORA)

    # --- halls bas + sortie matiere exotique
    c.box(4, 68, 26, 80, M2, L2, D2)
    c.rect(6, 70, 24, 78, D1)
    voyants(c, [(8, 72), (11, 72), (14, 74), (17, 72), (20, 76)], QUAN)
    c.box(37, 68, 59, 80, M2, L2, D2)
    c.rect(39, 70, 57, 78, D1)
    # cuve de matiere exotique (le produit)
    cuve(c, 48, 74, 5, QUAND, QUAN, hx('#3E2A5E'))
    c.px(48, 74, WHT); c.px(47, 73, WHT)
    # conduits reliant l'anneau aux halls
    c.rect(15, 62, 17, 68, D2); c.vline(15, 62, 68, M1)
    c.rect(46, 62, 48, 68, D2); c.vline(46, 62, 68, M1)
    return c


# =====================================================================
# SOUTERRAIN
# =====================================================================

def foreuse():
    """L79 · ACTION (pas un batiment de prod) : creuse la roche, revele une
    poche d'He3. Sprite = tete de forage sur chenilles, lisible comme un outil."""
    c = Cv()
    # chenilles
    c.box(3, 21, 28, 28, D1, M1, D0)
    for x in range(5, 27, 3):
        c.rect(x, 23, x + 1, 26, D2)
        c.px(x, 23, M1)
    # chassis
    c.box(6, 13, 25, 22, M2, L2, D2)
    c.hline(6, 25, 14, ORA)          # trim V2
    c.rect(8, 16, 23, 20, D1)
    voyants(c, [(10, 18), (12, 18)], ORA)
    voyants(c, [(20, 18), (22, 18)], CYAN)
    # bras + tete de forage pointee vers le haut-gauche
    c.rect(13, 8, 18, 14, M1)
    c.frame(13, 8, 18, 14, OUTL)
    c.vline(14, 9, 13, L2)
    # foret helicoidal
    c.rect(14, 2, 17, 9, M3)
    c.frame(14, 2, 17, 9, OUTL)
    for i, y in enumerate(range(3, 9)):
        c.px(15 if i % 2 == 0 else 16, y, L3)
        c.px(16 if i % 2 == 0 else 15, y, D2)
    # pointe carbure (accent tungstene)
    c.px(15, 1, TUNG); c.px(16, 1, TUNG)
    c.px(14, 2, TUNGD); c.px(17, 2, TUNGD)
    # gravats projetes
    voyants(c, [(4, 19), (27, 17), (5, 16)], ROCK)
    voyants(c, [(3, 20), (28, 19)], ROCKD)
    return c


def geothermie():
    """L80 · Aucune entree -> 512 kW. Seule source elec du souterrain.
    Puits + echangeur + cheminee de vapeur. Accent orange-rouge chaud."""
    c = Cv()
    socle(c, 1, 30, 24, 29)
    # bloc turbine
    c.box(2, 12, 20, 24, M2, L2, D2)
    c.hline(2, 20, 13, ORA)
    c.rect(4, 15, 18, 22, D1)
    # rotor / turbine visible
    cuve(c, 11, 18, 4, D2, M1, D0)
    c.px(11, 18, GEO)
    for (dx, dy) in [(0, -2), (0, 2), (-2, 0), (2, 0)]:
        c.px(11 + dx, 18 + dy, GEOD)
    voyants(c, [(5, 16), (17, 16), (5, 21)], GEO)
    # tete de puits geothermique (droite)
    c.box(21, 8, 29, 24, M2, L2, D2)
    c.rect(23, 11, 27, 22, D1)
    # colonne de chaleur montante
    c.rect(24, 12, 26, 21, GEOD)
    c.vline(25, 13, 20, GEO)
    c.px(25, 12, hx('#FFB07A'))
    c.hline(21, 29, 9, ORA)
    # cheminee de vapeur
    cheminee(c, 8, 4, 12, 4, L3)
    c.px(9, 3, L4); c.px(10, 2, hx('#C8CED8'))
    c.px(9, 1, hx('#B0B6C0'))
    # conduits vers le sol (chaleur)
    c.rect(2, 25, 29, 26, D2)
    for x in range(4, 29, 5):
        c.px(x, 25, GEOD)
    return c


def extracteur():
    """L81 · Sur poche d'He3 -> Gaz fossiles. Tete de puits + collecteur.
    Accent cyan pale He3."""
    c = Cv()
    socle(c, 2, 29, 24, 29)
    # tete de puits centrale (arbre de noel)
    c.box(12, 6, 20, 24, M2, L2, D2)
    c.rect(14, 9, 18, 22, D1)
    c.vline(16, 10, 21, HE3D)
    c.px(16, 12, HE3); c.px(16, 16, HE3); c.px(16, 20, HE3)
    # vannes laterales
    for y in [11, 16, 21]:
        c.rect(9, y, 12, y + 1, M1)
        c.rect(20, y, 23, y + 1, M1)
        c.px(9, y, L2); c.px(23, y, L2)
        c.px(10, y + 1, D2); c.px(22, y + 1, D2)
    # chapeau + trim
    c.box(11, 3, 21, 7, D2, M1, D0)
    c.hline(11, 21, 4, ORA)
    voyants(c, [(13, 5), (15, 5)], HE3)
    c.px(19, 5, ORA)
    # cuves de collecte laterales
    cuve(c, 5, 18, 4, M2, L2, D2, band=HE3D)
    c.px(5, 16, HE3)
    cuve(c, 26, 18, 4, M2, L2, D2, band=HE3D)
    c.px(26, 16, HE3)
    # collecteurs horizontaux
    tuyaux(c, 25, 3, 28)
    voyants(c, [(8, 26), (23, 26)], ORA)
    return c


def separateur_cryogenique():
    """L82 · Gaz fossiles + azote -> Methane + He4 + He3 (multi-sortie).
    Variante du Separateur Air : colonnes de distillation + givre.
    3 colonnes = 3 sorties, chacune avec sa couleur."""
    c = Cv()
    socle(c, 1, 30, 25, 29)
    # 3 colonnes de distillation, hauteurs differenciees
    cols = [
        (4, 8, GAS, GASD),    # methane -> jaune
        (14, 4, HE3, HE3D),   # He3 -> cyan pale (la plus haute, produit noble)
        (24, 10, L4, L1),     # He4 -> blanc/gris
    ]
    for (cx, ytop, acc, accd) in cols:
        c.rect(cx - 3, ytop, cx + 3, 25, M2)
        c.frame(cx - 3, ytop, cx + 3, 25, OUTL)
        c.vline(cx - 2, ytop + 1, 24, L2)
        c.vline(cx + 2, ytop + 1, 24, D2)
        # chapeau
        c.hline(cx - 3, cx + 3, ytop, OUTL)
        c.hline(cx - 2, cx + 2, ytop + 1, L3)
        # plateaux de distillation
        for y in range(ytop + 4, 24, 4):
            c.hline(cx - 2, cx + 2, y, D2)
            c.px(cx, y, accd)
        # hublot de sortie (accent)
        c.rect(cx - 1, 20, cx + 1, 22, D0)
        c.px(cx, 21, acc)
        # givre cryogenique (bord clair)
        c.px(cx - 2, ytop + 3, WHT); c.px(cx + 2, ytop + 6, WHT)
    # collecteur horizontal reliant les colonnes
    c.rect(2, 26, 29, 27, D2)
    c.hline(2, 29, 26, M1)
    for (cx, _, acc, _) in cols:
        c.px(cx, 26, acc)
    # arrivee gaz + azote (gauche)
    tuyaux(c, 15, 0, 1, HE3D)
    c.px(0, 15, HE3)
    # trim V2
    c.hline(1, 30, 25, ORA)
    return c


def centrale_gaz():
    """L83 · Methane + oxygene -> 512 kW. Peaker.
    Turbine a gaz : bloc + cheminee + flamme visible. Accent jaune flamme."""
    c = Cv()
    socle(c, 1, 30, 24, 29)
    # bloc turbine
    c.box(2, 11, 23, 24, M2, L2, D2)
    c.hline(2, 23, 12, ORA)
    c.rect(4, 14, 21, 22, D1)
    # chambre de combustion (flamme)
    c.rect(7, 16, 18, 21, D0)
    c.frame(7, 16, 18, 21, OUTL)
    c.rect(8, 18, 17, 20, GASD)
    c.hline(9, 16, 19, GAS)
    c.px(11, 20, hx('#FFF0B0')); c.px(14, 20, hx('#FFF0B0'))
    # grille d'admission
    for x in range(5, 22, 3):
        c.vline(x, 14, 15, M1)
    # cheminee d'echappement
    cheminee(c, 24, 3, 24, 4, L3)
    c.rect(24, 4, 27, 6, D2)
    c.px(25, 3, hx('#9CA2AE')); c.px(26, 2, hx('#7E848E'))
    # transformateur / sortie elec
    c.box(24, 15, 29, 24, D2, M1, D0)
    c.px(26, 17, ORA); c.px(26, 19, ORA)
    c.vline(26, 21, 23, CYAN)
    # arrivee methane
    tuyaux(c, 26, 0, 2, GASD)
    c.px(0, 26, GAS)
    voyants(c, [(4, 26), (20, 26)], ORA)
    return c


# NOTE : mine_tungstene, four_arc_tungstene et collisionneur ne sont PLUS
# generes ici. Voir gen_derives_tungstene.py (derives des sprites officiels)
# et gen_collisionneur.py (4 etats de reparation).
BUILDINGS = [
    ('bat_machine_outil',       machine_outil),
    ('bat_presse_uhp',          presse_uhp),
    ('bat_fab_ordi_quantique',  fab_ordi_quantique),
    ('bat_data_center',         data_center),
    ('bat_foreuse',             foreuse),
    ('bat_geothermie',          geothermie),
    ('bat_extracteur',          extracteur),
    ('bat_separateur_cryogenique', separateur_cryogenique),
    ('bat_centrale_gaz',        centrale_gaz),
]

if __name__ == '__main__':
    for name, fn in BUILDINGS:
        print(fn().save(name + '.png'))
