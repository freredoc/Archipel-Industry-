#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Animations des batiments ile 6
==================================================

Format releve dans la source (ANIM_META / ANIM_DATA, ligne ~2069) :
  - spritesheet horizontale, 4 frames, lecture G->D en boucle
  - frame 0 = le sprite statique EXACT (invariant verifie a 0 px d'ecart)
  - la cle de l'anim = `cle` du batiment ; le moteur retrouve le sprite
    statique via [cle, 'bat_'+cle, cle+'_v1']

On anime donc PAR-DESSUS le sprite statique existant : on charge le PNG du
batiment, on le met en frame 0, et on ne modifie que les zones "vivantes"
(lueurs, pistons, rotors, gaz) sur les frames 1-3. Rien d'autre ne bouge, ce
qui garantit une boucle propre et l'invariant frame 0.

Batiments traites (les plus "actifs" de l'ile 6) :
  - four_arc_tungstene      : arc electrique qui crepite
  - bat_machine_outil       : broche + copeaux
  - bat_presse_uhp          : piston vertical + eclair de pression
  - bat_fab_ordi_quantique  : cryostat pulsant
  - bat_foreuse             : tete de forage qui tourne
  - bat_geothermie          : panache de vapeur
  - bat_extracteur          : bulles de gaz remontant
  - bat_separateur_cryogenique : colonnes de distillation qui scintillent
  - bat_centrale_gaz        : flamme de torchere

Les mines tungstene ont deja leurs sheets (v1/v2/v3), on n'y touche pas.
"""
from PIL import Image
import numpy as np, os

SRC = 'out/sprites'
ANIM = 'out/anim'
os.makedirs(ANIM, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


def load(name):
    return np.array(Image.open(f'{SRC}/{name}.png').convert('RGBA'))


def px(f, x, y, c):
    if 0 <= x < f.shape[1] and 0 <= y < f.shape[0]:
        f[y, x] = c


def find_color(base, target, tol=30):
    """Renvoie les coords des pixels proches de 'target' (pour localiser une
    zone active du sprite : ecran, flamme, etc.)."""
    d = np.abs(base[:, :, :3].astype(int) - np.array(target[:3])).sum(axis=2)
    return np.argwhere((d <= tol) & (base[:, :, 3] > 0))


def make_sheet(base, animate_fns):
    """base = sprite statique. animate_fns = liste de 3 fns(frame,i) pour les
    frames 1,2,3. Frame 0 = base intacte."""
    h, w = base.shape[:2]
    frames = [base.copy() for _ in range(4)]
    for i in range(1, 4):
        animate_fns(frames[i], i)
    sheet = np.zeros((h, w * 4, 4), np.uint8)
    for i, f in enumerate(frames):
        sheet[:, i * w:(i + 1) * w] = f
    return sheet


# ------------------------------------------------------ animations par batiment
def anim_four_arc(base):
    """Arc electrique bleu-blanc qui crepite entre deux electrodes."""
    # centre approximatif de la cuve
    cx, cy = base.shape[1] // 2, base.shape[0] // 2 + 2
    arcs = [
        [(cx - 3, cy - 4), (cx, cy), (cx + 2, cy + 3)],
        [(cx - 2, cy - 4), (cx + 1, cy - 1), (cx - 1, cy + 3)],
        [(cx - 3, cy - 3), (cx + 2, cy), (cx + 1, cy + 4)],
    ]

    def fn(f, i):
        path = arcs[i - 1]
        col = [hx('#BFEFFF'), hx('#7FD4FF'), hx('#DFF6FF')][i - 1]
        for (x, y) in path:
            px(f, x, y, col)
            px(f, x + 1, y, hx('#4FC3F7'))
        # lueur montante
        for k in range(3):
            px(f, cx + (i - 2), cy - 5 - k, hx('#4FC3F7'))
    return fn


def anim_pulse_screen(base, glow=hx('#4FC3F7'), core=hx('#BFEFFF')):
    """Fait pulser les zones cyan (ecrans, cryostat) : plus clair sur les
    frames paires."""
    cyan = find_color(base, glow, tol=40)

    def fn(f, i):
        b = [0, 1, 2, 1][i]      # intensite
        for (y, x) in cyan:
            if b == 2:
                f[y, x] = core
            elif b == 1:
                f[y, x] = hx('#7FD4FF')
    return fn


def anim_piston(base):
    """Piston vertical : une barre qui descend puis remonte + eclair en bas."""
    cx = base.shape[1] // 2
    tops = [10, 12, 14, 12]

    def fn(f, i):
        top = tops[i]
        # tige
        for y in range(6, top):
            px(f, cx, y, hx('#A5A8B2'))
            px(f, cx - 1, y, hx('#646B78'))
        # tete
        for x in range(cx - 3, cx + 3):
            px(f, x, top, hx('#8C93A0'))
            px(f, x, top + 1, hx('#404652'))
        # eclair de pression en bas quand le piston est bas
        if i == 2:
            for x in range(cx - 4, cx + 4):
                px(f, x, top + 3, hx('#4FC3F7'))
            px(f, cx, top + 4, hx('#BFEFFF'))
    return fn


def anim_drill(base):
    """Tete de forage : chevrons qui defilent vers le bas (rotation)."""
    cx = base.shape[1] // 2
    cy = base.shape[0] - 8
    phase = [0, 1, 2, 3]

    def fn(f, i):
        p = phase[i]
        for k in range(4):
            y = cy + ((k + p) % 4)
            w = 4 - ((k + p) % 4)
            for x in range(cx - w, cx + w + 1):
                px(f, x, y, hx('#C2CBD6') if k % 2 else hx('#8C93A0'))
        # etincelles de forage
        if i % 2:
            px(f, cx - 4, cy + 3, hx('#FFD166'))
            px(f, cx + 4, cy + 2, hx('#FFD166'))
    return fn


def anim_steam(base, col=hx('#DCE2EA')):
    """Panache de vapeur/gaz qui monte : bouffees decalees au-dessus du toit."""
    cx = base.shape[1] // 2
    top = 6

    def fn(f, i):
        for k in range(4):
            y = top - k + (i % 2)
            x = cx + (1 if (k + i) % 2 else -1)
            shade = col if k < 2 else hx('#AEB6C2')
            px(f, x, y, shade)
            px(f, x + 1, y, shade)
    return fn


def anim_cryostat(base):
    """Fab ordi quantique : le coeur violet (#6E4AA8) pulse en clair, plus des
    qubits qui scintillent."""
    viol = find_color(base, hx('#6E4AA8'), tol=40)
    cx, cy = base.shape[1] // 2, base.shape[0] // 2

    def fn(f, i):
        b = [0, 1, 2, 1][i]
        for (y, x) in viol:
            if b == 2:
                f[y, x] = hx('#D6BBFF')
            elif b == 1:
                f[y, x] = hx('#B47CFF')
        # qubits scintillants autour du coeur
        pts = [(cx - 4, cy - 2), (cx + 4, cy), (cx, cy + 4), (cx - 2, cy + 2)]
        p = pts[i % len(pts)]
        px(f, p[0], p[1], hx('#EBE0FF'))
        px(f, p[0] + 1, p[1], hx('#B47CFF'))
    return fn


def anim_distillation(base):
    """Separateur cryogenique : colonnes qui scintillent (givre) + gouttes qui
    descendent. Le sprite n'a pas de zone coloree -> on anime des points de
    givre cyan sur les colonnes metalliques."""
    # deux colonnes reperees par le metal clair
    cols = [base.shape[1] // 2 - 5, base.shape[1] // 2 + 5]
    top, bot = 8, base.shape[0] - 6

    def fn(f, i):
        for j, cx in enumerate(cols):
            # givre scintillant a hauteur variable
            y = top + ((i * 2 + j) % (bot - top))
            px(f, cx, y, hx('#DFF6FF'))
            px(f, cx, y + 1, hx('#7FD4FF'))
            # goutte de condensat qui tombe
            gy = bot - ((i * 3 + j * 2) % (bot - top))
            px(f, cx + 1, gy, hx('#4FC3F7'))
    return fn


def anim_bubbles_strong(base, col=hx('#FFD166')):
    """Bulles de gaz plus nombreuses et contrastees (extracteur)."""
    cols = [base.shape[1] // 2 - 5, base.shape[1] // 2, base.shape[1] // 2 + 5]
    cy = base.shape[0] - 5
    top = 10

    def fn(f, i):
        for j, cx in enumerate(cols):
            span = cy - top
            y = cy - ((i * 3 + j * 4) % span)
            px(f, cx, y, col)
            px(f, cx, y - 1, hx('#FFE39A'))
            px(f, cx + 1, y, hx('#C8A030'))
            y2 = cy - ((i * 3 + j * 4 + 6) % span)
            px(f, cx, y2, col)
    return fn


def anim_flame(base):
    """Flamme de torchere : vacille en hauteur et couleur."""
    # cherche le sommet le plus haut du sprite (la torchere)
    op = np.argwhere(base[:, :, 3] > 0)
    top_y = op[:, 0].min()
    cx = int(np.median(op[op[:, 0] < top_y + 6][:, 1])) if len(op) else base.shape[1] // 2

    def fn(f, i):
        h = [3, 5, 4, 6][i]
        for k in range(h):
            y = top_y - 1 - k
            col = hx('#FFD166') if k < h - 2 else hx('#FF8C3A')
            if k == 0:
                col = hx('#FFF0C0')
            px(f, cx, y, col)
            if k < h - 1:
                px(f, cx - 1, y, hx('#FF8C3A'))
                px(f, cx + 1, y, hx('#FFB347'))
    return fn


JOBS = [
    ('four_arc_tungstene',        anim_four_arc),
    ('bat_machine_outil',         anim_drill),
    ('bat_presse_uhp',            anim_piston),
    ('bat_fab_ordi_quantique',    anim_cryostat),
    ('bat_foreuse',               anim_drill),
    ('bat_geothermie',            anim_steam),
    ('bat_extracteur',            anim_bubbles_strong),
    ('bat_separateur_cryogenique', anim_distillation),
    ('bat_centrale_gaz',          anim_flame),
]

# cle d'anim = nom sans prefixe bat_ (le moteur retrouve le statique via bat_+cle)
CLE = {
    'four_arc_tungstene': 'four_arc_tungstene',
    'bat_machine_outil': 'machine_outil',
    'bat_presse_uhp': 'presse_uhp',
    'bat_fab_ordi_quantique': 'fab_ordi_quantique',
    'bat_foreuse': 'foreuse',
    'bat_geothermie': 'geothermie',
    'bat_extracteur': 'extracteur',
    'bat_separateur_cryogenique': 'separateur_cryogenique',
    'bat_centrale_gaz': 'centrale_gaz',
}


if __name__ == '__main__':
    made = []
    for name, fn in JOBS:
        base = load(name)
        fn = fn(base)
        sheet = make_sheet(base, fn)
        # invariant frame 0
        assert np.array_equal(sheet[:, :base.shape[1]], base), f'frame0 KO {name}'
        cle = CLE[name]
        out = f'{cle}_sheet.png'
        Image.fromarray(sheet, 'RGBA').save(os.path.join(ANIM, out))
        made.append((out, sheet.shape[1] // 4, base.shape[1]))
    for o, fr, w in made:
        print(f'  {o:34s} {fr}x{w} frames=4')
    print(f'\n{len(made)} animations')
