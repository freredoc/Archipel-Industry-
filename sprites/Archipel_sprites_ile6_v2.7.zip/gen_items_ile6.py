#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Icones ressources Ile 6
Source : Archipel-industry-batiment-1.xlsx, feuille Ressources, lignes 36-45
         (+ Information quantique, feuille Batiments L77)

Conventions relevees sur les 30 icones officielles :
  - 16x16 RGBA, fond transparent
  - contour #1C1E26 (PAS #161A22 : les items ont leur propre contour, plus clair
    que celui des batiments)
  - 56-138 px opaques, 4-7 couleurs seulement -> icones tres lisibles
  - bbox typique x[2,14] y[2,14] : 1-2 px de marge
  - eclairage : clair a GAUCHE, sombre a DROITE (inverse des batiments, qui
    eclairent par le haut)
  - familles de FORME, pas de palette :
      * liquides/gaz -> goutte (masque item_eau reutilise tel quel)
      * metaux fondus -> lingot en perspective (masque item_lingot_fer)
      * minerais bruts -> amas de cailloux
      * composants -> objet dessine (circuit, processeur, piece meca)
  - les variantes "irradie" ajoutent des eclats vert-jaune #B4FF78

Les masques goutte et lingot sont EXTRAITS des sprites officiels, pas redessines.
"""
from PIL import Image
import numpy as np, os

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


OUTL = hx('#1C1E26')          # contour officiel des items
RAD  = hx('#B4FF78')          # eclat radioactif (convention *_irradie)

# ---- masques extraits des icones officielles -------------------------------
# item_eau : goutte. O=contour L=clair M=medium D=sombre
LIQUID = [
    "................",
    "................",
    "........O.......",
    ".......OMO......",
    ".......OMO......",
    "......OLMDO.....",
    "....OOLLMDDOO...",
    "...OLLLLMDDDDO..",
    "...OLLLLMDDDDO..",
    "...OLLLLMDDDDO..",
    "...OLLLLMDDDDO..",
    "....OLLLMDDDO...",
    ".....OLLMDDO....",
    "......OLMDO.....",
    ".......OOO......",
    "................",
]
# item_lingot_fer : lingot en perspective. H=highlight L=clair D=sombre
INGOT = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    ".....OOOO.......",
    "....OHHHHO......",
    ".....OLLLLO.....",
    "....OLLLLLLO....",
    "...OLLLLLLLLO...",
    "..ODDDDDDDDDDO..",
    "...OOOOOOOOOO...",
    "................",
    "................",
    "................",
]


class Cv:
    def __init__(s):
        s.a = np.zeros((16, 16, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < 16 and 0 <= y < 16:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def stamp(s, mask, pal):
        """Applique un masque extrait (dict role -> couleur)."""
        for y, row in enumerate(mask):
            for x, ch in enumerate(row):
                if ch != '.' and ch in pal:
                    s.px(x, y, pal[ch])

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


def liquide(light, med, dark):
    """Goutte : reutilise le masque officiel de item_eau."""
    c = Cv()
    c.stamp(LIQUID, {'O': OUTL, 'L': light, 'M': med, 'D': dark})
    return c


def lingot(hi, light, dark):
    """Lingot : reutilise le masque officiel de item_lingot_fer."""
    c = Cv()
    c.stamp(INGOT, {'O': OUTL, 'H': hi, 'L': light, 'D': dark})
    return c


# ===================================================================== ICONES

def tungstene():
    """L36 · Minerai brut de tungstene. Amas de cailloux (famille minerai_*),
    teinte blanc-metal bleute, distincte du fer (gris neutre)."""
    c = Cv()
    L, M, D = hx('#C2CBD6'), hx('#9AA4B2'), hx('#6E7784')
    # gros caillou
    c.rect(3, 6, 8, 11, M)
    c.hline(4, 7, 6, L); c.px(3, 7, L); c.px(4, 7, L)
    c.hline(4, 8, 11, D)
    c.frame(3, 6, 8, 11, OUTL)
    c.px(3, 6, OUTL); c.px(8, 11, OUTL)
    # caillou secondaire haut-droit
    c.rect(9, 3, 13, 7, M)
    c.hline(10, 12, 3, L)
    c.hline(10, 12, 7, D)
    c.frame(9, 3, 13, 7, OUTL)
    # caillou bas-droit
    c.rect(9, 9, 12, 13, M)
    c.hline(10, 11, 9, L)
    c.hline(10, 11, 13, D)
    c.frame(9, 9, 12, 13, OUTL)
    # eclats metalliques (le tell du tungstene)
    c.px(5, 8, hx('#E8EEF6')); c.px(11, 5, hx('#E8EEF6'))
    return c


def alliage_tungstene():
    """L37 · Lingot d'alliage. Famille lingot, teinte tungstene."""
    return lingot(hx('#E8EEF6'), hx('#C2CBD6'), hx('#8A94A2'))


def piece_precision():
    """L38 · Piece de precision. Famille composant : engrenage usine avec
    alesage central, plus fin que item_piece_meca (qui est un rouage epais)."""
    c = Cv()
    L, M, D = hx('#C8D0DC'), hx('#98A2B0'), hx('#69737F')
    # corps circulaire (d'abord, les dents seront greffees dessus)
    for y in range(16):
        for x in range(16):
            d = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** 0.5
            if d <= 4.8:
                c.px(x, y, M)
            elif d <= 5.7:
                c.px(x, y, OUTL)
    # 8 dents greffees sur la couronne (contact direct avec le corps)
    teeth = [(7, 1, 8, 2), (7, 13, 8, 14),        # haut / bas
             (1, 7, 2, 8), (13, 7, 14, 8)]        # gauche / droite
    for (x0, y0, x1, y1) in teeth:
        c.rect(x0, y0, x1, y1, M)
        c.frame(x0, y0, x1, y1, OUTL)
        c.px(x0, y0, OUTL)
    for (dx, dy) in [(3, 3), (11, 3), (3, 11), (11, 11)]:
        c.rect(dx, dy, dx + 1, dy + 1, M)
        c.px(dx, dy, OUTL)
    # volume : clair a gauche, sombre a droite
    for y in range(16):
        for x in range(16):
            d = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** 0.5
            if d <= 4.4:
                if x + y < 14:
                    c.px(x, y, L)
                elif x + y > 16:
                    c.px(x, y, D)
    # alesage central
    for y in range(16):
        for x in range(16):
            d = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** 0.5
            if d <= 1.6:
                c.px(x, y, hx('#3E444E'))
            elif d <= 2.3:
                c.px(x, y, OUTL)
    # trous d'allegement (marque "precision")
    for (x, y) in [(7, 4), (4, 9), (11, 9)]:
        c.px(x, y, hx('#3E444E'))
    return c


def cable_supraconducteur():
    """L39 · Cable supraconducteur. Famille cable (bobine), teinte cyan
    + halo froid : c'est un cable qui ne chauffe pas."""
    c = Cv()
    L, D = hx('#4FC3F7'), hx('#2A7FA8')
    # contour de la bobine EN PREMIER, les spires se posent dedans
    c.frame(2, 2, 13, 14, OUTL)
    # spires alternees clair/sombre (lecture "enroulement")
    for i, y in enumerate(range(3, 14)):
        c.hline(3, 12, y, L if i % 2 == 0 else D)
    # joues de la bobine
    c.vline(3, 3, 13, hx('#3E444E'))
    c.vline(12, 3, 13, hx('#3E444E'))
    # givre / supraconduction (le tell)
    c.px(5, 5, hx('#D6F5FF')); c.px(10, 10, hx('#D6F5FF'))
    c.px(7, 7, hx('#EBFAFF')); c.px(8, 8, hx('#EBFAFF'))
    return c


def ordinateur_quantique():
    """L40 · Ordinateur quantique. Famille composant : boitier sombre + coeur
    violet, evoque le cryostat de la fabrique."""
    c = Cv()
    # boitier
    c.rect(3, 2, 12, 13, hx('#2A303C'))
    c.frame(3, 2, 12, 13, OUTL)
    c.vline(4, 3, 12, hx('#404652'))
    c.hline(4, 11, 3, hx('#404652'))
    c.vline(11, 3, 12, hx('#1E222C'))
    c.hline(4, 11, 12, hx('#1E222C'))
    # coeur quantique (etages du cryostat)
    for i, (w, y) in enumerate([(6, 5), (4, 7), (2, 9)]):
        x0 = 7 - w // 2
        c.hline(x0, x0 + w - 1, y, hx('#B47CFF') if i == 1 else hx('#6E4AA8'))
    c.vline(7, 5, 10, hx('#6E4AA8'))
    c.px(7, 10, hx('#D6BBFF')); c.px(8, 10, hx('#D6BBFF'))
    # voyants
    c.px(5, 4, hx('#4FC3F7')); c.px(10, 4, hx('#BEA046'))
    c.px(5, 11, hx('#B47CFF'))
    return c


def information_quantique():
    """Batiments L77 · Information quantique (N saveurs).
    Qubit : sphere de Bloch stylisee. Volontairement MULTICOLORE pour dire
    'saveur aleatoire' - c'est la seule ressource du jeu dont l'icone doit
    signaler qu'elle porte une valeur variable."""
    c = Cv()
    # sphere
    for y in range(16):
        for x in range(16):
            d = ((x - 7.5) ** 2 + (y - 7.5) ** 2) ** 0.5
            if d <= 5.4:
                c.px(x, y, hx('#3A2E52'))
            elif d <= 6.3:
                c.px(x, y, OUTL)
    # anneau equatorial (superposition)
    for x in range(2, 14):
        d = abs(x - 7.5)
        if d <= 5.4:
            c.px(x, 8, hx('#6E4AA8'))
    c.hline(4, 11, 7, hx('#8A5FD0'))
    # vecteur d'etat
    c.px(7, 3, hx('#EBE0FF')); c.px(8, 3, hx('#EBE0FF'))
    c.vline(7, 4, 8, hx('#B47CFF'))
    c.px(8, 4, hx('#8A5FD0')); c.px(8, 5, hx('#8A5FD0'))
    # les N saveurs : 4 points de couleurs differentes autour
    c.px(4, 5, hx('#4FC3F7'))
    c.px(11, 6, hx('#BEA046'))
    c.px(5, 11, hx('#78D26E'))
    c.px(10, 11, hx('#FF6B9D'))
    c.px(7, 12, hx('#D6BBFF'))
    return c


def gaz_fossiles():
    """L41 · Gaz fossiles bruts (Tuyau). Goutte officielle, teinte brun-vert
    trouble : c'est un melange non raffine."""
    return liquide(hx('#8C8452'), hx('#6E6740'), hx('#4A4530'))


def helium3():
    """L42 · Helium 3 (Tuyau). Goutte, cyan pale lumineux - meme accent que
    la poche He3 des tuiles souterraines, pour la continuite de lecture."""
    c = liquide(hx('#7FE6F0'), hx('#4FBECC'), hx('#2E8494'))
    # halo : He3 est la ressource noble de l'endgame
    c.px(6, 8, hx('#DFFAFF'))
    c.px(5, 9, hx('#DFFAFF'))
    return c


def helium4():
    """L43 · Helium (He4), byproduct. Goutte, blanc-gris tres pale :
    volontairement TERNE a cote du He3, pour qu'on lise 'sous-produit'."""
    return liquide(hx('#DCE2EA'), hx('#AEB6C2'), hx('#7C8492'))


def methane():
    """L44 · Methane, byproduct valorisable. Goutte, jaune flamme -
    meme accent que la centrale a gaz."""
    return liquide(hx('#FFD166'), hx('#D8A83C'), hx('#96731F'))


def matiere_exotique():
    """L45 · Matiere exotique (T6, sortie terminale du collisionneur).
    Doit etre l'icone la plus 'chargee' du jeu : cristal violet en levitation
    avec halo. C'est la ressource de victoire."""
    c = Cv()
    # halo externe
    for (x, y) in [(7, 1), (8, 1), (2, 6), (13, 6), (2, 9), (13, 9), (7, 14), (8, 14)]:
        c.px(x, y, hx('#4A3070'))
    for (x, y) in [(4, 3), (11, 3), (4, 12), (11, 12)]:
        c.px(x, y, hx('#6E4AA8'))
    # cristal octaedrique
    pts = {}
    for y in range(16):
        for x in range(16):
            d = abs(x - 7.5) + abs(y - 7.5)      # losange
            if d <= 4.0:
                pts[(x, y)] = 'in'
            elif d <= 5.2:
                pts[(x, y)] = 'edge'
    for (x, y), k in pts.items():
        if k == 'edge':
            c.px(x, y, OUTL)
    for (x, y), k in pts.items():
        if k == 'in':
            # facettes : claire a gauche, sombre a droite
            if x + y < 14:
                c.px(x, y, hx('#C79BFF'))
            elif x + y > 16:
                c.px(x, y, hx('#5E3E96'))
            else:
                c.px(x, y, hx('#9366D8'))
    # arete centrale + coeur incandescent
    c.vline(7, 5, 10, hx('#E0D0FF'))
    c.px(7, 7, hx('#FFFFFF')); c.px(8, 7, hx('#FFFFFF'))
    c.px(7, 8, hx('#F0E6FF'))
    return c


ITEMS = [
    ('item_tungstene',              tungstene),
    ('item_alliage_tungstene',      alliage_tungstene),
    ('item_piece_precision',        piece_precision),
    ('item_cable_supraconducteur',  cable_supraconducteur),
    ('item_ordinateur_quantique',   ordinateur_quantique),
    ('item_information_quantique',  information_quantique),
    ('item_gaz_fossiles',           gaz_fossiles),
    ('item_helium3',                helium3),
    ('item_helium4',                helium4),
    ('item_methane',                methane),
    ('item_matiere_exotique',       matiere_exotique),
]

if __name__ == '__main__':
    for name, fn in ITEMS:
        print(fn().save(name + '.png'))
