#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Couche logique ile 6, sections 3 a 7 du brief
=================================================================

Verifications faites sur la source live (Alpha 13.88 / build 269) avant
production, pour ne pas fabriquer de sprites inutiles :

  - §1 Fils     : DEJA COMPLET (15 masques x 2 etats). Les "8 cles manquantes"
                  du brief existent toutes dans le pack v2.3.
  - §2 Portes   : DEJA COMPLET (8 portes x 4 orientations).
  - Portes _on  : INUTILES. Ligne ~18876 : le code peint une pastille d'etat
                  par-dessus le sprite (ctx.fillStyle selon logicOut). Aucun
                  sprite _on de porte n'est lu.
  - Etat 1      : BLANC #F0F0F4 (decision Ethan), pas le vert #00E5A0 que le
                  code utilise pour sa pastille. Les fils restent blancs.

Ce fichier produit uniquement ce qui manque reellement : §3 a §7 + les deux
fleches d'elevateur.

Palette officielle : contour #161A22, inox #2A303C..#A5A8B2, trim #FF9628,
cyan #4FC3F7, violet data #B47CFF, rouge alerte #FF5C5C.
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
ANIM = 'out/anim'
os.makedirs(OUT, exist_ok=True)
os.makedirs(ANIM, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
L4   = hx('#BAC0CC')
ORA  = hx('#FF9628')
ORAD = hx('#C46A12')
CYAN = hx('#4FC3F7')
CYAND = hx('#2A7FA8')
QUAN = hx('#B47CFF')
QUAND = hx('#6E4AA8')
RED  = hx('#FF5C5C')
REDD = hx('#A83232')
SIG_ON = hx('#F0F0F4')          # etat 1 : BLANC (decision Ethan)
SIG_ON_D = hx('#A8ACB8')
SIG_OFF = hx('#1A1A1E')
SHEATH = hx('#3A3E48')
WHITE = hx('#FFFFFF')
GLOW = hx('#F5C56A')


class Cv:
    def __init__(s, w=32, h=32):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2):
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, OUTL)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def disc(s, cx, cy, r, c):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r // 2:
                    s.px(x, y, c)

    def save(s, name, d=OUT):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(d, name))
        return name


def square_body(c):
    """Boitier carre 24x24 centre, identique aux autres composants logiques."""
    c.box(4, 4, 27, 27, M2, L2, D2)
    c.hline(4, 27, 5, ORA)
    c.rect(6, 7, 25, 25, D1)
    c.frame(6, 7, 25, 25, D0)


# ============================================================ §3 EMETTEURS
# Glyphes grecs dessines a la main : la police du jeu n'a que l'alphabet latin.
# 5x7 px, meme gabarit que les majuscules officielles, pour rester coherent.
GLYPH_ALPHA = [
    ".....",
    ".....",
    ".##.#",
    "#..##",
    "#...#",
    "#..##",
    ".##.#",
]
GLYPH_BETA = [
    "##...",
    "#.#..",
    "#.#..",
    "###..",
    "#..#.",
    "#..#.",
    "###..",
]
GLYPH_GAMMA = [
    ".....",
    ".....",
    "#...#",
    ".#.#.",
    "..#..",
    "..#..",
    "..#..",
]


def draw_glyph(c, g, x0, y0, col):
    for gy, row in enumerate(g):
        for gx, ch in enumerate(row):
            if ch == '#':
                c.px(x0 + gx, y0 + gy, col)


def emetteur(glyph, on=False, inactive=False):
    """Bloc emetteur : enfant du batiment porteur, non orientable.

    Le glyphe doit rester lisible a l'etat 'on' : le halo ne l'entoure que
    par les bords, il ne passe jamais dessus. C'est le point critique de
    lisibilite de toute la couche (cf. brief §3).
    """
    c = Cv()
    square_body(c)
    if inactive:
        # face non debloquee : obturee, sans glyphe. Doit se lire INERTE
        # (plaque pleine boulonnee), pas 'eteinte' (qui suggererait un bug).
        c.rect(9, 10, 22, 22, D2)
        c.frame(9, 10, 22, 22, D0)
        for (bx, by) in [(11, 12), (20, 12), (11, 20), (20, 20)]:
            c.px(bx, by, M1)
        # hachures = condamne
        for i in range(0, 14, 3):
            c.px(10 + i, 11 + i, M1)
        return c

    # cartouche du glyphe
    c.rect(9, 10, 22, 22, D0)
    c.frame(9, 10, 22, 22, M1 if not on else SIG_ON_D)
    body = SIG_ON if on else CYAN
    draw_glyph(c, glyph, 13, 12, body)
    # halo d'etat : uniquement sur le POURTOUR, jamais sur le glyphe
    if on:
        c.frame(8, 9, 23, 23, SIG_ON)
        for (px, py) in [(8, 9), (23, 9), (8, 23), (23, 23)]:
            c.px(px, py, WHITE)
    else:
        c.frame(8, 9, 23, 23, CYAND)
    # diode d'etat en coin (redondance avec la pastille du moteur)
    c.rect(25, 8, 26, 9, SIG_ON if on else hx('#0D5A45'))
    return c


# ================================================================ §4 VANNE
def vanne(state='off'):
    """Bloc vanne : lit le OU de ses faces, sans direction declaree.

    3 etats. Le '_penalite' annonce l'extinction du collisionneur et la perte
    des 10 min de demarrage : c'est le feedback le plus couteux du jeu, il doit
    etre rouge franc et non ambigu (brief §4).
    """
    c = Cv()
    square_body(c)
    if state == 'penalite':
        acc, accd = RED, REDD
    elif state == 'on':
        acc, accd = SIG_ON, SIG_ON_D
    else:
        acc, accd = M1, D2

    # corps de vanne : un obturateur circulaire
    c.disc(16, 16, 7, D0)
    for y in range(32):
        for x in range(32):
            d = ((x - 16) ** 2 + (y - 16) ** 2) ** 0.5
            if 6.6 < d <= 7.8:
                c.px(x, y, OUTL)
    c.disc(16, 16, 5, accd)
    c.disc(16, 16, 3, acc)

    # volant de commande : 4 branches. Ouvert = branches alignees sur les axes,
    # ferme = branches en diagonale -> l'etat se lit a la SILHOUETTE, pas
    # seulement a la couleur (lisible meme pour un daltonien).
    if state == 'off':
        for (dx, dy) in [(-1, -1), (1, 1), (-1, 1), (1, -1)]:
            for k in range(4, 8):
                c.px(16 + dx * k, 16 + dy * k, M2)
    else:
        for (dx, dy) in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            for k in range(4, 9):
                c.px(16 + dx * k, 16 + dy * k, acc)

    if state == 'penalite':
        # croix d'alerte + coins rouges : impossible a manquer
        for k in range(-4, 5):
            c.px(16 + k, 16 + k, RED)
            c.px(16 + k, 16 - k, RED)
        for (px, py) in [(6, 7), (25, 7), (6, 25), (25, 25)]:
            c.rect(px - 1, py - 1, px + 1, py + 1, RED)
        c.hline(4, 27, 5, RED)          # le trim orange devient rouge
    elif state == 'on':
        c.hline(4, 27, 5, SIG_ON)
    return c


def vanne_penalite_sheet():
    """Sheet 3 frames : flash d'alerte. Frame 0 = statique (invariant du pack)."""
    frames = [vanne('penalite'), vanne('penalite'), vanne('penalite')]
    # frame 1 : flash clair
    f1 = frames[1]
    for y in range(32):
        for x in range(32):
            p = f1.a[y, x]
            if p[3] and tuple(p[:3]) == RED[:3]:
                f1.a[y, x] = hx('#FFB0B0')
    # frame 2 : flash sombre
    f2 = frames[2]
    for y in range(32):
        for x in range(32):
            p = f2.a[y, x]
            if p[3] and tuple(p[:3]) == RED[:3]:
                f2.a[y, x] = REDD
    sheet = np.zeros((32, 96, 4), np.uint8)
    for i, f in enumerate(frames):
        sheet[:, i * 32:(i + 1) * 32] = f.a
    return sheet


# ============================================================= §5 JONCTION
def jonction(ns_on=False, eo_on=False):
    """Croisement sans connexion. Le passage superieur/inferieur doit etre
    lisible d'un coup d'oeil, sinon le joueur croit a une connexion (brief §5).

    Convention : l'axe E-O passe AU-DESSUS. Il est continu ; l'axe N-S est
    interrompu par une ombre portee et un pont metallique, ce qui montre
    physiquement qu'il plonge dessous.
    """
    c = Cv()
    core_ns = SIG_ON if ns_on else SIG_OFF
    core_eo = SIG_ON if eo_on else SIG_OFF
    edge_ns = SIG_ON_D if ns_on else hx('#0C0C10')
    edge_eo = SIG_ON_D if eo_on else hx('#0C0C10')

    # --- axe N-S (dessous), interrompu au centre
    for (y0, y1) in [(0, 11), (20, 31)]:
        c.vline(14, y0, y1, SHEATH)
        c.vline(18, y0, y1, SHEATH)
        c.vline(15, y0, y1, edge_ns)
        c.vline(16, y0, y1, core_ns)
        c.vline(17, y0, y1, edge_ns)
    # embouchures : le fil plonge sous le pont
    for y in (11, 20):
        c.hline(14, 18, y, D0)
    c.hline(15, 17, 12, hx('#0A0A0C'))
    c.hline(15, 17, 19, hx('#0A0A0C'))

    # --- axe E-O (dessus), continu
    c.hline(0, 31, 13, SHEATH)
    c.hline(0, 31, 19, SHEATH)
    c.hline(0, 31, 14, edge_eo)
    c.hline(0, 31, 15, core_eo)
    c.hline(0, 31, 16, core_eo)
    c.hline(0, 31, 17, core_eo)
    c.hline(0, 31, 18, edge_eo)

    # --- pont : tablier metallique + ombre portee, le tell du passage
    c.hline(11, 20, 12, M2)
    c.hline(11, 20, 20, M2)
    c.px(11, 12, L2); c.px(20, 12, L2)
    c.px(11, 20, D2); c.px(20, 20, D2)
    for x in (12, 15, 18):
        c.px(x, 12, L3); c.px(x, 20, D1)
    # ombre du tablier sur le fil du dessous
    c.hline(15, 17, 11, hx('#101014'))
    c.hline(15, 17, 21, hx('#101014'))
    return c


# ======================================================== §6 COLLISIONNEUR
# Le collisionneur est un LANDMARK 3x2 decoupe en 6 tuiles (tile_i6_collisionneur_0..5,
# sous-index = nord*3 + ouest, cf. source ligne ~18503). Les etats demandes par
# le brief (p1/p2/p3 x eteint/boot/actif) portent donc sur les 6 tuiles.
#
# Pour rester exploitable sans refaire 54 tuiles, on produit les 3 paliers en
# vignette 64x96 (comme bat_collisionneur_*) : c'est le format deja utilise par
# le pack pour les etats de reparation, et le code lit bat_collisionneur_p1/p2.
import math

CX, CY, R = 32, 44, 26


def collisionneur(palier=1, mode='off'):
    """palier 1/2/3, mode off|boot|actif.

    Chaque palier = x16 de puissance (32 -> 512 -> 8192 MW). Un ajout
    structurel par palier, meme logique que le 'V2 tell' :
      P1 : anneau simple, 12 aimants
      P2 : + anneau exterieur de renfort, 16 aimants, capots cyan
      P3 : + tours d'injection aux 4 coins, coeur double
    """
    c = Cv(64, 96)
    # dalle
    c.rect(1, 78, 62, 94, D1)
    c.frame(1, 78, 62, 94, OUTL)
    c.hline(2, 61, 79, M1)
    for x in range(4, 60, 7):
        c.vline(x, 80, 93, D0)
    trim = ORA if mode != 'off' else hx('#7A4A32')
    for x in range(3, 61):
        if (x // 3) % 2 == 0:
            c.px(x, 92, trim)

    n_mag = {1: 12, 2: 16, 3: 20}[palier]
    ring_w = {1: 5, 2: 6, 3: 7}[palier]

    # couleur du faisceau selon le mode
    if mode == 'actif':
        beam, beam_d = QUAN, QUAND
    elif mode == 'boot':
        beam, beam_d = CYAN, CYAND
    else:
        beam, beam_d = D1, D0

    # anneau principal
    for y in range(CY - R - 3, CY + R + 4):
        for x in range(CX - R - 3, CX + R + 4):
            d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
            if R - ring_w <= d <= R:
                c.px(x, y, M2)
            elif R < d <= R + 1.4:
                c.px(x, y, OUTL)
            elif R - ring_w - 1.4 <= d < R - ring_w:
                c.px(x, y, OUTL)
    # tube
    for y in range(CY - R, CY + R + 1):
        for x in range(CX - R, CX + R + 1):
            d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
            if R - ring_w + 1.4 <= d <= R - 1.8:
                c.px(x, y, beam_d)
            elif R - ring_w + 2.2 <= d <= R - 2.6:
                c.px(x, y, beam)

    # anneau de renfort exterieur (P2+)
    if palier >= 2:
        for y in range(0, 96):
            for x in range(0, 64):
                d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
                if R + 2.6 <= d <= R + 3.6:
                    c.px(x, y, D2)
                elif R + 3.6 < d <= R + 4.2:
                    c.px(x, y, OUTL)

    # aimants
    for k in range(n_mag):
        ang = k * 2 * math.pi / n_mag
        mx = int(round(CX + (R - ring_w / 2 - 0.5) * math.cos(ang)))
        my = int(round(CY + (R - ring_w / 2 - 0.5) * math.sin(ang)))
        c.rect(mx - 2, my - 2, mx + 2, my + 2, D2)
        c.frame(mx - 2, my - 2, mx + 2, my + 2, OUTL)
        if mode == 'off':
            c.px(mx, my, D0)
        elif mode == 'boot':
            c.px(mx, my, CYAN if (k % 2 == 0) else CYAND)
        else:
            c.px(mx, my, CYAN)
            c.px(mx - 1, my, CYAND); c.px(mx + 1, my, CYAND)

    # coeur
    c.disc(CX, CY, 9, D1)
    for y in range(CY - 11, CY + 12):
        for x in range(CX - 11, CX + 12):
            d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
            if 9 < d <= 10.4:
                c.px(x, y, OUTL)
    if mode == 'off':
        c.disc(CX, CY, 6, D0)
        c.disc(CX, CY, 3, hx('#0D1016'))
    elif mode == 'boot':
        c.disc(CX, CY, 6, D0)
        c.disc(CX, CY, 4, CYAND)
        c.disc(CX, CY, 2, CYAN)
    else:
        c.disc(CX, CY, 6, QUAND)
        c.disc(CX, CY, 4, QUAN)
        c.disc(CX, CY, 2, WHITE)
        if palier >= 3:
            for (dx, dy) in [(0, -8), (0, 8), (-8, 0), (8, 0)]:
                c.px(CX + dx, CY + dy, hx('#7FE6F0'))

    # detecteurs en croix
    for (rx0, ry0, rx1, ry1) in [(CX - 1, CY - 14, CX, CY - 11),
                                 (CX - 1, CY + 11, CX, CY + 14),
                                 (CX - 14, CY - 1, CX - 11, CY),
                                 (CX + 11, CY - 1, CX + 14, CY)]:
        c.rect(rx0, ry0, rx1, ry1, M2)

    # hall superieur
    c.box(6, 4, 57, 16, M2, L2, D2)
    c.hline(6, 57, 5, trim)
    c.rect(9, 7, 54, 14, D1)
    for i, x in enumerate(range(11, 54, 6)):
        c.rect(x, 8, x + 3, 13, D2)
        if mode == 'actif':
            c.px(x + 1, 9, [QUAN, CYAN, hx('#BEA046')][i % 3])
        elif mode == 'boot' and i % 2 == 0:
            c.px(x + 1, 9, CYAND)
    c.box(24, 0, 39, 6, D2, M1, D0)
    c.rect(27, 2, 36, 4, D0)
    if mode == 'actif':
        for x in (29, 31, 33):
            c.px(x, 3, CYAN)
    elif mode == 'boot':
        c.px(29, 3, CYAN); c.px(33, 3, CYAND)

    # tours d'injection (P3)
    if palier >= 3:
        for (tx, ty) in [(3, 22), (58, 22), (3, 62), (58, 62)]:
            c.box(tx - 2, ty - 4, tx + 2, ty + 4, M2, L2, D2)
            c.px(tx, ty, QUAN if mode == 'actif' else D0)

    # halls bas
    c.box(4, 68, 26, 80, M2, L2, D2)
    c.rect(6, 70, 24, 78, D1)
    c.box(37, 68, 59, 80, M2, L2, D2)
    c.rect(39, 70, 57, 78, D1)
    if mode == 'actif':
        for (px, py) in [(8, 72), (11, 72), (14, 74), (17, 72), (20, 76)]:
            c.px(px, py, QUAN)
        c.disc(48, 74, 5, QUAND)
        c.disc(47, 73, 3, QUAN)
        c.px(48, 74, WHITE)
    else:
        c.disc(48, 74, 5, D2)
        c.disc(47, 73, 3, M1)
    for y in range(69, 80):
        for x in range(43, 54):
            d = ((x - 48) ** 2 + (y - 74) ** 2) ** 0.5
            if 5 < d <= 6.4:
                c.px(x, y, OUTL)
    for x in (15, 46):
        c.rect(x, 62, x + 2, 68, D2)
    return c


def boot_sheet(palier):
    """Sheet 4 frames : montee en regime. Frame 0 = statique eteint (invariant).

    La sigmoide de puissance se termine a mi-parcours : frames 0-1 = lent,
    frames 2-3 = quasiment au regime. Le joueur voit que ca progresse, ce qui
    evite de croire que la machine est cassee pendant 10 min (brief §6).
    """
    f0 = collisionneur(palier, 'off')
    f1 = collisionneur(palier, 'boot')
    f2 = collisionneur(palier, 'boot')
    f3 = collisionneur(palier, 'actif')
    # f2 : boot plus avance -> coeur plus clair
    f2.disc(CX, CY, 4, CYAN)
    f2.disc(CX, CY, 2, hx('#BFEFFF'))
    sheet = np.zeros((96, 64 * 4, 4), np.uint8)
    for i, f in enumerate([f0, f1, f2, f3]):
        sheet[:, i * 64:(i + 1) * 64] = f.a
    return sheet


# ========================================================== §7 DATA CENTER
def data_center(niveau=1):
    """Niveaux 1-3 = bits achetes (alpha, alpha-beta, alpha-beta-gamma).
    Niveau 4 = palier de debit, plus de bus a montrer.

    Le bus qui s'elargit EST l'information utile au joueur : combien de bits il
    devra comparer. On le materialise par le nombre de pistes eclairees sur la
    face avant, pas par un detail decoratif.
    """
    c = Cv()
    c.rect(1, 25, 30, 29, D1)
    c.frame(1, 25, 30, 29, OUTL)
    c.hline(2, 29, 26, M1)

    c.box(1, 7, 30, 26, M2, L2, D2)
    c.hline(1, 30, 8, ORA)

    # racks
    for i, y in enumerate([11, 16, 21]):
        c.rect(3, y, 28, y + 3, D1)
        c.frame(3, y, 28, y + 3, OUTL)
        c.hline(4, 27, y, M1)
        for j, x in enumerate(range(5, 28, 4)):
            lit = (i * 2 + j) % 3
            c.px(x, y + 1, [QUAN, CYAN, hx('#BEA046')][lit])
            c.px(x + 1, y + 2, [CYAN, QUAN, hx('#78D26E')][lit])

    # ventilation
    for x in [6, 16, 25]:
        c.rect(x - 2, 3, x + 2, 7, D2)
        c.frame(x - 2, 3, x + 2, 7, OUTL)
        c.hline(x - 1, x + 1, 4, M2)
        c.px(x, 5, L3)

    # --- BUS : 3 pistes verticales a gauche, eclairees selon le niveau
    bits = min(niveau, 3)
    for k in range(3):
        bx = 0
        by = 10 + k * 6
        c.rect(bx, by, bx + 1, by + 3, SHEATH)
        if k < bits:
            c.vline(bx, by, by + 3, SIG_ON)
            c.px(bx, by, WHITE)
            # etiquette du bit sur le boitier
            draw_glyph(c, [GLYPH_ALPHA, GLYPH_BETA, GLYPH_GAMMA][k], 3, by, CYAN)
        else:
            c.vline(bx, by, by + 3, hx('#0C0C10'))

    if niveau >= 4:
        # palier debit : bandeau de throughput + double rangee de voyants
        c.hline(1, 30, 9, CYAN)
        for x in range(4, 28, 3):
            c.px(x, 10, WHITE)
        c.rect(24, 3, 30, 7, D2)
        c.frame(24, 3, 30, 7, OUTL)
        c.px(26, 5, ORA); c.px(28, 5, ORA)
    return c


# ================================================= FLECHES ELEVATEUR (bonus)
def fleche_elevateur(sens='bas'):
    """Tuile de terrain 32x32 : indique le passage vers l'autre grille.

    'bas'  = descendre vers le souterrain (ile 7)
    'haut' = remonter vers la surface (ile 6)

    Posee sur la tuile d'elevateur. Fond volontairement transparent au centre
    pour laisser voir la cage dessous ; seule la fleche et son cartouche sont
    opaques. La fleche est BLANCHE sur cartouche sombre, avec un lisere orange
    (trim V2) : elle doit se lire par-dessus n'importe quel fond de tuile.
    """
    c = Cv()
    down = (sens == 'bas')
    # cartouche
    c.rect(9, 6, 22, 25, hx('#12151C'))
    c.frame(9, 6, 22, 25, OUTL)
    c.frame(10, 7, 21, 24, ORA if down else CYAN)

    col = SIG_ON
    coldim = SIG_ON_D
    if down:
        # hampe
        c.rect(14, 9, 17, 17, col)
        c.rect(14, 9, 15, 17, coldim)
        # pointe
        for i, y in enumerate(range(18, 23)):
            w = 6 - i
            c.hline(16 - w, 15 + w, y, col)
            c.hline(16 - w, 16 - w + 1, y, coldim)
        c.px(15, 23, col); c.px(16, 23, col)
        c.px(15, 24, col); c.px(16, 24, col)
        # marches descendantes (renforce la lecture "on descend")
        c.px(11, 20, ORA); c.px(12, 21, ORA); c.px(13, 22, ORA)
        c.px(20, 20, ORA); c.px(19, 21, ORA); c.px(18, 22, ORA)
    else:
        c.rect(14, 14, 17, 22, col)
        c.rect(14, 14, 15, 22, coldim)
        for i, y in enumerate(range(13, 8, -1)):
            w = 6 - i
            c.hline(16 - w, 15 + w, y, col)
            c.hline(16 - w, 16 - w + 1, y, coldim)
        c.px(15, 8, col); c.px(16, 8, col)
        c.px(15, 7, col); c.px(16, 7, col)
        c.px(11, 11, CYAN); c.px(12, 10, CYAN); c.px(13, 9, CYAN)
        c.px(20, 11, CYAN); c.px(19, 10, CYAN); c.px(18, 9, CYAN)
    return c


if __name__ == '__main__':
    made = []

    # §3 emetteurs
    for nm, g in [('alpha', GLYPH_ALPHA), ('beta', GLYPH_BETA), ('gamma', GLYPH_GAMMA)]:
        made.append(emetteur(g, on=False).save(f'logic_emetteur_{nm}.png'))
        made.append(emetteur(g, on=True).save(f'logic_emetteur_{nm}_on.png'))
    made.append(emetteur(None, inactive=True).save('logic_emetteur_inactif.png'))

    # §4 vanne
    made.append(vanne('off').save('logic_vanne.png'))
    made.append(vanne('on').save('logic_vanne_on.png'))
    made.append(vanne('penalite').save('logic_vanne_penalite.png'))
    Image.fromarray(vanne_penalite_sheet(), 'RGBA').save(
        os.path.join(ANIM, 'logic_vanne_penalite_sheet.png'))
    made.append('anim/logic_vanne_penalite_sheet.png')

    # §5 jonction
    made.append(jonction(False, False).save('logic_jonction_NS_EO.png'))
    made.append(jonction(True, False).save('logic_jonction_NS_EO_ns.png'))
    made.append(jonction(False, True).save('logic_jonction_NS_EO_eo.png'))
    made.append(jonction(True, True).save('logic_jonction_NS_EO_both.png'))

    # §6 collisionneur
    for p in (1, 2, 3):
        made.append(collisionneur(p, 'off').save(f'bat_collisionneur_p{p}.png'))
        made.append(collisionneur(p, 'boot').save(f'bat_collisionneur_p{p}_boot.png'))
        made.append(collisionneur(p, 'actif').save(f'bat_collisionneur_p{p}_actif.png'))
        Image.fromarray(boot_sheet(p), 'RGBA').save(
            os.path.join(ANIM, f'bat_collisionneur_p{p}_boot_sheet.png'))
        made.append(f'anim/bat_collisionneur_p{p}_boot_sheet.png')

    # §7 data center
    for n in (1, 2, 3, 4):
        made.append(data_center(n).save(f'bat_data_center_v{n}.png'))

    # fleches elevateur
    made.append(fleche_elevateur('bas').save('tile_elevateur_fleche_bas.png'))
    made.append(fleche_elevateur('haut').save('tile_elevateur_fleche_haut.png'))

    print('\n'.join(made))
    print(f'\n{len(made)} fichiers')
