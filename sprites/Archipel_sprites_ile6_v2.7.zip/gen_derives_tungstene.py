#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Mine Tungstene & Four a Arc Tungstene
DERIVES des sprites officiels, pas redessines.

Systeme decode :
  - MINES : mine_fer_v1/v2/v3 est le master. Chaque minerai n'est qu'un swap de
    DEUX couleurs (le tas de minerai) :
        #969EAA (clair) et #757B84 (sombre)
    ex. uranium -> #78D26E / #5DA355 ; or -> #E0BC46 / #AE9236
    Verifie par bijection stricte sur les 6 minerais existants.
  - FOURS A ARC : four_arc_acier == four_arc_fer (0 px de diff). Les variantes
    (cuivre, meca) remappent 7 couleurs de CORPS, en gardant contour, arc
    electrique (#82D7FF/#EBFAFF), trim orange (#FF9628) et braise (#FFE196).

On applique donc exactement les memes swaps avec la teinte tungstene :
    tungstene = blanc-gris metallique legerement bleute (#C2CBD6 / #8A94A2)
"""
from PIL import Image
import numpy as np, os

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def arr(f):
    return np.array(Image.open(f).convert('RGBA'))


def swap(a, mapping):
    """Remplace des couleurs RGB exactes, alpha preserve."""
    out = a.copy()
    for src, dst in mapping.items():
        m = (a[:, :, 0] == src[0]) & (a[:, :, 1] == src[1]) & (a[:, :, 2] == src[2]) & (a[:, :, 3] > 0)
        out[m, 0], out[m, 1], out[m, 2] = dst
    return out


def save(a, name):
    Image.fromarray(a.astype(np.uint8), 'RGBA').save(os.path.join(OUT, name))
    return name


# ===================================================================== MINE
# Les 2 seules couleurs qui changent d'un minerai a l'autre.
ORE_LIGHT = (0x96, 0x9E, 0xAA)
ORE_DARK  = (0x75, 0x7B, 0x84)

# Tungstene : blanc-metal bleute. Doit rester distinct de "pierre" (#AAA08C,
# beige) et du gris du chassis -> on pousse vers le bleu clair et on ecarte
# les deux tons pour garder du contraste sur le chassis metallique.
TUNG_LIGHT = (0xC2, 0xCB, 0xD6)
TUNG_DARK  = (0x8A, 0x94, 0xA2)

MINE_MAP = {ORE_LIGHT: TUNG_LIGHT, ORE_DARK: TUNG_DARK}

# ============================================================ FOUR A ARC
# Les 7 couleurs de corps remappees par les variantes officielles.
# Reference du delta acier -> meca (variante grise), qu'on decale vers le
# blanc-bleute du tungstene en conservant l'ecart relatif de luminance.
FOUR_MAP = {
    (0x6E, 0x76, 0x84): (0x86, 0x90, 0x9E),   # corps principal (135 px)
    (0x48, 0x50, 0x5E): (0x5A, 0x64, 0x72),   # ombre de corps  (54 px)
    (0x5D, 0x64, 0x70): (0x70, 0x7A, 0x88),   # medium          (39 px)
    (0x96, 0x9E, 0xAC): (0xB4, 0xBE, 0xCC),   # clair           (26 px)
    (0x58, 0x5E, 0x69): (0x6A, 0x74, 0x82),   # medium sombre   (22 px)
    (0x7D, 0x86, 0x96): (0x9C, 0xA6, 0xB4),   # highlight       (21 px)
    (0x96, 0xAA, 0xC8): (0xC2, 0xCB, 0xD6),   # reflet froid    (13 px)
}
# NON touches, volontairement : #161A22 (contour), #3C3E46 / #363840 /
# #4E525A / #5C5E68 (structure sombre commune), #82D7FF + #EBFAFF (arc
# electrique), #FF9628 (trim V2), #FFE196 (braise).


if __name__ == '__main__':
    made = []

    # --- Mine Tungstene, 3 niveaux (comme toutes les mines du jeu)
    for v in ['v1', 'v2', 'v3']:
        src = f'{SRC}/mine_fer_{v}.png'
        made.append(save(swap(arr(src), MINE_MAP), f'mine_tungstene_{v}.png'))

    # --- Four a Arc Tungstene (master = four_arc_acier)
    made.append(save(swap(arr(f'{SRC}/four_arc_acier.png'), FOUR_MAP),
                     'four_arc_tungstene.png'))

    # --- Animations de mine : meme swap sur les spritesheets 4 frames
    #
    # ATTENTION : les 18 sheets officielles de mine violent toutes l'invariant
    # "frame 0 == sprite statique" (3 px sur v1, 6 sur v2, 5 sur v3 : le foret
    # est en position basse sur le statique et haute sur frame 0). Le defaut est
    # systematique et identique sur les 6 minerais -> il vient du generateur
    # d'origine, pas d'une retouche manuelle.
    # On ne propage pas le bug : frame 0 est reecrite avec le sprite statique.
    # Les frames 1-3 gardent le cycle d'origine, donc l'animation reste fluide.
    for v in ['v1', 'v2', 'v3']:
        src = f'anim/mine_fer_{v}_sheet.png'
        if os.path.exists(src):
            os.makedirs('out/anim', exist_ok=True)
            sheet = swap(arr(src), MINE_MAP)
            static = swap(arr(f'{SRC}/mine_fer_{v}.png'), MINE_MAP)
            fixed = int((sheet[:, :32] != static).any(axis=2).sum())
            sheet[:, :32] = static          # invariant frame 0
            Image.fromarray(sheet.astype(np.uint8), 'RGBA').save(
                f'out/anim/mine_tungstene_{v}_sheet.png')
            made.append(f'anim/mine_tungstene_{v}_sheet.png  (frame0 corrigee : {fixed} px)')

    # --- suppression des versions redessinees (remplacees par les derivees)
    for old in ['bat_mine_tungstene.png', 'bat_four_arc_tungstene.png']:
        p = os.path.join(OUT, old)
        if os.path.exists(p):
            os.remove(p)
            made.append('SUPPRIME ' + old)

    print('\n'.join(made))
