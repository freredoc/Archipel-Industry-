#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Icone d'ile 6 (format officiel)
===================================================

Format decode sur ile_1..ile_5.png (et non sur les ui_*, qui sont autre chose) :

  - 64x64 RGBA, fond transparent
  - une SILHOUETTE D'ILE vue de dessus, posee sur une grille de 4 px
  - exactement 8 couleurs, en 3 anneaux concentriques :
        coeur   -> 3 tons de LAND,  repris tels quels de tile_i<N>_land
        bordure -> 4 tons de COAST, repris tels quels de tile_i<N>_coast
        halo    -> ECUME #CEE7EC, identique sur les 5 iles
  - ~2 px de cote autour de la terre, ~2 px d'ecume autour de la cote
  - chaque ile a sa forme propre + une variante _gris pour l'etat verrouille

L'ile 6 est la seule a avoir DEUX ZONES (surface + souterrain) : sa silhouette
reprend cette dualite avec une masse principale et un satellite relies par un
isthme etroit, la ou se trouve l'elevateur. Les tons viennent directement de
tile_i6_land / tile_i6_coast, donc l'icone est raccord avec la carte.
"""
from PIL import Image
import numpy as np, os
from collections import Counter

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)

FOAM = (0xCE, 0xE7, 0xEC)


def arr(f):
    return np.array(Image.open(f).convert('RGBA'))


def palette_from_tiles():
    land = arr(f'{OUT}/tile_i6_land.png')
    coast = arr(f'{OUT}/tile_i6_coast.png')
    lc = [c for c, _ in Counter(tuple(p)[:3] for p in land.reshape(-1, 4)).most_common()]
    cc = [c for c, _ in Counter(tuple(p)[:3] for p in coast.reshape(-1, 4)).most_common()]
    lc = sorted(lc[:3], key=lambda c: -sum(int(v) for v in c))
    cc = sorted(cc[:4], key=lambda c: -sum(int(v) for v in c))
    return lc, cc


SHAPE = [
    "................",
    "................",
    "...XXXXXX.......",
    "..XXXXXXXX......",
    "..XXXXXXXXX.....",
    "..XXXXXXXXX.....",
    "..XXXXXXXXX.....",
    "...XXXXXXX......",
    "....XXXXX.......",
    ".....XXX........",
    "......XXXX......",
    ".......XXXXXX...",
    "........XXXXXX..",
    ".........XXXXX..",
    "..........XXX...",
    "................",
]
CELL = 4


def build_mask():
    m = np.zeros((64, 64), bool)
    for gy, row in enumerate(SHAPE):
        for gx, ch in enumerate(row):
            if ch == 'X':
                m[gy * CELL:(gy + 1) * CELL, gx * CELL:(gx + 1) * CELL] = True
    return m


def dilate(mask, n):
    out = mask.copy()
    for _ in range(n):
        cur = out.copy()
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            out |= np.roll(np.roll(cur, dy, 0), dx, 1)
    return out


def erode(mask, n):
    out = mask.copy()
    for _ in range(n):
        cur = out.copy()
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            out &= np.roll(np.roll(cur, dy, 0), dx, 1)
    return out


def build_icon(grey=False):
    lc, cc = palette_from_tiles()
    if grey:
        def desat(c):
            v = int(0.30 * c[0] + 0.59 * c[1] + 0.11 * c[2])
            v = min(int(v * 0.70 + 46), 255)
            return (v, v, v)
        lc = [desat(c) for c in lc]
        cc = [desat(c) for c in cc]
        foam = desat(FOAM)
    else:
        foam = FOAM

    land = build_mask()
    d1 = dilate(land, 1)
    d2 = dilate(land, 2)
    d4 = dilate(land, 4)

    a = np.zeros((64, 64, 4), np.uint8)
    a[d4 & ~d2] = (*foam, 255)          # ecume, 2 px
    a[d2 & ~d1] = (*cc[0], 255)         # cote claire
    a[d1 & ~land] = (*cc[1], 255)       # cote base
    edge = land & ~erode(land, 1)
    a[edge] = (*cc[2], 255)             # lisere sombre terre/cote

    core = erode(land, 1)
    for y in range(64):
        for x in range(64):
            if core[y, x]:
                if x + y < 52:
                    a[y, x] = (*lc[0], 255)
                elif x + y > 78:
                    a[y, x] = (*lc[2], 255)
                else:
                    a[y, x] = (*lc[1], 255)

    ys, xs = np.where(d1 & ~land)
    if len(xs):
        for k in (0, len(xs) // 2, len(xs) - 1):
            a[ys[k], xs[k]] = (*cc[3], 255)
    return a


if __name__ == '__main__':
    for grey, name in [(False, 'ile_6.png'), (True, 'ile_6_gris.png')]:
        Image.fromarray(build_icon(grey), 'RGBA').save(os.path.join(OUT, name))
        print(name)
    for f in ['ui_ile6.png', 'ui_ile6_verrouille.png', 'ui_ile6_souterrain.png']:
        p = os.path.join(OUT, f)
        if os.path.exists(p):
            os.remove(p)
            print('SUPPRIME ' + f)
