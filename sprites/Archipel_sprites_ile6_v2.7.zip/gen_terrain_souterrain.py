#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Tuiles du SOUTERRAIN (ile 7), jeu de terrain complet
=======================================================================

PROBLEME RESOLU ICI
-------------------
Le moteur n'a que 6 roles de terrain (charToTerrain) :
    W water · T land · M resource · O obstacle · C coast · P oil
et buildIslandTiles() promeut automatiquement en 'coast' toute tuile 'land'
adjacente a 'water'.

Pour le souterrain on REDEFINIT LE SENS des roles, sans toucher au moteur :

    water     -> ROCHE PLEINE       (le "vide" non creusable, equivalent de la mer)
    coast     -> BORD DE TUNNEL     (sol creuse au contact de la roche)
    land      -> TUNNEL             (sol creuse, circulable, constructible)
    obstacle  -> EBOULIS            (blocage local, degageable)
    resource  -> VEINE DE ROCHE     (minerai souterrain)
    oil       -> POCHE DE GAZ       (gisement He3/gaz fossiles, cf. Foreuse L79)

Consequence : la promotion automatique land->coast fabrique gratuitement le
liseré de bord de tunnel, et coastCliffPieces() pose les murs i7_mur_* au bon
endroit. Zero systeme neuf.

INVARIANT RESPECTE
------------------
Toutes les tuiles reutilisent le MASQUE DE DITHER OFFICIEL extrait de i1..i5
(bijection couleur verifiee). La roche pleine reutilise le masque 'water'
(bruit procedural), ce qui donne une texture dense sans motif visible - le
meme role que la mer : une masse continue qu'on ne traverse pas.
"""
from PIL import Image
import numpy as np, os

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def arr(f):
    return np.array(Image.open(f).convert('RGBA'))


def save(a, name):
    Image.fromarray(a.astype(np.uint8), 'RGBA').save(os.path.join(OUT, name))
    return name


# ================================================================= references
L5 = arr(f'{SRC}/tile_i5_land.png')
C5 = arr(f'{SRC}/tile_i5_coast.png')
O5 = arr(f'{SRC}/tile_i5_obstacle.png')
R5 = arr(f'{SRC}/tile_i5_resource.png')
W5 = arr(f'{SRC}/tile_i5_water.png')
OIL3 = arr(f'{SRC}/tile_i3_oil.png')
L3 = arr(f'{SRC}/tile_i3_land.png')

I5 = {
    'land_light': hx('#446C3D'), 'land_base': hx('#3A5C34'), 'land_dark': hx('#304D2B'),
    'coast_light': hx('#355E50'), 'coast_base': hx('#305448'),
    'coast_dark': hx('#29483D'), 'coast_spark': hx('#437564'),
    'rock_base': hx('#2E2D31'), 'rock_mid': hx('#434148'),
    'rock_light': hx('#54525A'), 'rock_hi': hx('#75727D'),
    'water_base': hx('#182A3E'),
}

# --- roles par pixel, extraits une fois
def role_map(a, mapping):
    out = np.empty((32, 32), object)
    for y in range(32):
        for x in range(32):
            out[y, x] = mapping.get(tuple(a[y, x][:3]))
    return out

LAND_ROLE = role_map(L5, {I5['land_light']: 'light', I5['land_base']: 'base',
                          I5['land_dark']: 'dark'})
COAST_ROLE = role_map(C5, {I5['coast_light']: 'light', I5['coast_base']: 'base',
                           I5['coast_dark']: 'dark', I5['coast_spark']: 'spark'})

ROCK_DIFF = (O5 != L5).any(axis=2)
ROCK_ROLE = role_map(O5, {I5['rock_base']: 'base', I5['rock_mid']: 'mid',
                          I5['rock_light']: 'light', I5['rock_hi']: 'hi'})

ORE_DIFF = (R5 != L5).any(axis=2)
_lum = R5[:, :, :3].astype(float).mean(axis=2)
_v = _lum[ORE_DIFF]
ORE_T = np.zeros((32, 32))
ORE_T[ORE_DIFF] = (_v - _v.min()) / max(1e-6, _v.max() - _v.min())

WATER_D = W5[:, :, :3].astype(int) - np.array(I5['water_base'])

# masque de la flaque de petrole (pour la poche de gaz)
OIL_DIFF = (OIL3 != L3).any(axis=2)
_olum = OIL3[:, :, :3].astype(float).mean(axis=2)
_ov = _olum[OIL_DIFF]
OIL_T = np.zeros((32, 32))
OIL_T[OIL_DIFF] = (_ov - _ov.min()) / max(1e-6, _ov.max() - _ov.min())

# triangles de bord
TRI = {d: (arr(f'{SRC}/tile_i5_coast_tri_{d}.png')[:, :, :3] != C5[:, :, :3]).any(axis=2)
       for d in ['ne', 'nw', 'se', 'sw']}


# ================================================================== palette i7
# Le souterrain inverse la logique de surface : le PLEIN est sombre, le
# CIRCULABLE est clair. Un joueur doit lire "ou puis-je aller" en un coup d'oeil.
P7 = {
    # TUNNEL (role land) : sol creuse, sec, eclaire par la geothermie
    'land_light':  hx('#6B5B49'),
    'land_base':   hx('#5C4D3E'),
    'land_dark':   hx('#4C4033'),
    # BORD DE TUNNEL (role coast) : legerement plus sombre + poussiereux
    'coast_light': hx('#5A4C3E'),
    'coast_base':  hx('#4C4034'),
    'coast_dark':  hx('#3E342B'),
    'coast_spark': hx('#8A7358'),      # eclat de quartz
    # EBOULIS (role obstacle) : blocs detaches sur le sol
    'rock_base':   hx('#2A231D'),
    'rock_mid':    hx('#3A3128'),
    'rock_light':  hx('#4E4235'),
    'rock_hi':     hx('#6B5C4D'),
    # ROCHE PLEINE (role water) : la "mer" du souterrain
    'water_base':  hx('#241E1A'),
}

ORE_LO, ORE_HI = hx('#16303A'), hx('#7FE6F0')       # veine He3, cyan
GAS_LO, GAS_HI = hx('#2E2A16'), hx('#C8B84A')       # poche de gaz, jaune


# =================================================================== builders
def base_rgba():
    a = np.zeros((32, 32, 4), np.uint8)
    a[:, :, 3] = 255
    return a


def build_land():
    """TUNNEL : sol circulable."""
    a = base_rgba()
    for r, k in [('light', 'land_light'), ('base', 'land_base'), ('dark', 'land_dark')]:
        a[:, :, :3][LAND_ROLE == r] = P7[k]
    return a


def build_coast():
    """BORD DE TUNNEL : genere automatiquement par buildIslandTiles."""
    a = base_rgba()
    for r, k in [('light', 'coast_light'), ('base', 'coast_base'),
                 ('dark', 'coast_dark'), ('spark', 'coast_spark')]:
        a[:, :, :3][COAST_ROLE == r] = P7[k]
    return a


def build_coast_tri(d):
    a = build_coast()
    land = build_land()
    a[TRI[d]] = land[TRI[d]]
    return a


def build_water():
    """ROCHE PLEINE : l'equivalent de la mer. Masse continue, non traversable.
    Reutilise le bruit procedural de l'eau -> texture dense sans motif."""
    a = base_rgba()
    a[:, :, :3] = np.clip(np.array(P7['water_base'], int) + WATER_D, 0, 255)
    # veinage mineral : quelques stries plus claires, deterministe
    rng = np.random.RandomState(7017)
    for _ in range(14):
        x0, y0 = rng.randint(0, 32), rng.randint(0, 32)
        ln = rng.randint(3, 7)
        for i in range(ln):
            x, y = (x0 + i) % 32, (y0 + i // 2) % 32
            a[y, x, :3] = np.clip(a[y, x, :3].astype(int) + 16, 0, 255)
    return a


def build_obstacle():
    """EBOULIS : blocs detaches, degageables."""
    a = build_land()
    for y in range(32):
        for x in range(32):
            if ROCK_DIFF[y, x] and ROCK_ROLE[y, x]:
                a[y, x, :3] = P7['rock_' + ROCK_ROLE[y, x]]
    return a


def build_resource():
    """VEINE : minerai dans le sol du tunnel."""
    a = build_land()
    lo, hi = np.array(ORE_LO, float), np.array(ORE_HI, float)
    for y in range(32):
        for x in range(32):
            if ORE_DIFF[y, x]:
                a[y, x, :3] = np.clip(lo + (hi - lo) * ORE_T[y, x], 0, 255)
    return a


def build_oil():
    """POCHE DE GAZ : gisement revele par la Foreuse (Excel L79).
    Reutilise le masque de flaque de tile_i3_oil, en jaune gazeux + bulles."""
    a = build_land()
    lo, hi = np.array(GAS_LO, float), np.array(GAS_HI, float)
    for y in range(32):
        for x in range(32):
            if OIL_DIFF[y, x]:
                a[y, x, :3] = np.clip(lo + (hi - lo) * OIL_T[y, x], 0, 255)
    # bulles de gaz : le tell qui distingue du petrole (qui est une flaque lisse)
    rng = np.random.RandomState(4211)
    ys, xs = np.where(OIL_DIFF)
    for _ in range(16):
        i = rng.randint(len(xs))
        x, y = int(xs[i]), int(ys[i])
        if 1 <= x < 31 and 1 <= y < 31 and OIL_DIFF[y, x]:
            a[y, x, :3] = hx('#E8DC8C')
    return a


def build_wall_fill():
    """ROCHE PLEINE variante 'bloc' : version avec liseré, pour les zones
    ou l'on veut lire la maille (compatibilite avec tile_i7_wall livre en v1.0)."""
    a = build_water()
    edge = (np.array(P7['water_base'], int) * 0.6).astype(int)
    a[0, :, :3] = edge; a[31, :, :3] = edge
    a[:, 0, :3] = edge; a[:, 31, :3] = edge
    return a


def build_gas_hidden():
    """POCHE NON REVELEE : identique a la roche pleine.
    Le brief (§8) dit que les poches sont CACHEES et qu'on perd l'affordance
    'la tuile clignote'. Ce sprite existe pour que le moteur puisse stocker un
    terrain 'gaz' distinct SANS le montrer : visuellement = roche pleine.
    Une fois foree, on bascule sur tile_i7_oil."""
    return build_water()


if __name__ == '__main__':
    made = []
    made.append(save(build_land(),      'tile_i7_land.png'))
    made.append(save(build_coast(),     'tile_i7_coast.png'))
    for d in ['ne', 'nw', 'se', 'sw']:
        made.append(save(build_coast_tri(d), f'tile_i7_coast_tri_{d}.png'))
    made.append(save(build_water(),     'tile_i7_water.png'))
    made.append(save(build_obstacle(),  'tile_i7_obstacle.png'))
    made.append(save(build_resource(),  'tile_i7_resource.png'))
    made.append(save(build_oil(),       'tile_i7_oil.png'))
    made.append(save(build_gas_hidden(),'tile_i7_gaz_cache.png'))
    made.append(save(build_wall_fill(), 'tile_i7_wall.png'))
    print('\n'.join(made))
