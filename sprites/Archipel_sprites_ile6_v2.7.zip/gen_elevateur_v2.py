#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - ELEVATEUR ile 6 (v2)

Correction de cadrage :
  - SURFACE   = TUILE vue de DESSUS, opaque, plein cadre 32x32
                (meme traitement que tile_port_terre : c'est du terrain amenage,
                 pas un batiment pose dessus)
                -> tile_i6_elevateur.png / tile_i6_elevateur_casse.png
  - SOUTERRAIN = BATIMENT vue de COTE, fond transparent
                (meme traitement que mine_fer_v1 / bat_pompe_eau)
                -> bat_elevateur.png / bat_elevateur_casse.png

Elevateur classique : cage + treuil + contrepoids. Pas de chevalement minier.
Palette officielle : contour #161A22, inox #404652->#A5A8B2, trim #FF9628,
accent cyan #4FC3F7.
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)

def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)

OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
ORA  = hx('#FF9628')
ORAD = hx('#C46A12')
CYAN = hx('#4FC3F7')
CYAD = hx('#2A7FA8')
RUST = hx('#7A4A32')
RUSD = hx('#4E2F20')
RUSL = hx('#9C6244')
DARK = hx('#0D1016')
GLOW = hx('#F5C56A')
GLOD = hx('#8A6A2E')

# sol i6 (surface) pour la tuile opaque
I6_L, I6_B, I6_D = hx('#6E6A72'), hx('#5C5962'), hx('#4A4851')


class Cv:
    def __init__(s, w=32, h=32, bg=None):
        s.a = np.zeros((h, w, 4), np.uint8)
        if bg:
            s.a[:, :] = bg

    def px(s, x, y, c):
        if 0 <= x < 32 and 0 <= y < 32:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


# =================================================================== SURFACE
# TUILE VUE DE DESSUS - on regarde la cage d'elevateur par le haut :
# dalle beton carree, cadre metallique, toit de cabine centre, rails lateraux.
def surface(repaired=True):
    c = Cv(bg=I6_B)

    # --- dalle beton amenagee (plein cadre, comme tile_port_terre)
    c.rect(0, 0, 31, 31, hx('#6A6770'))
    # damier de dalle
    for y in range(0, 32, 2):
        for x in range(0, 32, 2):
            if (x // 2 + y // 2) % 2 == 0:
                c.rect(x, y, x + 1, y + 1, hx('#625F68'))
    # bordure de dalle
    c.frame(0, 0, 31, 31, hx('#4A4851'))
    c.frame(1, 1, 30, 30, hx('#7A7680'))

    # --- marquage de securite au sol (hachures orange sur 2 cotes)
    for x in range(3, 29):
        if (x // 2) % 2 == 0:
            c.px(x, 3, ORA if repaired else RUST)
            c.px(x, 28, ORA if repaired else RUST)

    # --- cadre de la cage (carre metallique central)
    c.rect(6, 6, 25, 25, D2)
    c.frame(6, 6, 25, 25, OUTL)
    c.frame(7, 7, 24, 24, M2)

    # --- rails lateraux (2 bandes verticales)
    c.rect(8, 8, 9, 23, M1)
    c.rect(22, 8, 23, 23, M1)
    c.vline(8, 8, 23, L1)
    c.vline(23, 8, 23, L1)

    if repaired:
        # --- toit de cabine vu de dessus
        c.rect(11, 10, 20, 21, M2)
        c.frame(11, 10, 20, 21, OUTL)
        c.frame(12, 11, 19, 20, L2)
        # trappe centrale + panneaux
        c.rect(13, 13, 18, 18, D1)
        c.frame(13, 13, 18, 18, D0)
        c.hline(14, 17, 15, M1)
        c.hline(14, 17, 16, M1)
        # temoin cyan (cabine operationnelle)
        c.px(15, 15, CYAN); c.px(16, 15, CYAN)
        c.px(15, 16, CYAD); c.px(16, 16, CYAD)
        # trim orange 1px (signature V2)
        c.hline(11, 20, 12, ORA)
        c.hline(11, 20, 19, ORAD)
        # treuil / poulies en haut de cage
        c.rect(11, 7, 20, 8, D1)
        c.px(13, 7, L3); c.px(18, 7, L3)
        c.px(13, 8, M2); c.px(18, 8, M2)
        # gyrophares aux angles de la dalle
        for (gx, gy) in [(4, 5), (27, 5), (4, 26), (27, 26)]:
            c.px(gx, gy, ORA)
            c.px(gx, gy - 1, hx('#FFC97A'))
        # bornes de commande
        c.rect(27, 12, 29, 16, D2)
        c.frame(27, 12, 29, 16, OUTL)
        c.px(28, 13, CYAN); c.px(28, 15, ORA)
        c.rect(2, 12, 4, 16, D2)
        c.frame(2, 12, 4, 16, OUTL)
        c.px(3, 13, CYAN)
    else:
        # --- cage vide : on voit le fond du puits (trou noir)
        c.rect(10, 9, 21, 22, DARK)
        c.frame(10, 9, 21, 22, D0)
        # rails tordus / arraches
        c.px(9, 12, RUSD); c.px(9, 13, RUST)
        c.px(22, 17, RUSD); c.px(22, 18, RUST)
        # poutres effondrees en travers du trou
        for i, x in enumerate(range(11, 21)):
            c.px(x, 13 + (i // 4), RUST)
            c.px(x, 14 + (i // 4), RUSD)
        c.px(14, 19, RUSD); c.px(17, 20, RUSD); c.px(12, 18, RUST)
        # rouille sur le cadre
        for (rx, ry) in [(7, 9), (24, 14), (7, 20), (24, 22), (13, 6), (19, 25)]:
            c.px(rx, ry, RUSD)
        # dalle fissuree
        for i, y in enumerate(range(4, 10)):
            c.px(3 + i, y, hx('#4A4851'))
        for i, y in enumerate(range(22, 28)):
            c.px(28 - i, y, hx('#4A4851'))
        # gravats sur la dalle
        for (gx, gy) in [(4, 20), (5, 21), (27, 9), (26, 8), (28, 20)]:
            c.px(gx, gy, hx('#565266'))
    return c


# ================================================================ SOUTERRAIN
# BATIMENT VUE DE COTE, fond transparent : on voit la cabine dans sa cage,
# arrivee du puits par le haut, portes au niveau du sol.
def souterrain(repaired=True):
    c = Cv()

    # --- gaine / cage verticale (structure porteuse)
    # montants
    c.rect(8, 2, 9, 27, D2)
    c.rect(22, 2, 23, 27, D2)
    c.vline(8, 2, 27, OUTL)
    c.vline(23, 2, 27, OUTL)
    c.vline(9, 3, 26, M1)
    c.vline(22, 3, 26, M1)
    # traverses de gaine
    for y in [5, 11, 17, 23]:
        c.hline(10, 21, y, D1)
        c.px(10, y, M1); c.px(21, y, M1)

    # --- linteau superieur (arrivee du puits)
    c.rect(6, 0, 25, 3, M2)
    c.hline(6, 25, 0, OUTL)
    c.hline(6, 25, 1, L2)
    c.vline(6, 0, 3, OUTL)
    c.vline(25, 0, 3, OUTL)
    c.hline(6, 25, 4, D1)

    if repaired:
        # --- treuil + cable
        c.rect(13, 1, 18, 3, D1)
        c.px(14, 2, L3); c.px(17, 2, L3)
        c.px(15, 2, CYAN); c.px(16, 2, CYAN)
        c.vline(15, 4, 12, M1)
        c.vline(16, 4, 12, D1)

        # --- contrepoids (colonne laterale)
        c.rect(10, 6, 11, 11, M2)
        c.frame(10, 6, 11, 11, OUTL)
        c.px(10, 7, L2); c.px(10, 9, L2)
        c.vline(11, 4, 6, D1)

        # --- CABINE au niveau du sol
        c.rect(12, 13, 20, 26, M2)
        c.frame(12, 13, 20, 26, OUTL)
        # volume : lumiere a gauche, ombre a droite
        c.vline(13, 14, 25, L2)
        c.vline(14, 14, 25, L1)
        c.vline(19, 14, 25, D2)
        c.hline(13, 19, 14, L2)
        c.hline(13, 19, 25, D1)
        # trim orange (signature V2)
        c.hline(12, 20, 16, ORA)
        c.px(12, 16, ORAD); c.px(20, 16, ORAD)
        # portes coulissantes ouvertes
        c.rect(14, 18, 18, 25, D1)
        c.frame(14, 18, 18, 25, D0)
        c.vline(16, 18, 25, M1)   # jointure centrale
        # interieur eclaire
        c.rect(15, 19, 15, 24, hx('#3A3F4A'))
        c.rect(17, 19, 17, 24, hx('#3A3F4A'))
        c.px(15, 20, GLOW); c.px(17, 20, GLOW)
        # afficheur d'etage
        c.rect(14, 15, 18, 15, D0)
        c.px(15, 15, CYAN); c.px(16, 15, CYAN); c.px(17, 15, CYAD)
        # feux de gaine
        c.px(9, 8, GLOW); c.px(22, 14, GLOW); c.px(9, 20, GLOW)

        # --- quai / seuil au sol
        c.rect(3, 26, 28, 29, D2)
        c.hline(3, 28, 26, M1)
        c.hline(3, 28, 30, OUTL)
        c.vline(2, 26, 30, OUTL)
        c.vline(29, 26, 30, OUTL)
        c.hline(3, 28, 25, OUTL)
        # bande d'avertissement orange
        for x in range(4, 28):
            if (x // 2) % 2 == 0:
                c.px(x, 28, ORA)
        # borne d'appel
        c.rect(4, 21, 6, 25, D2)
        c.frame(4, 21, 6, 25, OUTL)
        c.px(5, 22, CYAN); c.px(5, 24, ORA)
        # caisse / conteneur (indique le transit de fret)
        c.rect(24, 20, 28, 25, D1)
        c.frame(24, 20, 28, 25, OUTL)
        c.hline(25, 27, 22, M2)
        c.px(26, 23, ORA)
    else:
        # --- gaine vide : cage beante, cabine absente
        c.rect(10, 5, 21, 25, DARK)
        # rails tordus
        for i, y in enumerate(range(6, 16)):
            c.px(12 + (i % 3), y, RUSD)
        for i, y in enumerate(range(10, 20)):
            c.px(19 - (i % 3), y, RUSD)
        # cable rompu qui pend
        c.vline(15, 4, 9, RUST)
        c.px(15, 10, RUSD); c.px(16, 11, RUSD); c.px(16, 12, RUST)
        # poutres effondrees en travers
        for i, x in enumerate(range(11, 21)):
            c.px(x, 17 + (i // 5), RUST)
            c.px(x, 18 + (i // 5), RUSD)
        # rouille sur les montants
        for (rx, ry) in [(9, 7), (9, 15), (22, 9), (22, 21), (9, 24), (22, 5)]:
            c.px(rx, ry, RUSD)
            c.px(rx, ry + 1, RUST)
        # eboulis au pied de la gaine
        c.rect(10, 22, 21, 25, hx('#2A231D'))
        for (gx, gy) in [(12, 23), (16, 22), (19, 24), (14, 25), (18, 23)]:
            c.px(gx, gy, hx('#4C423A'))
        c.px(13, 24, RUSL); c.px(17, 25, RUSL)

        # --- seuil abime
        c.rect(3, 26, 28, 29, D1)
        c.hline(3, 28, 26, M1)
        c.hline(3, 28, 30, OUTL)
        c.vline(2, 26, 30, OUTL)
        c.vline(29, 26, 30, OUTL)
        c.hline(3, 28, 25, OUTL)
        # fissures + gravats
        c.px(7, 27, hx('#2A231D')); c.px(8, 28, hx('#2A231D'))
        c.px(24, 27, hx('#2A231D')); c.px(25, 28, hx('#2A231D'))
        for (gx, gy) in [(5, 27), (26, 28), (6, 29)]:
            c.px(gx, gy, hx('#4C423A'))
        # marquage efface
        for x in range(4, 28, 6):
            c.px(x, 28, RUSD)
    return c


if __name__ == '__main__':
    made = []
    made.append(surface(True).save('tile_i6_elevateur.png'))
    made.append(surface(False).save('tile_i6_elevateur_casse.png'))
    made.append(souterrain(True).save('bat_elevateur.png'))
    made.append(souterrain(False).save('bat_elevateur_casse.png'))
    # nettoyage des noms v1 obsoletes
    for old in ['bat_elevateur_bas.png', 'bat_elevateur_bas_casse.png']:
        p = os.path.join(OUT, old)
        if os.path.exists(p):
            os.remove(p)
    print('\n'.join(made))
