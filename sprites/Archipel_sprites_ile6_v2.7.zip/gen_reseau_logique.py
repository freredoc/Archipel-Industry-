#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - 4e reseau : LOGIQUE BOOLEENNE (ile 6)
=========================================================

Convention de nommage relevee sur les 3 reseaux existants :
    <reseau>_v<N>_<BB>_<DIRS>.png
ou BB est un masque 4 bits en decimal, 2 chiffres, et DIRS la liste des
directions. Bits : N=1, E=2, S=4, O=8.
    00_iso · 01_N · 02_E · 03_NE · 04_S · 05_NS · 06_ES · 07_NES
    08_O · 09_NO · 10_EO · 11_NEO · 12_SO · 13_NSO · 14_ESO · 15_NESO

Largeur de trace, par ordre de "poids" du reseau (releve sur les sprites) :
    route  : 10 px (x=11..20)
    tuyau  :  6 px (x=13..18)
    cable  :  4 px (x=14..17)
    fil    :  2 px (x=15..16)   <- le plus fin, c'est de la SIGNALISATION
Le fil logique ne transporte pas de matiere ni de puissance : il doit se lire
comme secondaire, pose PAR-DESSUS le reste.

CODE COULEUR (demande explicite)
--------------------------------
    NOIR  = 0   (#1A1A1E, faux)
    BLANC = 1   (#F0F0F4, vrai)
Le fil existe donc en DEUX etats visuels par variante : etat bas et etat haut.
C'est le seul reseau du jeu ou l'etat se lit sur le sprite lui-meme - les trois
autres n'ont qu'un rendu.

Le boitier de tout composant logique est neutre (inox #2A303C..#8C93A0) pour ne
pas entrer en conflit avec le noir/blanc du signal : seuls les PORTS et la
DIODE d'etat portent la couleur du signal.

CONTENU
-------
  fil_logique_v1_XX_*        16 variantes, etat 0 (noir)
  fil_logique_v1_XX_*_on     16 variantes, etat 1 (blanc)
  logic_senseur_<type>       5 senseurs (plein / vide / contient / deficit / saveur)
  logic_porte_<type>         5 portes  (AND / OR / NOT / XOR / NAND)
  logic_sortie_collisionneur 3 sorties (le collisionneur expose 3 canaux)
  logic_entree_datacenter    1 entree  (le data center consomme 1 canal)
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


# ---- signal : le coeur du code couleur
SIG_OFF  = hx('#1A1A1E')     # NOIR  = 0
SIG_ON   = hx('#F0F0F4')     # BLANC = 1
SIG_OFF_D = hx('#0C0C10')    # ombre du noir
SIG_ON_D = hx('#A8ACB8')     # ombre du blanc

# ---- boitier neutre, langage officiel des batiments
OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
ORA  = hx('#FF9628')         # trim V2
CYAN = hx('#4FC3F7')
QUAN = hx('#B47CFF')         # quantique (collisionneur / data center)
GOLD = hx('#BEA046')
GRN  = hx('#78D26E')
RED  = hx('#E05A4A')


class Cv:
    def __init__(s, w=32, h=32):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2):
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, OUTL)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


# =============================================================== FIL LOGIQUE
# Trace de 2 px (x=15,16) avec 1 px de gaine sombre de chaque cote -> 4 px au
# total, mais le CONDUCTEUR visible ne fait que 2 px : plus fin que le cable
# electrique, conforme a son role de signalisation.
SHEATH = hx('#3A3E48')


def wire(bits, on):
    """bits : masque N=1 E=2 S=4 O=8. on : True = signal a 1 (blanc).

    Empreinte de 5 px (x=14..18) : conducteur de 3 px encadre par 1 px de gaine.
    Reste sous le cable electrique (route 10 / tuyau 6 / cable 4 ... le fil est
    a 5 avec un conducteur plus large, donc lisible sans dominer) mais devient
    assez epais pour que l'etat 0/1 se lise d'un coup d'oeil en jeu.
    """
    c = Cv()
    core = SIG_ON if on else SIG_OFF
    edge = SIG_ON_D if on else SIG_OFF_D

    def seg_v(y0, y1):
        c.vline(14, y0, y1, SHEATH)
        c.vline(18, y0, y1, SHEATH)
        c.vline(15, y0, y1, edge)
        c.vline(16, y0, y1, core)
        c.vline(17, y0, y1, edge)

    def seg_h(x0, x1):
        c.hline(x0, x1, 14, SHEATH)
        c.hline(x0, x1, 18, SHEATH)
        c.hline(x0, x1, 15, edge)
        c.hline(x0, x1, 16, core)
        c.hline(x0, x1, 17, edge)

    if bits & 1:  seg_v(0, 18)      # N
    if bits & 4:  seg_v(14, 31)     # S
    if bits & 8:  seg_h(0, 18)      # O
    if bits & 2:  seg_h(14, 31)     # E

    if bits == 0:
        # isole : plot avec diode d'etat
        c.rect(13, 13, 19, 19, D1)
        c.frame(13, 13, 19, 19, OUTL)
        c.rect(15, 15, 17, 17, core)
        c.px(16, 16, hx('#FFFFFF') if on else SIG_OFF_D)
        return c

    # noeud central : re-affirme le coeur pour que les croisements restent nets
    c.rect(15, 15, 17, 17, core)
    n = bin(bits).count('1')
    if n >= 3:
        for (dx, dy) in [(14, 14), (18, 14), (14, 18), (18, 18)]:
            c.px(dx, dy, SHEATH)
    return c


DIRS = {1: 'N', 2: 'E', 4: 'S', 8: 'O'}


def wire_name(bits, on):
    if bits == 0:
        base = 'fil_logique_v1_00_iso'
    else:
        tag = ''.join(DIRS[b] for b in (1, 2, 4, 8) if bits & b)
        base = f'fil_logique_v1_{bits:02d}_{tag}'
    return base + ('_on' if on else '') + '.png'


# ================================================================= SENSEURS
def _sensor_body(c, accent, out_side='s'):
    """Chassis CARRE : boitier 24x24 + diode d'etat + port de SORTIE orientable.

    Un senseur ne fait que PRODUIRE un signal (pas d'entree), donc un seul port,
    blanc et fleche. Le corps etant carre, le port peut etre place sur n'importe
    lequel des 4 bords sans decaler le boitier.
    """
    square_body(c, inner_inset=2)
    # diode d'etat (montre le resultat du test)
    c.rect(23, 6, 25, 7, accent)
    port(c, out_side)
    return c


def sensor_plein(out_side='s'):
    """Vrai si le stock est plein. Icone : cuve remplie."""
    c = Cv(); _sensor_body(c, GRN, out_side)
    c.rect(11, 11, 20, 22, D0)
    c.frame(11, 11, 20, 22, M1)
    c.rect(12, 12, 19, 21, GRN)            # rempli a 100%
    c.hline(12, 19, 12, hx('#A8E89E'))
    return c


def sensor_vide(out_side='s'):
    """Vrai si le stock est vide. Icone : cuve vide + fond visible."""
    c = Cv(); _sensor_body(c, RED, out_side)
    c.rect(11, 11, 20, 22, D0)
    c.frame(11, 11, 20, 22, M1)
    c.hline(12, 19, 21, RED)               # residu au fond
    c.px(12, 20, hx('#F08A7A')); c.px(19, 20, hx('#F08A7A'))
    return c


def sensor_contient(out_side='s'):
    """Vrai si contient la ressource X. Icone : loupe sur un item."""
    c = Cv(); _sensor_body(c, CYAN, out_side)
    # item generique
    c.rect(9, 12, 16, 19, M1)
    c.frame(9, 12, 16, 19, D0)
    c.hline(10, 15, 13, L2)
    # loupe
    for y in range(32):
        for x in range(32):
            d = ((x - 19) ** 2 + (y - 17) ** 2) ** 0.5
            if 3.2 <= d <= 4.4:
                c.px(x, y, CYAN)
    c.px(22, 20, CYAN); c.px(23, 21, CYAN)
    return c


def sensor_deficit(out_side='s'):
    """Vrai si production < consommation. Icone : jauge sous le seuil."""
    c = Cv(); _sensor_body(c, ORA, out_side)
    # barre de niveau + curseur de seuil
    c.rect(10, 15, 21, 19, D0)
    c.frame(10, 15, 21, 19, M1)
    c.rect(11, 16, 14, 18, ORA)            # niveau bas
    c.vline(17, 12, 21, hx('#FFC97A'))     # seuil
    c.px(17, 11, hx('#FFC97A'))
    # fleche descendante
    c.px(20, 11, ORA); c.px(20, 12, ORA)
    c.px(19, 12, ORA); c.px(21, 12, ORA)
    return c


def sensor_saveur(out_side='s'):
    """Vrai si l'information quantique a la saveur X.
    Icone : 3 pastilles de couleurs = les saveurs, une seule active."""
    c = Cv(); _sensor_body(c, QUAN, out_side)
    cols = [CYAN, QUAN, GOLD]
    for i, col in enumerate(cols):
        x = 9 + i * 5
        c.rect(x, 13, x + 3, 17, D0)
        c.frame(x, 13, x + 3, 17, M1)
        if i == 1:                          # celle qui matche
            c.rect(x + 1, 14, x + 2, 16, col)
        else:
            c.px(x + 1, 15, hx('#3E444E'))
    c.hline(9, 22, 20, D0)
    c.px(16, 21, QUAN)
    return c


# ============================================================ GEOMETRIE CARREE
# Tous les composants logiques partagent un CORPS CARRE de 24x24 centre dans la
# tuile (x=4..27, y=4..27). Les 4 px de marge de chaque cote accueillent les
# ports, quelle que soit leur orientation.
#
# Pourquoi carre : le joueur doit pouvoir faire pivoter un composant pour
# orienter sa sortie vers N/E/S/O. Avec un corps rectangulaire, la rotation
# decale le centre optique et les ports ne tombent plus en face du fil.
# Un carre pivote sur lui-meme sans rien casser.
BODY = (4, 4, 27, 27)          # x0, y0, x1, y1


def square_body(c, inner_inset=3):
    """Boitier carre standard : cadre + trim orange + zone interieure."""
    x0, y0, x1, y1 = BODY
    c.box(x0, y0, x1, y1, M2, L2, D2)
    c.hline(x0, x1, y0 + 1, ORA)                       # trim V2
    i = inner_inset
    c.rect(x0 + i, y0 + i + 1, x1 - i, y1 - i, D1)
    c.frame(x0 + i, y0 + i + 1, x1 - i, y1 - i, D0)
    return (x0 + i + 1, y0 + i + 2, x1 - i - 1, y1 - i - 1)   # zone utile


# --- ports de SORTIE orientables ---------------------------------------------
# IMPORTANT : le reseau logique se branche comme les 3 autres reseaux, c'est-a-dire
# PAR ADJACENCE (netConnectMask + bitmask de voisinage). Il n'y a donc AUCUN port
# d'entree a dessiner : un fil pose contre un composant est connecte, point.
#
# Seule la SORTIE est materialisee, parce qu'elle porte une information que
# l'adjacence ne donne pas : de quel cote le composant EMET. C'est ce que le
# joueur doit pouvoir orienter.
#
# offset permet de decaler le port le long du bord (3 sorties du collisionneur).

def port(c, side, offset=0):
    """Dessine un port de SORTIE sur le bord 'side' (n/e/s/o)."""
    out = True
    core = SIG_ON
    edge = SIG_ON_D
    tip = hx('#FFFFFF')
    half = 4

    if side in ('n', 's'):
        cx = 16 + offset
        if side == 'n':
            c.rect(cx - half, 0, cx + half, 4, SHEATH)
            c.frame(cx - half, 0, cx + half, 4, OUTL)
            c.rect(cx - half + 1, 1, cx + half - 1, 3, D0)
            c.vline(cx, 0, 4, core)
            c.vline(cx - 1, 1, 4, edge); c.vline(cx + 1, 1, 4, edge)
            c.px(cx - 1, 1, core); c.px(cx + 1, 1, core)       # pointe ^
            c.px(cx - 2, 2, core); c.px(cx + 2, 2, core)
            c.px(cx, 0, tip)
        else:
            c.rect(cx - half, 27, cx + half, 31, SHEATH)
            c.frame(cx - half, 27, cx + half, 31, OUTL)
            c.rect(cx - half + 1, 28, cx + half - 1, 30, D0)
            c.vline(cx, 27, 31, core)
            c.vline(cx - 1, 27, 30, edge); c.vline(cx + 1, 27, 30, edge)
            c.px(cx - 1, 30, core); c.px(cx + 1, 30, core)
            c.px(cx - 2, 29, core); c.px(cx + 2, 29, core)
            c.px(cx, 31, tip)
    else:
        cy = 16 + offset
        if side == 'o':
            c.rect(0, cy - half, 4, cy + half, SHEATH)
            c.frame(0, cy - half, 4, cy + half, OUTL)
            c.rect(1, cy - half + 1, 3, cy + half - 1, D0)
            c.hline(0, 4, cy, core)
            c.hline(1, 4, cy - 1, edge); c.hline(1, 4, cy + 1, edge)
            c.px(1, cy - 1, core); c.px(1, cy + 1, core)
            c.px(2, cy - 2, core); c.px(2, cy + 2, core)
            c.px(0, cy, tip)
        else:
            c.rect(27, cy - half, 31, cy + half, SHEATH)
            c.frame(27, cy - half, 31, cy + half, OUTL)
            c.rect(28, cy - half + 1, 30, cy + half - 1, D0)
            c.hline(27, 31, cy, core)
            c.hline(27, 30, cy - 1, edge); c.hline(27, 30, cy + 1, edge)
            c.px(30, cy - 1, core); c.px(30, cy + 1, core)
            c.px(29, cy - 2, core); c.px(29, cy + 2, core)
            c.px(31, cy, tip)


# ================================================================== PORTES
# Les portes portent leur NOM ECRIT (AND / OR / NOT / XOR / NAND) avec la police
# officielle du jeu (font/maj_*.png, 8x8, glyphes de 5 px utiles en #EBEEF5).
# A 32 px, un symbole electronique seul n'est pas assez discriminant - surtout
# AND vs NAND, qui ne different que par la bulle. Le texte leve toute ambiguite.

FONT_DIR = 'font'
_GLYPH_CACHE = {}


def glyph(ch):
    """Charge un glyphe de la police officielle et le recadre a sa largeur utile."""
    if ch in _GLYPH_CACHE:
        return _GLYPH_CACHE[ch]
    # la police officielle couvre tout l'alphabet : on mappe directement
    a = np.array(Image.open(f'{FONT_DIR}/maj_{ch.lower()}.png').convert('RGBA'))
    cols = [x for x in range(8) if (a[:, x, 3] > 0).any()]
    rows = [y for y in range(8) if (a[y, :, 3] > 0).any()]
    sub = a[rows[0]:rows[-1] + 1, cols[0]:cols[-1] + 1]
    _GLYPH_CACHE[ch] = sub
    return sub


def text_width(s, spacing=1):
    return sum(glyph(c).shape[1] for c in s) + spacing * (len(s) - 1)


def draw_text(c, s, x, y, color, spacing=1):
    """Dessine une chaine en recolorant les pixels opaques de la police."""
    cx = x
    for ch in s:
        g = glyph(ch)
        h, w = g.shape[:2]
        for gy in range(h):
            for gx in range(w):
                if g[gy, gx, 3] > 0:
                    c.px(cx + gx, y + gy, color)
        cx += w + spacing
    return cx


OPPOSITE_S = {'n': 's', 's': 'n', 'e': 'o', 'o': 'e'}


def _gate_body(c, label, ins=None, out_side='e'):
    """Chassis carre des portes.

    Corps CARRE 24x24 -> la porte pivote sans que le boitier ne se decale.

    Aucune entree n'est dessinee : comme pour la route, le tuyau et le cable,
    le raccordement se fait par ADJACENCE. Un fil colle a la porte est connecte.
    Seule la sortie est materialisee, parce qu'elle indique de quel cote la
    porte emet - information que l'adjacence ne peut pas donner.
    """
    square_body(c, inner_inset=2)
    port(c, out_side)

    # nom de la porte, centre dans le corps carre
    sp = 0 if len(label) >= 4 else 1
    w = text_width(label, sp)
    x0 = 4 + (24 - w) // 2
    draw_text(c, label, x0, 14, hx('#EBEEF5'), sp)
    return c


# Les 8 portes booleennes standard.
#
# Une porte a 2 entrees a 16 tables de verite possibles, mais seules 8 ont un
# nom et un symbole normalises en electronique. Les 8 autres sont soit des
# constantes (toujours 0, toujours 1), soit de simples passe-plats (A, B, NOT A,
# NOT B), soit des variantes asymetriques (IMPLY, NIMPLY) qui n'ont pas de
# glyphe standard et dont le label ne tient pas dans 24 px. On s'en tient donc
# au jeu canonique, qui est fonctionnellement complet (NAND seul suffit a tout
# reconstruire).
#
# La BULLE blanche sur le port de sortie marque l'inversion : c'est la
# convention electronique reelle, et elle relie visuellement chaque porte a sa
# duale (AND/NAND, OR/NOR, XOR/XNOR, BUF/NOT).

def _bubble(c, out_side):
    """Bulle d'inversion, posee juste en retrait du port de sortie."""
    if out_side == 'e':
        x0, y0 = 23, 14
        c.rect(x0, y0, x0 + 2, y0 + 4, SIG_ON)
        c.frame(x0, y0, x0 + 2, y0 + 4, OUTL)
        c.px(x0 + 1, y0 + 1, hx('#FFFFFF'))
    elif out_side == 'o':
        x0, y0 = 6, 14
        c.rect(x0, y0, x0 + 2, y0 + 4, SIG_ON)
        c.frame(x0, y0, x0 + 2, y0 + 4, OUTL)
        c.px(x0 + 1, y0 + 1, hx('#FFFFFF'))
    elif out_side == 's':
        x0, y0 = 14, 23
        c.rect(x0, y0, x0 + 4, y0 + 2, SIG_ON)
        c.frame(x0, y0, x0 + 4, y0 + 2, OUTL)
        c.px(x0 + 1, y0 + 1, hx('#FFFFFF'))
    else:
        x0, y0 = 14, 6
        c.rect(x0, y0, x0 + 4, y0 + 2, SIG_ON)
        c.frame(x0, y0, x0 + 4, y0 + 2, OUTL)
        c.px(x0 + 1, y0 + 1, hx('#FFFFFF'))


def gate_and(out_side='e'):
    """AND : 1 seulement si les DEUX entrees sont a 1."""
    c = Cv(); _gate_body(c, 'AND', out_side=out_side)
    return c


def gate_or(out_side='e'):
    """OR : 1 si AU MOINS UNE entree est a 1."""
    c = Cv(); _gate_body(c, 'OR', out_side=out_side)
    return c


def gate_xor(out_side='e'):
    """XOR : 1 si les entrees DIFFERENT."""
    c = Cv(); _gate_body(c, 'XOR', out_side=out_side)
    return c


def gate_nand(out_side='e'):
    """NAND : inverse de AND. Fonctionnellement complet a lui seul."""
    c = Cv(); _gate_body(c, 'NAND', out_side=out_side)
    _bubble(c, out_side)
    return c


def gate_nor(out_side='e'):
    """NOR : inverse de OR. Egalement complet a lui seul."""
    c = Cv(); _gate_body(c, 'NOR', out_side=out_side)
    _bubble(c, out_side)
    return c


def gate_xnor(out_side='e'):
    """XNOR : inverse de XOR -> 1 si les entrees sont EGALES.
    C'est le comparateur : indispensable pour tester une saveur."""
    c = Cv(); _gate_body(c, 'XNOR', out_side=out_side)
    _bubble(c, out_side)
    return c


def gate_not(out_side='e'):
    """NOT : inverseur a 1 entree."""
    c = Cv(); _gate_body(c, 'NOT', out_side=out_side)
    _bubble(c, out_side)
    return c


def gate_buf(out_side='e'):
    """BUF : suiveur a 1 entree, recopie le signal.

    Utile en jeu meme s'il ne calcule rien : il sert de RELAIS pour retarder un
    signal d'un tick, casser une boucle de retroaction, ou simplement forcer une
    direction de propagation dans un croisement dense."""
    c = Cv(); _gate_body(c, 'BUF', out_side=out_side)
    return c


# ============================== CONNECTEURS COLLISIONNEUR / DATA CENTER
# Les 4 rotations du collisionneur. Le collisionneur a 3 sorties reparties sur
# 3 COTES DIFFERENTS (pas 3 ports sur un meme bord) : le 4e cote reste libre
# pour l'alimentation / l'acces. 'rot' fait tourner l'ensemble d'un quart de
# tour, donc le cote libre se deplace.
ROT_SIDES = {
    'n': ('e', 's', 'o'),      # cote libre = n
    'e': ('s', 'o', 'n'),      # cote libre = e
    's': ('o', 'n', 'e'),      # cote libre = s
    'o': ('n', 'e', 's'),      # cote libre = o
}


def sortie_collisionneur(free_side='o'):
    """3 SORTIES sur 3 COTES DIFFERENTS.

    Le collisionneur expose 3 canaux logiques distincts. Plutot que de les
    empiler sur un meme bord, chacun sort sur son propre cote : c'est plus
    lisible en jeu (3 fils qui partent dans 3 directions) et ca evite d'avoir
    a distinguer 3 ports voisins identiques.

    'free_side' est le cote SANS sortie - celui qu'on laisse a l'alimentation.
    Faire varier free_side revient a tourner le batiment d'un quart de tour.

    Chaque canal est indexe par 1/2/3 diodes violettes cote interieur.
    """
    c = Cv()
    square_body(c, inner_inset=2)
    # coeur quantique : c'est bien le collisionneur qui parle
    c.rect(10, 11, 21, 22, QUAN)
    c.rect(11, 12, 20, 21, hx('#6E4AA8'))
    c.px(14, 15, hx('#E0D0FF')); c.px(15, 16, hx('#E0D0FF'))
    for i, side in enumerate(ROT_SIDES[free_side]):
        port(c, side)
        # index du canal : 1, 2 puis 3 diodes, juste en retrait du port
        for k in range(i + 1):
            d = k * 2 - i          # centre les diodes
            if side == 'e':
                c.px(23, 16 + d, QUAN)
            elif side == 'o':
                c.px(8, 16 + d, QUAN)
            elif side == 's':
                c.px(16 + d, 23, QUAN)
            else:
                c.px(16 + d, 8, QUAN)
    return c


def entree_datacenter(_side=None):
    """Data center : AUCUN port dessine.

    Le data center consomme un canal logique, mais comme tous les reseaux du
    jeu, le raccordement se fait par ADJACENCE : un fil pose contre le batiment
    est connecte. Dessiner un port d'entree serait une exception au systeme et
    induirait le joueur en erreur (il chercherait a aligner son fil sur le port).

    On garde donc un simple boitier carre, sans port. Le '_side' est ignore et
    conserve uniquement pour la compatibilite d'appel.
    """
    c = Cv()
    square_body(c, inner_inset=2)
    for y in (11, 16, 21):
        c.rect(9, y, 22, y + 2, D2)
        c.px(11, y + 1, QUAN); c.px(15, y + 1, CYAN); c.px(19, y + 1, GOLD)
    return c


SENSORS = ['plein', 'vide', 'contient', 'deficit', 'saveur']
SENSOR_FN = {'plein': sensor_plein, 'vide': sensor_vide,
             'contient': sensor_contient, 'deficit': sensor_deficit,
             'saveur': sensor_saveur}
GATES = ['and', 'or', 'xor', 'nand', 'nor', 'xnor', 'not', 'buf']
GATE_FN = {'and': gate_and, 'or': gate_or, 'xor': gate_xor,
           'nand': gate_nand, 'nor': gate_nor, 'xnor': gate_xnor,
           'not': gate_not, 'buf': gate_buf}

# Les 4 orientations. Le suffixe indique le cote de la SORTIE (ou de l'entree
# pour le data center). Sans suffixe = orientation par defaut, conservee pour
# ne pas casser les references existantes.
SIDES = ['n', 'e', 's', 'o']
OPPOSITE = {'n': 's', 's': 'n', 'e': 'o', 'o': 'e'}

if __name__ == '__main__':
    n = 0
    # --- fil : 16 variantes x 2 etats
    for bits in range(16):
        for on in (False, True):
            wire(bits, on).save(wire_name(bits, on)); n += 1

    # --- senseurs : sortie orientable sur les 4 cotes
    for key in SENSORS:
        for side in SIDES:
            c = SENSOR_FN[key](side)
            c.save(f'logic_senseur_{key}_{side}.png'); n += 1
        SENSOR_FN[key]('s').save(f'logic_senseur_{key}.png'); n += 1

    # --- portes : sortie orientable, entrees sur le cote oppose
    for key in GATES:
        for side in SIDES:
            c = GATE_FN[key](side)
            c.save(f'logic_porte_{key}_{side}.png'); n += 1
        GATE_FN[key]('e').save(f'logic_porte_{key}.png'); n += 1

    # --- collisionneur : 3 sorties sur 3 cotes, 4 rotations
    #     (le suffixe designe le cote LIBRE, sans sortie)
    for side in SIDES:
        sortie_collisionneur(side).save(f'logic_sortie_collisionneur_{side}.png'); n += 1
    sortie_collisionneur('o').save('logic_sortie_collisionneur.png'); n += 1

    # --- data center : pas de port, donc une seule version
    entree_datacenter().save('logic_entree_datacenter.png'); n += 1
    for side in SIDES:
        f = os.path.join(OUT, f'logic_entree_datacenter_{side}.png')
        if os.path.exists(f):
            os.remove(f)
    print(f'{n} sprites generes')
