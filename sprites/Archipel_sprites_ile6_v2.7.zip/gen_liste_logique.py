#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Liste logique demandee (v2.6)
=================================================

Cette passe applique 4 decisions qui DIFFERENT du code actuel. Chacune est
notee ici parce qu'elle demande un ajustement d'une ligne cote moteur ; les
sprites, eux, sont livres dans la forme demandee.

  1. SENSEUR UNIQUE
     Demande : un seul sprite de senseur, pas un par type.
     Code actuel (~18863) : choisit logic_senseur_plein/vide/contient selon
     bld.sensorMode. -> il faut remplacer cette ligne par un 'logic_senseur'
     unique. On livre donc 'logic_senseur_<dir>_<etat>' et on garde des alias
     plein/vide/contient pointant sur le meme visuel, pour ne rien casser tant
     que la ligne moteur n'est pas changee.

  2. ETAT 0/1 SUR LE SPRITE
     Demande : indiquer sur le sprite s'il envoie 0 ou 1.
     Code actuel (~18884) : peint deja une pastille verte (#00E5A0 / #0d5a45)
     par-dessus chaque tuile logique. -> pour eviter le doublon, cote moteur il
     faudra ne plus peindre cette pastille sur les composants qui ont leur
     propre sprite d'etat. Les sprites portent desormais un BANDEAU d'etat clair
     (barre + point) qui encode 0/1 sans ambiguite.
     Convention Ethan conservee : 1 = BLANC #F0F0F4, 0 = NOIR #1A1A1E.

  3. FLECHES DANS CHAQUE SENS
     Chaque composant orientable est livre en _n/_e/_s/_o, la fleche etant
     dessinee DANS le sprite (pas en repli vectoriel). Deja le cas ; ici on
     l'etend au senseur unifie et a l'actionneur.

  4. ACTIONNEUR
     Le code (~18863) fait pointer l'actionneur (logicSink) sur le sprite du
     collisionneur, faute de mieux. On livre un vrai 'logic_actionneur_<dir>_<etat>'.
     A cote-moteur : base = bdef.logicSink ? 'logic_actionneur' : ... .

Palette officielle. 1=BLANC #F0F0F4, 0=NOIR #1A1A1E, accent cyan, trim orange.
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
ORA  = hx('#FF9628')
ORAD = hx('#C46A12')
CYAN = hx('#4FC3F7')
CYAND = hx('#2A7FA8')
QUAN = hx('#B47CFF')
GOLD = hx('#BEA046')
GRN  = hx('#78D26E')
SIG_ON = hx('#F0F0F4')          # 1 = BLANC
SIG_ON_D = hx('#A8ACB8')
SIG_OFF = hx('#1A1A1E')         # 0 = NOIR
SIG_OFF_L = hx('#3A3A42')
SHEATH = hx('#3A3E48')
WHITE = hx('#FFFFFF')

FONT_DIR = 'font'
_G = {}


def glyph(ch):
    if ch not in _G:
        a = np.array(Image.open(f'{FONT_DIR}/maj_{ch.lower()}.png').convert('RGBA'))
        cols = [x for x in range(8) if (a[:, x, 3] > 0).any()]
        rows = [y for y in range(8) if (a[y, :, 3] > 0).any()]
        _G[ch] = a[rows[0]:rows[-1] + 1, cols[0]:cols[-1] + 1]
    return _G[ch]


class Cv:
    def __init__(s, w=32, h=32):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2):
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, OUTL)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def disc(s, cx, cy, r, c):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r // 2:
                    s.px(x, y, c)

    def text(s, txt, x, y, col, sp=1):
        cx = x
        for ch in txt:
            g = glyph(ch)
            for gy in range(g.shape[0]):
                for gx in range(g.shape[1]):
                    if g[gy, gx, 3] > 0:
                        s.px(cx + gx, y + gy, col)
            cx += g.shape[1] + sp
        return cx

    def text_w(s, txt, sp=1):
        return sum(glyph(c).shape[1] for c in txt) + sp * (len(txt) - 1)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


# ---- corps carre commun ----------------------------------------------------
def body(c):
    c.box(4, 4, 27, 27, M2, L2, D2)
    c.rect(6, 7, 25, 25, D1)
    c.frame(6, 7, 25, 25, D0)


# ---- BANDEAU D'ETAT 0/1 ----------------------------------------------------
# Barre horizontale en haut du boitier : blanche pleine = 1, noire creuse = 0.
# Plus un point d'etat dans le coin. C'est ce qui remplace la pastille verte du
# moteur, en restant sur la convention blanc/noir demandee.
def status_bar(c, on):
    if on:
        c.hline(4, 27, 5, SIG_ON)
        c.hline(5, 26, 6, SIG_ON_D)
        c.rect(6, 6, 8, 8, SIG_ON)          # temoin de coin, plein
        c.px(7, 7, WHITE)
    else:
        c.hline(4, 27, 5, SIG_OFF)
        c.hline(5, 26, 6, SIG_OFF_L)
        c.rect(6, 6, 8, 8, D0)              # temoin de coin, creux
        c.frame(6, 6, 8, 8, SIG_OFF_L)


# ---- FLECHE D'ORIENTATION integree -----------------------------------------
# Fleche qui part du centre du boitier vers le bord 'side', debordant legerement
# sur la marge de tuile. Couleur = etat du signal : blanc si 1, gris si 0, pour
# qu'un fil et sa source aient la meme teinte.
def arrow(c, side, on):
    col = SIG_ON if on else SIG_OFF_L
    coldim = SIG_ON_D if on else hx('#2A2A30')
    if side == 'n':
        c.vline(16, 1, 8, col); c.vline(15, 3, 8, coldim); c.vline(17, 3, 8, coldim)
        c.px(16, 0, WHITE if on else SIG_OFF_L)
        for i, y in enumerate(range(1, 5)):
            c.hline(16 - i, 16 + i, y, col)
    elif side == 's':
        c.vline(16, 23, 30, col); c.vline(15, 23, 28, coldim); c.vline(17, 23, 28, coldim)
        c.px(16, 31, WHITE if on else SIG_OFF_L)
        for i, y in enumerate(range(30, 26, -1)):
            c.hline(16 - i, 16 + i, y, col)
    elif side == 'o':
        c.hline(1, 8, 16, col); c.hline(3, 8, 15, coldim); c.hline(3, 8, 17, coldim)
        c.px(0, 16, WHITE if on else SIG_OFF_L)
        for i, x in enumerate(range(1, 5)):
            c.vline(x, 16 - i, 16 + i, col)
    else:  # e
        c.hline(23, 30, 16, col); c.hline(23, 28, 15, coldim); c.hline(23, 28, 17, coldim)
        c.px(31, 16, WHITE if on else SIG_OFF_L)
        for i, x in enumerate(range(30, 26, -1)):
            c.vline(x, 16 - i, 16 + i, col)


# =============================================================== SENSEUR UNIQUE
def senseur(side='s', on=False):
    """UN SEUL sprite de senseur (pas de variante plein/vide/contient).

    Un capteur lit une condition et emet un signal. L'oeil (lentille) symbolise
    la lecture ; l'etat 0/1 est porte par le bandeau + la fleche. Le TYPE de
    condition (plein/vide/contient...) est un reglage, il se lit dans le panneau
    de config, pas sur la tuile - conforme a la demande.
    """
    c = Cv()
    body(c)
    # lentille de capteur
    c.disc(16, 15, 5, D0)
    for y in range(32):
        for x in range(32):
            d = ((x - 16) ** 2 + (y - 15) ** 2) ** 0.5
            if 4.4 < d <= 5.4:
                c.px(x, y, M1)
    c.disc(16, 15, 3, CYAND)
    c.disc(15, 14, 2, CYAN)
    c.px(15, 14, WHITE)
    # label CAPT discret
    c.text('C', 9, 20, L2)
    arrow(c, side, on)
    status_bar(c, on)
    return c


# ================================================================ ACTIONNEUR
def actionneur(side='e', on=False):
    """Actionneur : recoit un signal et coupe/rallume un batiment voisin.

    Symbole : un interrupteur/relais. La fleche pointe vers le batiment cible.
    Trim orange (le code lui donne color '#FF9628').
    """
    c = Cv()
    body(c)
    c.hline(4, 27, 5, ORA if not on else SIG_ON)   # trim, ecrase par le bandeau ensuite
    # relais : bobine + contact
    c.rect(10, 11, 14, 20, D0)
    c.frame(10, 11, 14, 20, M1)
    for y in range(12, 20, 2):
        c.hline(11, 13, y, ORA)                     # enroulements
    # bras de contact : ferme si on, ouvert si off
    if on:
        c.rect(15, 14, 22, 16, SIG_ON)
        c.px(22, 15, WHITE)
    else:
        c.line = None
        for i in range(8):
            c.px(15 + i, 14 + i, SIG_OFF_L)         # bras releve (ouvert)
    c.rect(20, 17, 23, 21, D0)                       # borne de sortie
    c.frame(20, 17, 23, 21, M1)
    c.text('A', 8, 20, L2)
    arrow(c, side, on)
    status_bar(c, on)
    return c


# ================================================================== PORTES (7)
def _gate(label, side, on, bubble=False):
    c = Cv()
    wide = len(label) >= 4
    ix0, ix1 = (4, 27) if wide else (6, 25)
    c.box(4, 4, 27, 27, M2, L2, D2)
    c.rect(ix0, 7, ix1, 25, D1)
    c.frame(ix0, 7, ix1, 25, D0)
    sp = 0 if wide else 1
    w = c.text_w(label, sp)
    c.text(label, ix0 + ((ix1 - ix0 + 1) - w) // 2, 13, hx('#EBEEF5'), sp)
    if bubble:
        # bulle d'inversion sur le port de sortie (cote 'side')
        if side == 'e':
            c.rect(23, 14, 25, 18, SIG_ON); c.frame(23, 14, 25, 18, OUTL); c.px(24, 15, WHITE)
        elif side == 'o':
            c.rect(6, 14, 8, 18, SIG_ON); c.frame(6, 14, 8, 18, OUTL); c.px(7, 15, WHITE)
        elif side == 's':
            c.rect(14, 23, 18, 25, SIG_ON); c.frame(14, 23, 18, 25, OUTL); c.px(15, 24, WHITE)
        else:
            c.rect(14, 6, 18, 8, SIG_ON); c.frame(14, 6, 18, 8, OUTL); c.px(15, 7, WHITE)
    arrow(c, side, on)
    status_bar(c, on)
    return c


GATES = [
    ('and',  'AND',  False),
    ('or',   'OR',   False),
    ('xor',  'XOR',  False),
    ('nand', 'NAND', True),
    ('nor',  'NOR',  True),
    ('xnor', 'XNOR', True),
    ('not',  'NOT',  True),
]


# ================================================ BLOCS EMETTEURS (alpha...)
# 3 blocs = 3 niveaux de bits emis. Meme boitier, contenu croissant.
GLYPH_A = ["..#..", ".#.#.", "#...#", "#####", "#...#", "#...#", "#...#"]  # A stylise
GA = ["....", ".##.", "#..#", "#..#", "####", "#..#", "#..#"]              # non utilise


def draw_greek(c, rows, x0, y0, col):
    for gy, row in enumerate(rows):
        for gx, ch in enumerate(row):
            if ch == '#':
                c.px(x0 + gx, y0 + gy, col)


AL = [".##.#", "#..##", "#...#", "#..##", ".##.#"]                     # alpha
BE = ["##..", "#.#.", "###.", "#.#.", "#.#.", "###.", "#..."]         # beta
GA2 = ["#...#", ".#.#.", "..#..", "..#..", "..#.."]                   # gamma


def bloc(niveau, side='e', on=False):
    """Bloc emetteur. niveau 1=alpha, 2=alpha+beta, 3=alpha+beta+gamma.

    Le nombre de glyphes allumes = le nombre de bits que le bloc met sur le
    reseau. C'est l'information utile ; le reste du boitier est neutre.
    """
    c = Cv()
    body(c)
    glyphs = [(AL, 'a'), (BE, 'b'), (GA2, 'g')][:niveau]
    # disposer 1, 2 ou 3 cartouches
    positions = {1: [(13, 12)], 2: [(9, 12), (18, 12)], 3: [(8, 12), (14, 12), (20, 12)]}[niveau]
    allon = [(AL, 'a'), (BE, 'b'), (GA2, 'g')]
    for i, (gx, gy) in enumerate(positions):
        g = allon[i][0]
        gw = max(len(r) for r in g)
        c.rect(gx - 1, 11, gx + gw, 19, D0)
        c.frame(gx - 1, 11, gx + gw, 19, M1)
        draw_greek(c, g, gx, 12, CYAN if not on else SIG_ON)
    arrow(c, side, on)
    status_bar(c, on)
    return c


# ============================================================ VANNE COLLISIONNEUR
def vanne(side='e', on=False, penalite=False):
    """Vanne du collisionneur : ouvre/ferme l'arrivee sur le collisionneur.

    Silhouette du volant : diagonale = ferme, croix = ouvert (lisible sans
    couleur). 'penalite' = rouge, l'arret a coute les 10 min de demarrage.
    """
    c = Cv()
    body(c)
    if penalite:
        acc, accd = hx('#FF5C5C'), hx('#A83232')
    elif on:
        acc, accd = SIG_ON, SIG_ON_D
    else:
        acc, accd = M1, D2
    c.disc(16, 16, 7, D0)
    for y in range(32):
        for x in range(32):
            d = ((x - 16) ** 2 + (y - 16) ** 2) ** 0.5
            if 6.6 < d <= 7.8:
                c.px(x, y, OUTL)
    c.disc(16, 16, 5, accd)
    c.disc(16, 16, 3, acc)
    if on and not penalite:
        for (dx, dy) in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            for k in range(4, 9):
                c.px(16 + dx * k, 16 + dy * k, acc)
    else:
        for (dx, dy) in [(-1, -1), (1, 1), (-1, 1), (1, -1)]:
            for k in range(4, 8):
                c.px(16 + dx * k, 16 + dy * k, acc if penalite else M2)
    if penalite:
        for k in range(-4, 5):
            c.px(16 + k, 16 + k, hx('#FF5C5C')); c.px(16 + k, 16 - k, hx('#FF5C5C'))
    arrow(c, side, on and not penalite)
    if penalite:
        c.hline(4, 27, 5, hx('#FF5C5C'))
    else:
        status_bar(c, on)
    return c


# ================================================================= BADGE PAUSE
def badge_pause_logique():
    """Badge 'pause logique' : 16x16, format des ui_* (pastille circulaire).

    Le reseau logique peut etre gele independamment de la pause generale. Le
    badge reprend les deux barres de pause, sur pastille cyan (couleur du
    signal), avec un petit 'L' pour 'logique'.
    """
    c = Cv(16, 16)
    # pastille
    for y in range(16):
        for x in range(16):
            d = ((x - 8) ** 2 + (y - 8) ** 2) ** 0.5
            if d <= 6.8:
                if x + y < 14:
                    c.px(x, y, CYAN)
                elif x + y > 18:
                    c.px(x, y, CYAND)
                else:
                    c.px(x, y, hx('#3E9AC0'))
            elif d <= 7.8:
                c.px(x, y, hx('#12303A'))
    # deux barres de pause
    c.rect(5, 4, 6, 11, WHITE)
    c.rect(9, 4, 10, 11, WHITE)
    c.px(5, 4, hx('#DFF4FF')); c.px(9, 4, hx('#DFF4FF'))
    return c


def badge_pause_logique_16():
    return badge_pause_logique()


DIRS = ['n', 'e', 's', 'o']

if __name__ == '__main__':
    made = []

    # senseur unique (+ alias plein/vide/contient sur le meme visuel)
    for d in DIRS:
        for st, on in [('0', False), ('1', True)]:
            c = senseur(d, on)
            made.append(c.save(f'logic_senseur_{d}_{st}.png'))
        # alias pour compat avec la ligne moteur actuelle (sensorMode)
        for alias in ['plein', 'vide', 'contient']:
            senseur(d, False).save(f'logic_senseur_{alias}_{d}.png')
            made.append(f'logic_senseur_{alias}_{d}.png (alias)')

    # actionneur
    for d in DIRS:
        for st, on in [('0', False), ('1', True)]:
            made.append(actionneur(d, on).save(f'logic_actionneur_{d}_{st}.png'))

    # portes (7) x 4 dir x 2 etats
    for key, lab, bub in GATES:
        for d in DIRS:
            for st, on in [('0', False), ('1', True)]:
                made.append(_gate(lab, d, on, bub).save(f'logic_porte_{key}_{d}_{st}.png'))
        # version sans suffixe d'etat = etat 0, pour compat cle moteur actuelle
        for d in DIRS:
            _gate(lab, d, False, bub).save(f'logic_porte_{key}_{d}.png')

    # blocs emetteurs
    for niv, nm in [(1, 'alpha'), (2, 'alpha_beta'), (3, 'alpha_beta_gamma')]:
        for d in DIRS:
            for st, on in [('0', False), ('1', True)]:
                made.append(bloc(niv, d, on).save(f'logic_bloc_{nm}_{d}_{st}.png'))

    # vanne collisionneur
    for d in DIRS:
        for st, on in [('0', False), ('1', True)]:
            made.append(vanne(d, on).save(f'logic_vanne_collisionneur_{d}_{st}.png'))
    made.append(vanne('e', False, penalite=True).save('logic_vanne_collisionneur_penalite.png'))

    # badge pause logique
    made.append(badge_pause_logique().save('ui_pause_logique.png'))

    print(f'{len(made)} fichiers')
