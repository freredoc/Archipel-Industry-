#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Generateur tuiles Ile 6 (surface i6) + Souterrain (i7)
Reproduit EXACTEMENT le systeme officiel decode depuis sprites/tile_i1..i5_* :
  - masque de dither 3 tons identique pour toutes les iles (land)
  - coast = meme grille de dither + 4 pixels "sparkle"
  - coast_tri_XX = coast + moitie diagonale en palette land
  - obstacle = land + rocher (masque 4 tons)
  - resource = land + blob minerai (36 teintes, degrade)
  - water = bruit procedural autour d'une couleur de base
Seule la PALETTE change par ile. Aucune invention de structure.
"""
from PIL import Image
import numpy as np, os, json

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)

def arr(f):
    return np.array(Image.open(f).convert('RGBA'))

def save(a, name):
    Image.fromarray(a.astype(np.uint8), 'RGBA').save(os.path.join(OUT, name))
    return name

# ---------------------------------------------------------------- references
L5 = arr(f'{SRC}/tile_i5_land.png')
C5 = arr(f'{SRC}/tile_i5_coast.png')
O5 = arr(f'{SRC}/tile_i5_obstacle.png')
R5 = arr(f'{SRC}/tile_i5_resource.png')
W5 = arr(f'{SRC}/tile_i5_water.png')

# palette i5 de reference (roles)
I5 = {
    'land_light': (0x44, 0x6C, 0x3D),
    'land_base':  (0x3A, 0x5C, 0x34),
    'land_dark':  (0x30, 0x4D, 0x2B),
    'coast_light':(0x35, 0x5E, 0x50),
    'coast_base': (0x30, 0x54, 0x48),
    'coast_dark': (0x29, 0x48, 0x3D),
    'coast_spark':(0x43, 0x75, 0x64),
    'rock_base':  (0x2E, 0x2D, 0x31),
    'rock_mid':   (0x43, 0x41, 0x48),
    'rock_light': (0x54, 0x52, 0x5A),
    'rock_hi':    (0x75, 0x72, 0x7D),
    'water_base': (0x18, 0x2A, 0x3E),
    'ore_dark':   (0x37, 0x2D, 0x21),
}

# index maps (role par pixel), derives une seule fois depuis i5
def index_map(a, mapping):
    idx = np.full((32, 32), -1, int)
    keys = list(mapping.keys())
    for y in range(32):
        for x in range(32):
            t = tuple(a[y, x][:3])
            if t in mapping:
                idx[y, x] = keys.index(t)
    return idx, keys

LAND_IDX, LAND_KEYS = index_map(L5, {
    I5['land_light']: 'light', I5['land_base']: 'base', I5['land_dark']: 'dark'})
LAND_ROLE = np.array([['light', 'base', 'dark'][v] for v in LAND_IDX.ravel()]).reshape(32, 32)

COAST_IDX, COAST_KEYS = index_map(C5, {
    I5['coast_light']: 'light', I5['coast_base']: 'base',
    I5['coast_dark']: 'dark', I5['coast_spark']: 'spark'})
COAST_ROLE = np.array([['light', 'base', 'dark', 'spark'][v] for v in COAST_IDX.ravel()]).reshape(32, 32)

# rocher : masque + role
ROCK_DIFF = (O5 != L5).any(axis=2)
ROCK_ROLE = np.empty((32, 32), object)
_rmap = {I5['rock_base']: 'base', I5['rock_mid']: 'mid',
         I5['rock_light']: 'light', I5['rock_hi']: 'hi'}
for y in range(32):
    for x in range(32):
        ROCK_ROLE[y, x] = _rmap.get(tuple(O5[y, x][:3])) if ROCK_DIFF[y, x] else None

# minerai : masque + luminance normalisee (pour re-teinter)
ORE_DIFF = (R5 != L5).any(axis=2)
_ore = R5[:, :, :3].astype(float)
_lum = _ore.mean(axis=2)
_vals = _lum[ORE_DIFF]
ORE_T = np.zeros((32, 32))
ORE_T[ORE_DIFF] = (_vals - _vals.min()) / max(1e-6, (_vals.max() - _vals.min()))

# eau : bruit = delta par rapport a la base
WATER_D = W5[:, :, :3].astype(int) - np.array(I5['water_base'])

# triangles cote : quels pixels prennent la palette LAND
TRI = {}
for d in ['ne', 'nw', 'se', 'sw']:
    t = arr(f'{SRC}/tile_i5_coast_tri_{d}.png')
    TRI[d] = (t[:, :, :3] != C5[:, :, :3]).any(axis=2)

# ---------------------------------------------------------------- palettes I6
def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))

# ILE 6 SURFACE : volcanique / mineral froid. Roche grise-violacee, vegetation
# rase et rare -> teinte gris-ardoise verdatre. Se demarque des iles 1-5
# (toutes vertes/olive) sans sortir du langage chromatique du jeu.
I6 = {
    'land_light':  hx('#6E6A72'),
    'land_base':   hx('#5C5962'),
    'land_dark':   hx('#4A4851'),
    'coast_light': hx('#4A5A63'),
    'coast_base':  hx('#405059'),
    'coast_dark':  hx('#35434B'),
    'coast_spark': hx('#5E7A86'),
    'rock_base':   hx('#2A2833'),
    'rock_mid':    hx('#403D4C'),
    'rock_light':  hx('#565266'),
    'rock_hi':     hx('#7A7590'),
    'water_base':  hx('#141F33'),
    # minerai = TUNGSTENE : blanc-gris metallique legerement bleute
    'ore_lo':      hx('#2E3138'),
    'ore_hi':      hx('#C2CBD6'),
}

# SOUTERRAIN (ile 7 interne) : caverne. "land" = sol rocheux poussiereux
# eclaire par la geothermie (brun-ocre chaud), "coast" = zone humide/bord de
# gouffre, "water" = lac souterrain sombre, "obstacle" = paroi rocheuse.
I7 = {
    'land_light':  hx('#5A4B3E'),
    'land_base':   hx('#4A3D33'),
    'land_dark':   hx('#3B3028'),
    'coast_light': hx('#4A4038'),
    'coast_base':  hx('#3E352F'),
    'coast_dark':  hx('#322B26'),
    'coast_spark': hx('#7A5F3E'),
    'rock_base':   hx('#221C1A'),
    'rock_mid':    hx('#38302B'),
    'rock_light':  hx('#4C423A'),
    'rock_hi':     hx('#6B5C4D'),
    'water_base':  hx('#101820'),
    # minerai souterrain = poche HE3 : cyan pale luminescent
    'ore_lo':      hx('#16303A'),
    'ore_hi':      hx('#7FE6F0'),
}

# ---------------------------------------------------------------- builders
def build_land(P):
    a = np.zeros((32, 32, 4), np.uint8)
    a[:, :, 3] = 255
    for role, key in [('light', 'land_light'), ('base', 'land_base'), ('dark', 'land_dark')]:
        a[:, :, :3][LAND_ROLE == role] = P[key]
    return a

def build_coast(P):
    a = np.zeros((32, 32, 4), np.uint8)
    a[:, :, 3] = 255
    for role, key in [('light', 'coast_light'), ('base', 'coast_base'),
                      ('dark', 'coast_dark'), ('spark', 'coast_spark')]:
        a[:, :, :3][COAST_ROLE == role] = P[key]
    return a

def build_coast_tri(P, d):
    a = build_coast(P)
    land = build_land(P)
    m = TRI[d]
    a[m] = land[m]
    return a

def build_obstacle(P):
    a = build_land(P)
    for y in range(32):
        for x in range(32):
            r = ROCK_ROLE[y, x]
            if r:
                a[y, x, :3] = P['rock_' + r]
    return a

def build_resource(P):
    a = build_land(P)
    lo = np.array(P['ore_lo'], float)
    hi = np.array(P['ore_hi'], float)
    for y in range(32):
        for x in range(32):
            if ORE_DIFF[y, x]:
                t = ORE_T[y, x]
                a[y, x, :3] = np.clip(lo + (hi - lo) * t, 0, 255).astype(np.uint8)
    return a

def build_water(P):
    a = np.zeros((32, 32, 4), np.uint8)
    a[:, :, 3] = 255
    base = np.array(P['water_base'], int)
    a[:, :, :3] = np.clip(base + WATER_D, 0, 255)
    return a

# ---------------------------------------------------------------- souterrain : mur
def build_wall(P):
    """Paroi rocheuse pleine du souterrain (non constructible, non traversable).
    Construite sur la meme grille de dither que land, mais en palette rocher,
    plus un lisere sombre 1px sur tout le pourtour -> lecture 'bloc plein'
    quand plusieurs tuiles sont adjacentes."""
    a = np.zeros((32, 32, 4), np.uint8)
    a[:, :, 3] = 255
    for role, key in [('light', 'rock_light'), ('base', 'rock_mid'), ('dark', 'rock_base')]:
        a[:, :, :3][LAND_ROLE == role] = P[key]
    # lisere perimetrique
    edge = np.array(P['rock_base'], int)
    a[0, :, :3] = np.clip(edge * 0.75, 0, 255)
    a[31, :, :3] = np.clip(edge * 0.75, 0, 255)
    a[:, 0, :3] = np.clip(edge * 0.75, 0, 255)
    a[:, 31, :3] = np.clip(edge * 0.75, 0, 255)
    # quelques eclats clairs (facettes) - deterministe
    rng = np.random.RandomState(607)
    for _ in range(26):
        x, y = rng.randint(3, 29), rng.randint(3, 29)
        a[y, x, :3] = P['rock_hi']
    return a

if __name__ == '__main__':
    made = []
    # NOTE : les tuiles i7 sont desormais generees par gen_terrain_souterrain.py
    # (roles inverses : water=roche pleine, land=tunnel, oil=poche de gaz).
    for tag, P in [('i6', I6)]:
        made.append(save(build_land(P), f'tile_{tag}_land.png'))
        made.append(save(build_coast(P), f'tile_{tag}_coast.png'))
        for d in ['ne', 'nw', 'se', 'sw']:
            made.append(save(build_coast_tri(P, d), f'tile_{tag}_coast_tri_{d}.png'))
        made.append(save(build_obstacle(P), f'tile_{tag}_obstacle.png'))
        made.append(save(build_resource(P), f'tile_{tag}_resource.png'))
        made.append(save(build_water(P), f'tile_{tag}_water.png'))
    print('\n'.join(made))
    print(len(made), 'fichiers')
