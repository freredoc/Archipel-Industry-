#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Collisionneur de Hadrons, 4 etats de reparation
64x96 (2x3 tuiles, cf. colonne Taille de l'Excel L78).

Les 4 etats suivent les paliers du brief (§2) :
  etat 0 - RUINE      : structure trouvee en ruine. Anneau brise, pas de faisceau.
  etat 1 - P1 fait    : beton arme irradie + acier irradie + piece de precision
                        -> genie civil refait : anneau complet, halls debouches,
                           mais aucun aimant, aucune alimentation.
  etat 2 - P2 fait    : cable supraconducteur
                        -> les 12 aimants supra sont poses et alimentes (cyan),
                           le tube est sous vide mais le coeur reste eteint.
  etat 3 - P3 fait    : ordinateur quantique
                        -> collisionneur operationnel : faisceau violet, coeur
                           en collision, matiere exotique en sortie.

Progression lisible d'un coup d'oeil, meme en dezoome :
  ruine = brun/rouille et troue · P1 = gris complet mais eteint ·
  P2 = points cyan sur l'anneau · P3 = anneau violet + coeur blanc.
"""
from PIL import Image
import numpy as np, os, math

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


OUTL = hx('#161A22')
D0   = hx('#1E222C')
D1   = hx('#2A303C')
D2   = hx('#404652')
M1   = hx('#4E525C')
M2   = hx('#646B78')
L1   = hx('#787C86')
L2   = hx('#8C93A0')
L3   = hx('#A5A8B2')
WHT  = hx('#D6DCE4')
ORA  = hx('#FF9628')
CYAN = hx('#4FC3F7'); CYAND = hx('#2A7FA8')
QUAN = hx('#B47CFF'); QUAND = hx('#6E4AA8')
HE3  = hx('#7FE6F0')
GOLD = hx('#BEA046')
RUST = hx('#7A4A32'); RUSD = hx('#4E2F20'); RUSL = hx('#9C6244')
DARK = hx('#0D1016')
ROCK = hx('#4C423A'); ROCKD = hx('#2A231D')


class Cv:
    def __init__(s, w=64, h=96):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2, outline=OUTL):
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, outline)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def disc(s, cx, cy, r, c):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r // 2:
                    s.px(x, y, c)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


CX, CY, R = 32, 44, 26

# Secteurs de l'anneau detruits a l'etat 0 (en radians, [debut, fin])
GAPS = [(0.35, 0.95), (2.30, 2.85), (3.95, 4.35), (5.35, 5.80)]


def in_gap(ang):
    a = ang % (2 * math.pi)
    return any(g0 <= a <= g1 for g0, g1 in GAPS)


def socle(c, stage):
    """Dalle de la megastructure."""
    body = D1 if stage >= 1 else hx('#241E1A')
    c.rect(1, 78, 62, 94, body)
    c.frame(1, 78, 62, 94, OUTL)
    c.hline(2, 61, 79, M1 if stage >= 1 else RUSD)
    for x in range(4, 60, 7):
        c.vline(x, 80, 93, D0)
    if stage >= 1:
        for x in range(3, 61):
            if (x // 3) % 2 == 0:
                c.px(x, 92, ORA if stage >= 2 else RUST)
    else:
        # dalle eventree
        for (gx, gy) in [(9, 84), (22, 88), (40, 82), (52, 90), (16, 91), (46, 86)]:
            c.rect(gx, gy, gx + 3, gy + 2, ROCKD)
            c.px(gx + 1, gy, ROCK)
        for i in range(6):
            c.px(12 + i * 2, 80 + i, ROCKD)


def anneau(c, stage):
    """Anneau de collision. stage 0 = brise, 1 = complet eteint,
    2 = aimants supra alimentes, 3 = faisceau actif."""
    for y in range(CY - R - 2, CY + R + 3):
        for x in range(CX - R - 2, CX + R + 3):
            dx, dy = x - CX, y - CY
            d = (dx * dx + dy * dy) ** 0.5
            ang = math.atan2(dy, dx)
            broken = (stage == 0 and in_gap(ang))
            if broken:
                # segment effondre : quelques debris seulement
                if R - 5 <= d <= R and (x + y) % 3 == 0:
                    c.px(x, y, RUSD)
                continue
            if R - 5 <= d <= R:
                c.px(x, y, M2 if stage >= 1 else RUST)
            elif R < d <= R + 1.4:
                c.px(x, y, OUTL)
            elif R - 6.4 <= d < R - 5:
                c.px(x, y, OUTL)

    # tube interne
    if stage >= 1:
        for y in range(CY - R, CY + R + 1):
            for x in range(CX - R, CX + R + 1):
                dx, dy = x - CX, y - CY
                d = (dx * dx + dy * dy) ** 0.5
                ang = math.atan2(dy, dx)
                if stage == 0 and in_gap(ang):
                    continue
                if R - 3.6 <= d <= R - 1.8:
                    if stage >= 3:
                        c.px(x, y, QUAND)
                    else:
                        c.px(x, y, D1)
                elif R - 3.0 <= d <= R - 2.4:
                    if stage >= 3:
                        c.px(x, y, QUAN)
                    elif stage == 2:
                        c.px(x, y, D2)

    # aimants supraconducteurs (12) - poses a partir de P2
    for k in range(12):
        ang = k * math.pi / 6
        mx = int(round(CX + (R - 2.5) * math.cos(ang)))
        my = int(round(CY + (R - 2.5) * math.sin(ang)))
        if stage == 0:
            if not in_gap(ang):
                # socles d'aimants vides et rouilles
                c.rect(mx - 2, my - 2, mx + 2, my + 2, RUSD)
                c.frame(mx - 2, my - 2, mx + 2, my + 2, OUTL)
                c.px(mx, my, ROCKD)
            continue
        if stage == 1:
            # emplacements prets, aucun aimant monte
            c.rect(mx - 2, my - 2, mx + 2, my + 2, D1)
            c.frame(mx - 2, my - 2, mx + 2, my + 2, OUTL)
            c.px(mx, my, D0)
            continue
        # stage >= 2 : aimants montes et alimentes
        c.rect(mx - 2, my - 2, mx + 2, my + 2, D2)
        c.frame(mx - 2, my - 2, mx + 2, my + 2, OUTL)
        c.px(mx, my, CYAN)
        c.px(mx - 1, my, CYAND); c.px(mx + 1, my, CYAND)


def coeur(c, stage):
    """Point de collision central."""
    if stage == 0:
        # cratere : la chambre a implose
        c.disc(CX, CY, 9, ROCKD)
        for y in range(CY - 10, CY + 11):
            for x in range(CX - 10, CX + 11):
                d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
                if 9 < d <= 10.4:
                    c.px(x, y, OUTL)
        c.disc(CX, CY, 6, DARK)
        for (dx, dy) in [(-3, -2), (2, 3), (4, -1), (-1, 4), (-4, 1)]:
            c.px(CX + dx, CY + dy, RUSD)
        c.px(CX - 2, CY - 4, ROCK); c.px(CX + 3, CY + 1, ROCK)
        return

    c.disc(CX, CY, 9, D1)
    for y in range(CY - 10, CY + 11):
        for x in range(CX - 10, CX + 11):
            d = ((x - CX) ** 2 + (y - CY) ** 2) ** 0.5
            if 9 < d <= 10.4:
                c.px(x, y, OUTL)

    if stage == 1:
        # chambre remontee mais vide
        c.disc(CX, CY, 6, D0)
        c.disc(CX, CY, 3, DARK)
    elif stage == 2:
        # sous vide, pre-alimentee, pas encore de collision
        c.disc(CX, CY, 6, D0)
        c.disc(CX, CY, 4, CYAND)
        c.disc(CX, CY, 2, hx('#3A6E88'))
    else:
        # collision active
        c.disc(CX, CY, 6, QUAND)
        c.disc(CX, CY, 4, QUAN)
        c.disc(CX, CY, 2, WHT)
        for (dx, dy) in [(0, -8), (0, 8), (-8, 0), (8, 0),
                         (-6, -6), (6, 6), (-6, 6), (6, -6)]:
            c.px(CX + dx, CY + dy, HE3)

    # detecteurs en croix (presents des P1)
    det = M2 if stage >= 1 else RUST
    c.rect(CX - 1, CY - 14, CX, CY - 11, det)
    c.rect(CX - 1, CY + 11, CX, CY + 14, det)
    c.rect(CX - 14, CY - 1, CX - 11, CY, det)
    c.rect(CX + 11, CY - 1, CX + 14, CY, det)


def hall_haut(c, stage):
    """Hall technique + tour de controle."""
    if stage == 0:
        # toiture effondree
        c.rect(6, 8, 57, 16, hx('#3A322C'))
        c.frame(6, 8, 57, 16, OUTL)
        for i, x in enumerate(range(8, 56, 6)):
            c.vline(x, 9, 15, RUSD)
            c.px(x, 9 + (i % 4), RUST)
        for (gx, gy) in [(12, 12), (28, 10), (44, 14), (50, 11)]:
            c.rect(gx, gy, gx + 2, gy + 1, ROCKD)
        # poutres tombees en travers
        for i in range(14):
            c.px(10 + i, 6 + i // 3, RUST)
            c.px(40 + i, 9 - i // 4, RUSD)
        return

    c.box(6, 4, 57, 16, M2, L2, D2)
    c.hline(6, 57, 5, ORA if stage >= 2 else RUST)
    c.rect(9, 7, 54, 14, D1)
    for i, x in enumerate(range(11, 54, 6)):
        c.rect(x, 8, x + 3, 13, D2)
        if stage >= 3:
            c.px(x + 1, 9, [QUAN, CYAN, GOLD][i % 3])
            c.px(x + 2, 11, [CYAN, QUAN, HE3][i % 3])
        elif stage == 2:
            c.px(x + 1, 9, CYAN)
            c.px(x + 2, 11, CYAND)
        # stage 1 : baies muettes
    # tour de controle
    c.box(24, 0, 39, 6, D2, M1, D0)
    c.rect(27, 2, 36, 4, D0)
    if stage >= 2:
        for x in [29, 31, 33]:
            c.px(x, 3, CYAN)
        c.px(35, 3, ORA)
    elif stage == 1:
        c.px(29, 3, D1); c.px(33, 3, D1)


def tours_laterales(c, stage):
    """Cryostat He3 (gauche) + alimentation supra (droite)."""
    for (x0, x1, acc, accd) in [(1, 8, HE3, hx('#3A96A4')), (55, 62, CYAN, CYAND)]:
        if stage == 0:
            c.rect(x0, 34, x1, 58, hx('#3A322C'))
            c.frame(x0, 34, x1, 58, OUTL)
            for y in range(37, 56, 6):
                c.hline(x0 + 1, x1 - 1, y, RUSD)
            c.px(x0 + 2, 40, RUST); c.px(x1 - 2, 50, RUST)
            continue
        c.box(x0, 30, x1, 58, M2, L2, D2)
        c.rect(x0 + 1, 32, x1 - 1, 56, D1)
        c.hline(x0, x1, 31, ORA if stage >= 2 else RUST)
        for y in range(34, 55, 5):
            if stage >= 2:
                c.hline(x0 + 2, x1 - 2, y, accd)
                c.px(x0 + 3, y, acc); c.px(x0 + 4, y, acc)
            else:
                c.hline(x0 + 2, x1 - 2, y, D2)


def halls_bas(c, stage):
    """Halls inferieurs + cuve de matiere exotique."""
    if stage == 0:
        for (x0, x1) in [(4, 26), (37, 59)]:
            c.rect(x0, 70, x1, 80, hx('#3A322C'))
            c.frame(x0, 70, x1, 80, OUTL)
            for i, x in enumerate(range(x0 + 2, x1 - 1, 5)):
                c.vline(x, 71, 79, RUSD)
            c.px(x0 + 4, 74, RUST); c.px(x1 - 5, 77, RUST)
        return

    c.box(4, 68, 26, 80, M2, L2, D2)
    c.rect(6, 70, 24, 78, D1)
    if stage >= 3:
        for (x, y) in [(8, 72), (11, 72), (14, 74), (17, 72), (20, 76)]:
            c.px(x, y, QUAN)
    elif stage == 2:
        for (x, y) in [(8, 72), (14, 74), (20, 76)]:
            c.px(x, y, CYAND)

    c.box(37, 68, 59, 80, M2, L2, D2)
    c.rect(39, 70, 57, 78, D1)
    # cuve de matiere exotique : ne se remplit qu'a P3
    cx, cy, r = 48, 74, 5
    if stage >= 3:
        c.disc(cx, cy, r, QUAND)
        c.disc(cx - 1, cy - 1, r - 2, QUAN)
        c.px(cx, cy, WHT); c.px(cx - 1, cy - 1, WHT)
    else:
        c.disc(cx, cy, r, D2)
        c.disc(cx - 1, cy - 1, r - 2, M1)
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            d = (x - cx) ** 2 + (y - cy) ** 2
            if r * r + r // 2 < d <= (r + 1) ** 2 + r:
                c.px(x, y, OUTL)

    # conduits anneau -> halls
    for x in [15, 46]:
        c.rect(x, 62, x + 2, 68, D2)
        c.vline(x, 62, 68, M1)


def collisionneur(stage):
    c = Cv()
    socle(c, stage)
    anneau(c, stage)
    coeur(c, stage)
    hall_haut(c, stage)
    tours_laterales(c, stage)
    halls_bas(c, stage)
    return c


if __name__ == '__main__':
    names = [
        'bat_collisionneur_ruine',   # etat 0
        'bat_collisionneur_p1',      # etat 1
        'bat_collisionneur_p2',      # etat 2
        'bat_collisionneur',         # etat 3 (operationnel, nom par defaut)
    ]
    for i, n in enumerate(names):
        print(collisionneur(i).save(n + '.png'))
