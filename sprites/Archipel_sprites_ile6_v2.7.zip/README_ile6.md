# Archipel Industry — Pack sprites Île 6 (v1.0)

23 sprites 32×32 RGBA. Deux zones = deux îles au sens moteur : **i6** (surface) et **i7** (souterrain).

## Méthode
Le masque de dither et toutes les structures (rocher, blob minerai, bruit d'eau,
demi-diagonales des triangles) sont **extraits des tuiles officielles i1–i5**, pas
redessinés. Vérification faite : bijection couleur stricte entre `tile_i5_*` et
`tile_i6_*`/`tile_i7_*` → structure identique au pixel près, **seule la palette change**.
C'est exactement le système déjà en place entre les îles 1 à 5.

## Contenu

### Surface (i6) — 9 tuiles
`land` · `coast` · `coast_tri_{ne,nw,se,sw}` · `obstacle` · `resource` · `water`

Palette **gris-ardoise minéral** (`#5C5962` base). Les îles 1–5 sont toutes
vertes/olive ; l'île 6 devait se démarquer sans quitter le langage du jeu — d'où
un basculement vers le minéral froid, cohérent avec le thème tungstène/endgame.
`resource` = **tungstène** : dégradé blanc-gris métallique légèrement bleuté.

### Souterrain (i7) — 12 tuiles, **rôles de terrain inversés**

Le moteur n'a que 6 rôles (`charToTerrain`) : `W water · T land · M resource · O obstacle ·
C coast · P oil`. Plutôt que d'en ajouter, le souterrain **redéfinit leur sens** :

| Rôle moteur | Sens en surface | **Sens au souterrain** |
|---|---|---|
| `water` | mer | **roche pleine** — le « vide » infranchissable, l'équivalent de la mer |
| `coast` | littoral | **bord de tunnel** |
| `land` | terre | **tunnel** circulable et constructible |
| `obstacle` | rocher | **éboulis** dégageable |
| `resource` | gisement | **veine** (cyan He3) |
| `oil` | flaque de pétrole | **poche de gaz** (jaune + bulles) |

**Pourquoi ça marche sans toucher au moteur :** `buildIslandTiles()` promeut
automatiquement toute tuile `land` adjacente à `water` en `coast`. Le liseré de bord de
tunnel se fabrique donc **tout seul**, et `coastCliffPieces()` pose les `i7_mur_*` au bon
endroit. Zéro système neuf — c'est le même code qui dessine une côte et une paroi de galerie.

La roche pleine réutilise le **bruit procédural de l'eau** : masse continue sans motif
répétitif visible, exactement le rôle de la mer. Plus un veinage minéral léger.

**Hiérarchie de luminance** (c'est elle qui fait la lisibilité) :

| Tuile | Luminance |
|---|---|
| roche pleine | **31** |
| bord de tunnel | 66 |
| poche de gaz | 71 |
| tunnel | **78** |
| veine | 88 |

Séparation de 2,5× entre le plein et le circulable. En surface le plein (obstacle) est plus
sombre que le sol mais reste dans la même famille ; ici l'inversion est franche, parce que
la question « où puis-je aller » doit se lire instantanément.

**Deux tuiles supplémentaires :**
- `tile_i7_gaz_cache` — visuellement **identique à la roche pleine**. Le brief (§8) dit que
  les poches sont cachées et qu'on perd l'affordance « la tuile clignote ». Ce sprite permet
  au moteur de stocker un terrain distinct **sans le montrer** ; une fois foré, on bascule
  sur `tile_i7_oil`.
- `tile_i7_wall` — variante de la roche pleine avec liseré périmétrique, si tu veux lire la
  maille sur certaines zones.

### Élévateur — 4 sprites, 2 cadrages différents

**Surface = tuile vue de dessus, opaque, plein cadre** (même traitement que
`tile_port_terre` : c'est du terrain aménagé, pas un bâtiment posé dessus).
On regarde la cage par le haut : dalle béton, cadre métallique, rails latéraux,
toit de cabine centré, marquage de sécurité orange.

| Fichier | Usage |
|---|---|
| `tile_i6_elevateur_casse` | état initial — cage béante (trou noir), poutres effondrées, rails arrachés, dalle fissurée |
| `tile_i6_elevateur` | réparé — toit de cabine, treuil, témoin cyan, gyrophares, bornes de commande |

**Souterrain = bâtiment vue de côté, fond transparent** (même traitement que
`mine_fer_v1`). On voit la cabine dans sa gaine, l'arrivée du puits par le haut,
les portes au niveau du sol.

| Fichier | Usage |
|---|---|
| `bat_elevateur_casse` | gaine vide, câble rompu qui pend, éboulis au pied, seuil abîmé |
| `bat_elevateur` | cabine à quai portes ouvertes, contrepoids, treuil, afficheur d'étage, quai + conteneur |

Palette officielle bâtiments : contour `#161A22`, inox `#404652`→`#A5A8B2`,
trim orange `#FF9628`, accent cyan `#4FC3F7`. Cassé et réparé partagent la même
structure porteuse → la réparation se lit comme une transformation, pas un remplacement.

## Bâtiments — 12 sprites (Excel lignes 72–83)

Accent **signature** par famille, pour distinguer d'un coup d'œil :
tungstène `#C2CBD6` · supraconducteur `#4FC3F7` · quantique `#B47CFF` ·
géothermie `#FF6B3D` · He3 `#7FE6F0` · méthane `#FFD166`.

### Dérivés des sprites officiels (pas redessinés)

Deux bâtiments réutilisent directement les assets existants :

| Sprite | Dérivé de | Méthode |
|---|---|---|
| `mine_tungstene_v1/v2/v3` + 3 sheets d'anim | `mine_fer_*` | swap de **2 couleurs** — le système décodé sur les 6 minerais existants (uranium, or, pierre… ne changent que `#969EAA` et `#757B84`) |
| `four_arc_tungstene` | `four_arc_acier` | swap des **7 couleurs de corps**, comme le fait `four_arc_meca` ; contour, arc électrique, trim orange et braise intacts |

Teinte tungstène : `#C2CBD6` / `#8A94A2` (blanc-métal bleuté). Bijection couleur vérifiée
dans les deux cas → structure officielle préservée au pixel près.

**Bug corrigé au passage :** les 18 sheets d'animation de mine officielles violent toutes
l'invariant « frame 0 == sprite statique » (3 px sur v1, 6 sur v2, 5 sur v3 — le foret est
en position basse sur le statique et haute sur frame 0). Défaut systématique et identique
sur les 6 minerais, donc issu du générateur d'origine. Les sheets tungstène ont leur frame 0
réécrite avec le sprite statique ; les frames 1–3 gardent le cycle, l'animation reste fluide.
**Les 18 sheets d'origine restent à corriger de la même façon si tu veux l'invariant partout.**

### Collisionneur — 4 états de réparation

64×96 (2×3). Les paliers du brief donnent naturellement 4 états :

| Sprite | Palier | Lecture |
|---|---|---|
| `bat_collisionneur_ruine` | trouvé en ruine | anneau **brisé en 4 secteurs**, cratère au centre, toiture effondrée, tout en brun/rouille |
| `bat_collisionneur_p1` | béton armé irradié + acier irradié + pièce de précision | génie civil refait : anneau complet et gris, halls debouchés, **mais tout est éteint** — emplacements d'aimants vides |
| `bat_collisionneur_p2` | câble supraconducteur | les **12 aimants supra** sont posés et alimentés (cyan), tube sous vide, cœur encore froid |
| `bat_collisionneur` | ordinateur quantique | opérationnel : **faisceau violet**, cœur en collision, cuve de matière exotique pleine |

Gradient de lecture voulu : brun troué → gris complet → points cyan → anneau violet.
Lisible même à 1× (vérifié).

### Surface (4 autres)
| Sprite | Lecture visuelle |
|---|---|
| `bat_machine_outil` | bâti d'usinage, portique + broche verticale, pièce en cours, copeaux |
| `bat_presse_uhp` | colonnes massives + vérin + chambre de compression cyan, bobine de câble en sortie |
| `bat_fab_ordi_quantique` | salle blanche claire + **cryostat en lustre** suspendu (violet), baies or/cyan |
| `bat_data_center` | 3 rangées de racks, LEDs **multicolores = saveurs aléatoires**, ventilation en toiture |

### Souterrain (5)
| Sprite | Lecture visuelle |
|---|---|
| `bat_foreuse` | tête de forage sur chenilles, foret hélicoïdal, pointe carbure — lisible comme un **outil**, pas une usine (c'est une action) |
| `bat_geothermie` | turbine + tête de puits avec colonne de chaleur montante + cheminée de vapeur |
| `bat_extracteur` | tête de puits « arbre de Noël » + vannes + cuves de collecte |
| `bat_separateur_cryogenique` | **3 colonnes de distillation = 3 sorties**, chacune sa couleur (méthane jaune / He3 cyan / He4 blanc), givre cryogénique |
| `bat_centrale_gaz` | turbine + chambre de combustion visible + cheminée + transfo |

## Icônes ressources — 11 icônes (Ressources L36–45 + Information quantique)

16×16 RGBA. Conventions relevées sur les 30 icônes officielles : contour **`#1C1E26`**
(les items ont leur propre contour, plus clair que le `#161A22` des bâtiments),
4–11 couleurs, 56–138 px, marge de 1–2 px, et **éclairage clair à gauche / sombre à droite**
— l'inverse des bâtiments, qui s'éclairent par le haut.

Les icônes officielles ne sont **pas** des palette-swaps entre elles (chacune est dessinée),
mais elles partagent des **familles de forme**. J'ai extrait deux masques et les réutilise :
la goutte de `item_eau` pour tous les fluides, le lingot de `item_lingot_fer` pour l'alliage.

| Icône | Famille | Lecture |
|---|---|---|
| `item_tungstene` | minerai brut | amas de cailloux, blanc-métal bleuté + éclats |
| `item_alliage_tungstene` | lingot | masque `item_lingot_fer`, teinte tungstène |
| `item_piece_precision` | composant | engrenage à alésage + trous d'allègement, plus fin que `item_piece_meca` |
| `item_cable_supraconducteur` | bobine | spires cyan + points de givre (câble qui ne chauffe pas) |
| `item_ordinateur_quantique` | composant | boîtier sombre + cryostat violet étagé |
| `item_information_quantique` | — | sphère de Bloch + **4 points de couleurs différentes** : seule icône du jeu qui doit signaler une valeur variable (saveur aléatoire) |
| `item_gaz_fossiles` | goutte | brun-vert trouble = mélange non raffiné |
| `item_helium3` | goutte | cyan pâle lumineux, même accent que la poche He3 des tuiles |
| `item_helium4` | goutte | blanc-gris **volontairement terne** à côté du He3 → se lit « sous-produit » |
| `item_methane` | goutte | jaune flamme, même accent que la centrale à gaz |
| `item_matiere_exotique` | — | cristal octaédrique violet + halo, l'icône la plus chargée du pack (ressource de victoire) |

Les 4 fluides partagent la goutte mais restent distinguables à 16 px (vérifié).

## Bordures de tunnel — 16 pièces (remplacent les murs v1)

**Les falaises ne pouvaient pas marcher, et il a fallu deux essais pour comprendre pourquoi.**

Une falaise encode un point de vue précis dans sa géométrie : sommet clair (herbe) →
paroi qui **s'assombrit vers le bas** → écume claire au pied. Ça dit « je surplombe une
étendue en contrebas ». Repeindre ça en brun donne forcément une impression de mer,
quelle que soit la palette — c'est la structure qui parle, pas la couleur.

Deuxième problème, invisible au premier coup d'œil : le masque `falaise_s` occupe une
bande de 14 px **en haut de tuile**, alors que la frontière roche/tunnel se trouve **au
bord** de la tuile. L'arête et l'ombre tombaient donc à 18 px de la vraie frontière —
une bande claire flottant en pleine roche.

### La correction

On abandonne les masques de falaise. Les bordures sont générées sur les **arêtes de
tuile**, et surtout elles se posent sur la **tuile de SOL**, pas sur la roche :

```
tuile ROCHE          tuile TUNNEL (sol)
(pleine, sombre)     y=0   liseré clair — arête de roche taillée
                     y=1   ombre portée (forte)
--- bord de tuile -- y=2-8 ombre dégressive
                     y=9+  sol en pleine lumière
```

C'est le sol qui reçoit l'ombre de la roche voisine — exactement ce qu'on voit en vue de
dessus quand une masse est plus haute que son environnement. **Sans cette ombre portée,
aucune lecture de surplomb** ; c'était le vrai élément manquant.

Profil vérifié sur le raccord : roche 35 → **liseré 93** → ombre 20 → remontée
progressive → sol 78. Le pic clair suivi du creux sombre, c'est ça qui fait l'arête.

### Les 16 pièces — nommage aligné sur le code

**Correction v2.5.** Le nommage suit la sémantique de `tunnelBorderPieces()`, qui n'est
pas l'intuition géométrique :

| Clé | Cas de voisinage | Forme |
|---|---|---|
| `i7_bord_n/e/s/w` | roche sur **un** côté | bord plein |
| `i7_bord_ext_<d>` | roche sur **deux** côtés adjacents | deux bords qui se rejoignent |
| `i7_bord_coin_<d>` | roche en **diagonale seule** | petit quart |
| `i7_bord_chenal_<d>` | = `i7_bord_<d>` | le code **empile deux pièces** pour un couloir |

**Ce qui n'allait pas :** `coin` et `ext` étaient inversés, et `chenal` dessinait un U à
trois côtés. En jeu, une case avec de la roche sur deux côtés recevait un petit quart —
donc **les angles n'avaient pas de paroi** — et les galeries étroites se bouchaient
visuellement. C'est ce qu'on voyait sur le screenshot du souterrain.

Vérifié en réimplémentant `tunnelBorderPieces()` à l'identique : un angle montre
maintenant liseré (93) → ombre (20) → remontée sur **ses deux bords**, et le sol
intérieur reste plat à 78.

## Icône de l'île 6 — `ile_6.png` + `ile_6_gris.png`

J'avais d'abord fait des pastilles 16×16 au format `ui_*` : c'était le mauvais format.
Les icônes d'île existent déjà sous `ile_1..ile_5.png`, et c'est autre chose.

Format décodé sur les 5 officielles :

- **64×64**, silhouette d'île vue de dessus, posée sur une grille de 4 px
- **exactement 8 couleurs**, en 3 anneaux concentriques :
  - cœur → les **3 tons de `tile_i<N>_land`**, repris tels quels
  - bordure → les **4 tons de `tile_i<N>_coast`**
  - halo → **écume `#CEE7EC`**, identique sur les 5 îles
- ~2 px de côte autour de la terre, ~2 px d'écume autour de la côte
- variante `_gris` désaturée pour l'état verrouillé

La palette est lue directement depuis `tile_i6_land` et `tile_i6_coast`, donc l'icône
est automatiquement raccord avec la carte de l'île.

**Forme :** l'île 6 est la seule à avoir deux zones (surface + souterrain). Sa silhouette
reprend cette dualité — une masse principale et un satellite reliés par un isthme étroit,
là où se trouve l'élévateur. Les 5 autres îles ont chacune une forme distincte, donc en
avoir une reconnaissable comptait.

Métriques : 2014 px opaques, 8 couleurs (officielles : 1009–2271 px, 8 couleurs).

## Couche logique — sections 3 à 7 du brief (33 fichiers)

**Vérifié sur la source live avant production** (Alpha 13.88 / build 269) :

- **§1 Fils** — les 8 clés dites manquantes existent **toutes** dans le pack. Rien à faire.
- **§2 Portes** — NAND/NOR/XOR/XNOR déjà livrées, plus BUF. Rien à faire.
- **Portes `_on`** — **inutiles, confirmé**. Ligne ~18876 : le code peint une pastille
  d'état par-dessus le sprite (`ctx.fillStyle = on ? '#00E5A0' : '#0d5a45'`). Aucun sprite
  `_on` de porte n'est lu. Produire les 4 aurait été du gâchis.
- **État 1** — reste **blanc `#F0F0F4`**. Le code utilise un vert `#00E5A0` pour sa
  pastille ; les deux coexistent (pastille verte sur fil blanc).

### §3 Émetteurs α β γ — 7 sprites

Glyphes grecs **dessinés à la main** : la police du jeu n'a que l'alphabet latin.
5×7 px, même gabarit que les majuscules officielles.

Point critique du brief : le glyphe doit rester lisible à l'état `on`. Le halo blanc
n'entoure donc que le **pourtour** du cartouche, il ne passe jamais sur le glyphe.

`logic_emetteur_inactif` se lit **inerte** et non éteint : plaque pleine boulonnée avec
hachures, pas un cartouche noir qui suggérerait un bug.

### §4 Vanne — 3 sprites + 1 sheet

L'état se lit à la **silhouette** autant qu'à la couleur : volant en diagonale = fermé,
volant aligné sur les axes = ouvert. Lisible même sans distinguer les couleurs.

`logic_vanne_penalite` : rouge `#FF5C5C`, croix d'alerte, coins rouges, et le trim orange
vire au rouge. Sheet de 3 frames pour le flash. C'est le feedback le plus coûteux du jeu,
il ne devait pas être ambigu.

### §5 Jonction — 4 sprites

Convention : **l'axe E-O passe au-dessus**. Il est continu ; l'axe N-S est interrompu par
un tablier métallique et une ombre portée, ce qui montre physiquement qu'il plonge dessous.
Sans ça le joueur croit à une connexion.

### §6 Collisionneur — 9 sprites + 3 sheets

Format 64×96 (comme `bat_collisionneur_*` déjà lu par le code), pas les 6 tuiles
`tile_i6_collisionneur_*` qui servent à l'état ruine.

Un **ajout structurel par palier**, même logique que le « V2 tell » :

| Palier | Ajout | px |
|---|---|---|
| P1 | anneau simple, 12 aimants | 3756 |
| P2 | + anneau de renfort extérieur, 16 aimants | 4096 |
| P3 | + 4 tours d'injection, 20 aimants, cœur rayonnant | 4379 |

Les 3 modes : `off` (éteint), `_boot` (cyan, démarrage), `_actif` (violet, quarks).
Le boot est **visiblement différent** de l'actif — sinon le joueur croit la machine cassée
pendant 10 minutes.

Sheets de 4 frames, sigmoïde terminée à mi-parcours. **Frame 0 = statique éteint**,
invariant vérifié sur les 3.

### §7 Data Center — 4 sprites

Le bus s'élargit visiblement : 3 pistes verticales à gauche, éclairées selon le niveau
(3 → 6 → 9 px blancs), avec le glyphe α/β/γ correspondant gravé sur le boîtier. C'est
l'information utile au joueur : combien de bits il devra comparer.

Le v4 change de registre — plus de bus à montrer, mais un bandeau de débit cyan.

## Flèches d'élévateur — 2 tuiles

`tile_elevateur_fleche_bas` / `_haut`. Posées sur la tuile d'élévateur, qui est un
**terrain** partagé entre les deux grilles (source ~18508).

Flèche blanche sur cartouche sombre : elle doit se lire par-dessus n'importe quel fond.
Liseré **orange** pour descendre (surface → souterrain), **cyan** pour remonter — le cyan
étant déjà l'accent du souterrain dans le pack. Chevrons latéraux qui renforcent le sens.

## Liste logique unifiée + animations (v2.6)

Quatre décisions qui **diffèrent du code actuel** — les sprites sont livrés dans la forme
demandée, chacune demande un ajustement d'une ligne côté moteur :

### 1. Senseur unique

Un seul visuel de senseur (`logic_senseur_<dir>_<0|1>`), **pas un par type**. Le code
(~18863) choisit aujourd'hui plein/vide/contient selon `sensorMode` ; il faut simplifier
cette ligne en un `logic_senseur` unique. Des alias `plein`/`vide`/`contient` pointent sur
le même visuel pour ne rien casser en attendant. Le **type de condition est un réglage**,
il se lit dans le panneau de config, pas sur la tuile.

### 2. État 0/1 sur le sprite

Chaque composant porte un **bandeau d'état** : barre en haut + témoin de coin. **Blanc
plein = 1, noir creux = 0** (ta convention). Ça remplace la pastille verte que le code
peint par-dessus (~18884) — à retirer côté moteur pour ces composants, sinon les deux
s'affichent. Chaque composant existe en `_0` et `_1`.

### 3. Flèches dans chaque sens

Tous les composants orientables livrés en `_n/_e/_s/_o`, la flèche **dessinée dans le
sprite**. Elle est blanche si le signal est à 1, grise à 0 — même teinte que le fil.

### 4. Actionneur

`logic_actionneur_<dir>_<0|1>` (un relais). Le code le faisait pointer sur le sprite du
collisionneur faute de mieux ; côté moteur : `base = logicSink ? 'logic_actionneur' : …`.

### Contenu

| Composant | Sprites |
|---|---|
| Senseur unique (+ alias) | 8 + 12 alias |
| Actionneur | 8 |
| Portes (7) | 7 × 4 dir × 2 états + 7 × 4 sans état = 84 |
| Bloc α | 8 |
| Bloc α β | 8 |
| Bloc α β γ | 8 |
| Vanne collisionneur | 8 + 1 pénalité |

Les blocs montrent 1/2/3 cartouches grecs = le nombre de bits émis. La vanne lit sa
silhouette (volant en diagonale = fermé, en croix = ouvert), lisible sans couleur.

### Badge pause logique

`ui_pause_logique.png` — 16×16, pastille cyan, deux barres de pause. Les badges du jeu
sont dessinés en texte (`drawBadge`) ; celui-ci est une **icône** au format `ui_*`.

## Animations des bâtiments île 6 — 9 sheets

Format du pack : 4 frames horizontales, boucle G→D, **frame 0 = statique exact**
(invariant vérifié à 0 px sur les 9). On anime uniquement les zones vivantes par-dessus le
sprite existant, le reste ne bouge pas → boucle propre.

| Bâtiment | Animation |
|---|---|
| `four_arc_tungstene` | arc électrique cyan qui crépite |
| `machine_outil` / `foreuse` | tête de forage, chevrons qui défilent + étincelles |
| `presse_uhp` | piston vertical + éclair de pression en bas |
| `fab_ordi_quantique` | cœur violet pulsant + qubits scintillants |
| `geothermie` | panache de vapeur qui monte |
| `extracteur` | bulles de gaz jaunes qui remontent |
| `separateur_cryogenique` | givre scintillant + gouttes de condensat |
| `centrale_gaz` | flamme de torchère qui vacille |

La clé d'anim est le nom sans `bat_` ; le moteur retrouve le sprite statique via
`[cle, 'bat_'+cle, cle+'_v1']`, comme pour les mines tungstène.

## Batterie V2 — `bat_accumulateur_v2.png`

Le bâtiment s'appelle `accumulateur` dans le code (pas « batterie »), et il n'a pas encore
de V2 déclarée — c'est donc un asset pour la récompense île 6. Le nom suit la paire
officielle `bat_broyeur` → `bat_broyeur_v2`, donc il se résoudra tout seul via le candidat
`'bat_'+id` quand l'id `accumulateur_v2` sera ajouté.

**La convention V2 est décodée sur les 7 paires officielles du pack**
(`four_fer`, `four_cuivre`, `betonniere`, `cimenterie`, `bat_broyeur`, `pompe_eau`,
`centrale_charbon`) — pas inventée :

| Règle | Relevé |
|---|---|
| Repeint slate-steel | Les gris **neutres** glissent vers le bleu-acier : `#929496`→`#788596`, `#6C6E72`→`#3C4654` (mapping pur extrait de `betonniere`, masque identique) |
| Signatures préservées | Sur `betonniere`, `#78B4C8` / `#967846` / `#B49054` restent **inchangés**. Seuls les gris bougent |
| Contour | `#161A22` ne bouge jamais |
| Trim orange | **Une seule rangée pleine largeur** : 22 px sur `betonniere_v2`, 20 px sur `cimenterie_v2` |
| Cyan | Très sobre : 6 à 8 px par bâtiment |
| Ajout structurel | Optionnel : `four_fer` 354→541 px, `pompe_eau` 432→512, mais `betonniere`/`cimenterie` gardent le masque exact |

**Application à la batterie :** le vert `#5AE68C` est la couleur **signature** (la charge),
il est donc préservé tel quel — seul le châssis passe en slate. Virage vérifié sur le
châssis seul : dominante bleue +16 → +24.

**L'ajout structurel choisi** est un collecteur cryogénique reliant les deux bornes du
dessus. La Batterie V2 est une récompense de l'île 6, celle du câble supraconducteur et du
séparateur cryogénique — un collecteur refroidi dit « même emprise, deux fois la capacité »
sans agrandir le bâtiment, ce qui serait de toute façon impossible : la v1 occupe déjà
y=5..30.

Le trim orange est posé sur y=24, la seule rangée de métal **uniforme** du banc de cellules.
Les rangées 10..23 portent les séparateurs verticaux (y toucher casserait la lecture des
5 cellules) et y=8 est le highlight haut du corps (l'écraser aplatirait le volume). Résultat :
un jonc juste au-dessus de la jauge, qui se lit comme un encadrement d'afficheur.

La jauge passe à pleine largeur — capacité ×2, conforme à la note « upgrade ×2 cap ».

Métriques : 613 → **689 px**, 13 → 17 couleurs, trim 22 px sur 1 rangée, cyan 8 px.
Tout dans les fourchettes officielles.

## Vérifications faites
- bijection couleur avec `tile_i5_*` → structure officielle préservée
- tiling 4×4 sans couture (land / water / coast, i6 et i7)
- 4 triangles de côte cohérents avec `coast` + demi-diagonale `land`
- tuiles terrain **et tuile élévateur surface** 100 % opaques ; bâtiments souterrains transparents

## Intégration
Copier dans `sprites/`. Clés `tile_i6_*` / `tile_i7_*` suivent la nomenclature
existante — aucun code de résolution à modifier. Pour l'élévateur, la résolution
`bat_<id>` fonctionne telle quelle.

**Attention — cohérence à vérifier (§ Excel) :** la ligne 75 note la presse UHP comme « Souterrain » alors que le § 2 du brief la place en surface (elle consomme du câble irradié importé de l'île 5, et l'élec ne descend pas). J'ai fait le sprite sans hypothèse de zone — il marche des deux côtés — mais la ligne Excel est à trancher.

**Note :** ce pack est de l'asset, pas du code de jeu. Rien n'a été touché dans
`Archipel_industry_alpha-7.html`.

## Reste à faire
- Variante de `coastCliffPieces()` pour le souterrain (prédicat roche/vide)
- Versions V2 des bâtiments (récompenses île 6) si besoin
