#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Bordures de TUNNEL (ile 7) v4
=================================================

LE DIAGNOSTIC
-------------
Les falaises du jeu encodent un point de vue : "je surplombe une etendue en
contrebas". Sommet clair (herbe) -> paroi qui s'assombrit -> ecume claire au
pied. Repeindre cette geometrie donne forcement une impression de mer, quelle
que soit la palette. En plus, le masque falaise_s occupe une bande de 14 px en
HAUT de tuile, alors que la frontiere roche/tunnel se trouve au BORD de tuile.

LA CORRECTION
-------------
On ne herite plus des masques de falaise. On genere des bordures collees aux
ARETES de tuile, et surtout on les pose sur la TUILE DE SOL, pas sur la roche :

    tuile ROCHE                    tuile TUNNEL (sol clair)
    (pleine, sombre)               +-- y=0  ombre portee du surplomb (fort)
                                   |   y=1  ombre (degressif)
    ------- bord de tuile -------  |   y=2  ombre (faible)
                                   +-- y=3+ sol du tunnel, pleine lumiere

C'est le sol qui recoit l'ombre de la roche voisine. Exactement ce qu'on voit
dans un jeu vu de dessus : la masse rocheuse est plus haute que le sol, donc
elle projette sur lui. Sans cette ombre, aucune lecture de surplomb.

On ajoute aussi un LISERE CLAIR de 1 px cote roche (l'arete taillee qui accroche
la lumiere), dessine sur le meme sprite, en debord de 1 px vers la roche.

Nommage : 'i7_bord_<dir>' pour les 4 aretes, 'i7_bord_coin_*' pour les coins
rentrants, 'i7_bord_ext_*' pour les coins sortants. La logique de voisinage
reste celle de coastCliffPieces() (meme arbre de decision), seuls les noms et
le rendu changent.
"""
from PIL import Image
import numpy as np, os

OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


# arete de roche taillee, eclairee par la geothermie du tunnel
EDGE_HI  = hx('#8A7358')
EDGE_MID = hx('#5E4E3C')

# profil d'ombre portee sur le sol, du plus proche de la roche au plus loin
SHADOW = [190, 150, 112, 78, 50, 28, 14, 6]


def blank():
    return np.zeros((32, 32, 4), np.uint8)


def put(a, x, y, rgb, alpha):
    if 0 <= x < 32 and 0 <= y < 32:
        a[y, x] = (rgb[0], rgb[1], rgb[2], alpha)


def shade(a, x, y, alpha):
    if 0 <= x < 32 and 0 <= y < 32 and alpha > 0:
        a[y, x] = (0, 0, 0, alpha)


def edge_piece(direction):
    """Bordure droite : la roche est du cote 'direction'.
    Pose sur la tuile de SOL. Lisere clair au contact, puis ombre degressive."""
    a = blank()
    rng = np.random.RandomState(hash(direction) % 9999)
    for i in range(32):
        # lisere de roche taillee, 1 px, irregulier
        lit = EDGE_HI if (i * 5) % 7 < 3 else EDGE_MID
        if direction == 'n':
            put(a, i, 0, lit, 255)
            for k, al in enumerate(SHADOW):
                shade(a, i, 1 + k, al)
        elif direction == 's':
            put(a, i, 31, lit, 255)
            for k, al in enumerate(SHADOW):
                shade(a, i, 30 - k, al)
        elif direction == 'w':
            put(a, 0, i, lit, 255)
            for k, al in enumerate(SHADOW):
                shade(a, 1 + k, i, al)
        elif direction == 'e':
            put(a, 31, i, lit, 255)
            for k, al in enumerate(SHADOW):
                shade(a, 30 - k, i, al)
    return a


def corner_inner(d1, d2):
    """Coin rentrant : roche sur deux cotes adjacents (ex. n + w).
    Les deux ombres se cumulent naturellement dans l'angle."""
    a = edge_piece(d1)
    b = edge_piece(d2)
    out = blank()
    for y in range(32):
        for x in range(32):
            pa, pb = a[y, x], b[y, x]
            # priorite au lisere opaque
            if pa[3] == 255:
                out[y, x] = pa
            elif pb[3] == 255:
                out[y, x] = pb
            else:
                # cumul des deux ombres (compositing alpha)
                al = 255 - (255 - int(pa[3])) * (255 - int(pb[3])) // 255
                if al:
                    out[y, x] = (0, 0, 0, min(al, 220))
    return out


def corner_outer(dx, dy):
    """Coin sortant : la roche n'occupe QUE le quart diagonal.
    Ombre courte, en quart de disque."""
    a = blank()
    cx = 0 if dx == 'w' else 31
    cy = 0 if dy == 'n' else 31
    for y in range(32):
        for x in range(32):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            k = int(d)
            if k == 0:
                put(a, x, y, EDGE_HI, 255)
            elif 1 <= k <= len(SHADOW):
                shade(a, x, y, SHADOW[k - 1])
    return a


def channel(missing):
    """Chenal : le code EMPILE deux pieces pour un couloir.

    Pour roche au N et au S, tunnelBorderPieces renvoie
        ['i7_bord_chenal_n', 'i7_bord_chenal_s']
    -> chaque piece ne represente donc QU'UN SEUL bord, pas un U a 3 cotes.

    La v1 dessinait un U (roche sur 3 cotes), ce qui remplissait le couloir de
    paroi des deux cotes ET sur le fond : les galeries etroites se bouchaient
    visuellement. On renvoie simplement le bord correspondant.
    """
    return edge_piece(missing)


PIECES = {}
for d in ['n', 'e', 's', 'w']:
    PIECES[f'i7_bord_{d}'] = edge_piece(d)

# ATTENTION AU NOMMAGE - il suit la SEMANTIQUE DU CODE, pas l'intuition
# geometrique. Dans tunnelBorderPieces() :
#
#   n == 0  (aucun bord cardinal, roche en DIAGONALE seulement)
#           -> 'i7_bord_coin_<d>'   = petit quart, la roche ne touche que le coin
#   n == 2  (roche sur DEUX cotes adjacents)
#           -> 'i7_bord_ext_<d>'    = deux bords pleins qui se rejoignent
#
# La v1 avait l'inverse (coin = deux bords, ext = quart), ce qui produisait en
# jeu des angles SANS paroi et des bouts de mur flottants la ou la roche n'etait
# qu'en diagonale. Bug visible sur le screenshot du souterrain.
for d1, d2, nm in [('n', 'w', 'nw'), ('n', 'e', 'ne'),
                   ('s', 'w', 'sw'), ('s', 'e', 'se')]:
    PIECES[f'i7_bord_ext_{nm}'] = corner_inner(d1, d2)
for dx, dy, nm in [('w', 'n', 'nw'), ('e', 'n', 'ne'),
                   ('w', 's', 'sw'), ('e', 's', 'se')]:
    PIECES[f'i7_bord_coin_{nm}'] = corner_outer(dx, dy)
for m in ['n', 'e', 's', 'w']:
    PIECES[f'i7_bord_chenal_{m}'] = channel(m)


if __name__ == '__main__':
    for name, a in PIECES.items():
        Image.fromarray(a, 'RGBA').save(os.path.join(OUT, name + '.png'))
        print(name + '.png')
    # retirer les pieces v1/v2 devenues obsoletes
    for p in ['s', 'e', 'w', 'coin_ne', 'coin_nw', 'coin_se', 'coin_sw',
              'crique_se', 'crique_sw', 'U_s', 's_ew']:
        for pref in ('i7_mur_', 'i7_ombre_'):
            f = os.path.join(OUT, pref + p + '.png')
            if os.path.exists(f):
                os.remove(f)
                print('SUPPRIME ' + pref + p + '.png')
