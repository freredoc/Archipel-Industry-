#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Batterie V2 (accumulateur V2)
=================================================

CONVENTION V2 DECODEE sur les paires officielles du pack
--------------------------------------------------------
7 paires v1/v2 existent deja (four_fer, four_cuivre, betonniere, cimenterie,
bat_broyeur, pompe_eau, centrale_charbon). En les comparant pixel a pixel :

  1. REPEINT SLATE-STEEL. Les gris NEUTRES glissent vers un bleu-acier.
     Mapping releve sur betonniere (masque identique -> mapping pur) :
        #929496 -> #788596     #B0B2B4 -> #9EAAB9
        #6C6E72 -> #3C4654     #686E7A -> #3C4654
     Palette slate officielle : #262E3A #2A3240 #3C4654 #444A56 #566272
                                #686E7A #788596 #9096A2 #9EAAB9

  2. COULEURS SIGNATURE PRESERVEES. Sur betonniere, #78B4C8 / #967846 /
     #B49054 / #D7D3C8 restent INCHANGES. Seuls les gris bougent. Le contour
     #161A22 ne bouge jamais.

  3. TRIM ORANGE #FF9628. Sur betonniere, 12 px de #363A44 deviennent du
     #FF9628 : un lisere orange apparait la ou il y avait du gris sombre.

  4. ACCENT CYAN #4FC3F7 (ou #5AC8FF / #3FA5DC selon le batiment).

  5. UN AJOUT STRUCTUREL. Certaines V2 gardent le masque exact (betonniere,
     cimenterie, centrale_charbon = repeint pur) mais d'autres grossissent :
     four_fer 354 -> 541 px, pompe_eau 432 -> 512, broyeur 586 -> 594.

CE QUE FAIT CETTE BATTERIE V2
-----------------------------
Base : bat_accumulateur.png (v1), dont la structure est
    y=5..7   deux bornes sur le dessus
    y=9      bandeau de temoins (2 verts + 1 orange)
    y=10..24 banc de 5 cellules
    y=13..14 glyphe eclair au centre
    y=25     JAUGE DE CHARGE (vert #5AE68C, remplie a ~55%)
    y=26..30 socle + 3 pieds

Le vert #5AE68C / #AAFFC8 est la couleur SIGNATURE de la batterie (la charge) :
il est donc preserve tel quel, comme le veut la convention. Seul le chassis
passe en slate.

L'ajout structurel choisi est un COLLECTEUR CRYOGENIQUE reliant les deux bornes
sur le dessus. Raison : la Batterie V2 est une recompense de l'ile 6, et l'ile 6
est justement celle du cable supraconducteur et du separateur cryogenique. Un
collecteur refroidi dit "meme volume, deux fois la capacite" sans avoir a
agrandir le batiment - ce qui serait impossible, v1 occupe deja y=5..30.

La jauge passe a pleine largeur (capacite x2) avec des graduations cyan.
"""
from PIL import Image
import numpy as np, os

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


# ---- mapping chassis v1 -> slate-steel V2 ----------------------------------
# Trie par luminance pour conserver exactement le modele d'ombrage de la v1.
SLATE = {
    hx('#969CA8')[:3]: hx('#9EAAB9'),    # metal clair    (L)
    hx('#7C8290')[:3]: hx('#788596'),    # clair          (l)
    hx('#585E6C')[:3]: hx('#566272'),    # metal dominant (m)
    hx('#484A54')[:3]: hx('#444A56'),    # socle          (f)
    hx('#464C5A')[:3]: hx('#3C4654'),    # separateur     (d)
    hx('#3A404C')[:3]: hx('#3C4654'),    # ombre          (e)
    hx('#3C3E46')[:3]: hx('#36404E'),    # socle mid      (g)
    hx('#303642')[:3]: hx('#2A3240'),    # creux cellule  (D)
    hx('#2A2C32')[:3]: hx('#262E3A'),    # socle sombre   (k)
}

# ---- couleurs PRESERVEES (signature + contour) -----------------------------
KEEP = {
    hx('#161A22')[:3],   # contour, ne bouge jamais
    hx('#5AE68C')[:3],   # vert de charge  <- SIGNATURE de la batterie
    hx('#AAFFC8')[:3],   # vert clair (eclair + haut de jauge)
    hx('#FFB43C')[:3],   # temoin orange
}

ORA   = hx('#FF9628')
ORAD  = hx('#C46A12')
CYAN  = hx('#4FC3F7')
CYAND = hx('#2A7FA8')
CYANL = hx('#BFEFFF')
GRN   = hx('#5AE68C')
GRNL  = hx('#AAFFC8')
OUTL  = hx('#161A22')
SL_L  = hx('#9EAAB9')
SL_M  = hx('#788596')
SL_D  = hx('#566272')
SL_DD = hx('#3C4654')


class Cv:
    def __init__(s, base=None):
        s.a = base.copy() if base is not None else np.zeros((32, 32, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < 32 and 0 <= y < 32:
            s.a[y, x] = c

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


def repaint_slate(a):
    """Applique le repeint slate-steel en preservant contour et signature."""
    out = a.copy()
    unknown = {}
    for y in range(32):
        for x in range(32):
            if a[y, x, 3] == 0:
                continue
            c = tuple(int(v) for v in a[y, x][:3])
            if c in KEEP:
                continue
            if c in SLATE:
                out[y, x, :3] = SLATE[c][:3]
            else:
                unknown[c] = unknown.get(c, 0) + 1
    return out, unknown


def batterie_v2():
    base = np.array(Image.open(f'{SRC}/bat_accumulateur.png').convert('RGBA'))
    slated, unknown = repaint_slate(base)
    c = Cv(slated)

    # ------------------------------------------------ 1. TRIM ORANGE (1 rangee)
    # Convention relevee : betonniere_v2 = 22 px sur UNE rangee (y=13),
    # cimenterie_v2 = 20 px sur UNE rangee (y=14). C'est donc bien un lisere
    # pleine largeur, sur une seule ligne.
    # On le pose sur y=24, la seule rangee de metal UNIFORME du banc de cellules
    # (les rangees 10..23 portent les separateurs verticaux, y toucher casserait
    # la lecture des cellules ; y=8 est le highlight haut du corps, l'ecraser
    # aplatirait le volume).
    # Resultat : un jonc orange juste au-dessus de la jauge, qui se lit comme un
    # encadrement d'afficheur.
    c.hline(5, 26, 24, ORA)
    c.px(4, 24, ORAD); c.px(27, 24, ORAD)

    # --------------------------- 2. AJOUT STRUCTUREL : collecteur cryogenique
    # Relie les deux bornes (x=6 et x=25) par un tube refroidi. C'est le "tell"
    # V2 : meme emprise au sol, capacite doublee grace au refroidissement.
    c.hline(6, 25, 3, OUTL)
    c.hline(6, 25, 6, OUTL)
    c.hline(7, 24, 4, SL_L)
    c.hline(7, 24, 5, SL_D)
    c.px(6, 4, OUTL); c.px(6, 5, OUTL)
    c.px(25, 4, OUTL); c.px(25, 5, OUTL)
    # fluide cryogenique : 2 hublots seulement. Les V2 officielles restent tres
    # sobres sur le cyan (6 a 8 px : betonniere 8, cimenterie 8, charbon 6).
    for hxx in (12, 19):
        c.px(hxx, 4, CYANL); c.px(hxx + 1, 4, CYAN)
        c.px(hxx, 5, CYAN);  c.px(hxx + 1, 5, CYAND)
    # brides sur les bornes
    for bx in (6, 25):
        c.px(bx - 1, 4, SL_M); c.px(bx + 1, 4, SL_M)

    # ------------------------------------ 3. JAUGE PLEINE LARGEUR (capacite x2)
    # v1 : jauge remplie de x=7 a x=19 (~55%). V2 : pleine sur toute la largeur.
    # Pas de graduations cyan : le budget cyan est deja pris par le collecteur,
    # et les V2 officielles restent a 6-8 px de cyan par batiment.
    c.hline(4, 27, 25, GRN)
    c.px(4, 25, GRNL); c.px(5, 25, GRNL)
    c.px(26, 25, GRNL); c.px(27, 25, GRNL)

    # ------------------------------------------- 4. TEMOINS : un de plus qu'en v1
    # v1 y=9 : 2 verts + 1 orange. V2 : 3 verts, l'orange de v1 est conserve.
    c.px(5, 9, GRN); c.px(7, 9, GRN); c.px(9, 9, GRN)

    # ------------------------------------------ 5. ECLAIR : coeur plus lumineux
    # Le glyphe eclair de la v1 (y=12..15, x~16) recoit un coeur blanc-vert :
    # la signature verte est conservee, seule son intensite monte.
    c.px(16, 13, hx('#E8FFF2')); c.px(17, 13, GRNL)
    c.px(16, 14, GRNL)

    return c, unknown


if __name__ == '__main__':
    c, unknown = batterie_v2()
    print(c.save('bat_accumulateur_v2.png'))
    if unknown:
        print('\nCouleurs v1 non mappees (a verifier) :')
        for k, n in sorted(unknown.items(), key=lambda z: -z[1]):
            print('   #%02X%02X%02X n=%d' % (k + (n,)))
    else:
        print('Toutes les couleurs du chassis sont mappees.')
