# Archipel Industry — textures, état v3.2

Extraction complète des textures du jeu, **pack « île6 v3.2 » appliqué**.

Source : `Archipel_industry_alpha-7.html` — **Alpha 14.29 / build 311 / SAVE_VERSION 31**.

| | |
|---|---|
| Fichiers | **1 427** PNG |
| dont inchangés | 1 307 |
| dont remplacés | 79 |
| dont nouveaux | 41 |
| Supprimés | 24 (`logic_bloc_alpha*`, orphelins) |

Quand une clé était définie plusieurs fois dans le HTML (mécanisme d'override par packs
successifs — la dernière affectation gagne au runtime), c'est **la version gagnante** qui a
été extraite, pas la première.

---

## Structure

```
sprites/     → window.__SPRITE_DATA__     (visuels statiques)
  batiments/  machines/  terrain/  mines/  reseaux/  logique/  items/  ui/
anim/        → window.__ANIM_DATA__       (spritesheets horizontales)
  batiments/  machines/  terrain/  logique/ …
MANIFEST.csv    inventaire complet
ANIM_META.json  métadonnées d'animation (frames / fw / fh / fps)
```

**Le nom de fichier est la clé**, sans exception. Les sous-dossiers ne servent qu'à la
navigation : `bat_cryostat.png` se réinjecte sous la clé `bat_cryostat` quel que soit son
dossier. Une même clé peut légitimement exister dans `sprites/` **et** `anim/` (le statique
et sa sheet) — voir les 6 clés `bat_collisionneur_pN_boot|actif`.

`MANIFEST.csv` : `cle, conteneur, famille, fichier, largeur, hauteur, frames, fw, fh, fps,
octets, etat`. La colonne `etat` vaut `inchangé` / `remplacé` / `nouveau` — c'est le journal
du pack v3.2.

---

## Comment ça remonte dans le HTML

```js
window.__SPRITE_DATA__["<clé>"] = "data:image/png;base64,…";
window.__ANIM_DATA__["<clé>"]   = "data:image/png;base64,…";
Object.assign(ANIM_META, { "<clé>": { frames, fw, fh, fps } });
```

Trois résolutions de clé cohabitent, à connaître avant de nommer un nouvel asset :

- **`buildingSpriteKey(id)`** teste `['bat_' + id, id, id + '_v1']` — donc nommer un sprite de
  bâtiment `bat_<id>` suffit, aucun override nécessaire.
- **`BLD_SPRITE_OVERRIDE`** ne sert qu'aux cas où le nom d'asset ne colle pas à l'id.
- **`ANIM_BY_SK`** fait le chemin inverse : pour une clé d'anim `cle`, il cherche le statique
  dans `[cle, 'bat_' + cle, cle + '_v1']`. D'où la règle : **les sheets de bâtiments 1×1 sont
  nommées sans le préfixe `bat_`** (`fonderie_or_v2`, `refroidisseur`, `cryostat`…), alors que
  les sheets du collisionneur gardent le nom complet.

**Exception : les tuiles `_breeze`.** Les 16 sheets `tile_iN_<terrain>_breeze` n'ont pas
d'entrée `ANIM_META` — elles passent par la table `TILE_ANIM_BY_KEY`, indexée par la clé de
**tuile statique**, avec une phase par tuile (`(t + r + c) % 4`) et `fps: 3`. Ce n'est pas un
oubli.

---

## Conventions de style

### Palettes

**V2 « slate-steel »** — le socle du jeu :
contour `#161A22` · ombre `#2A303A` · aciers `#414B59` `#4A5462` `#566272` `#727E8F` `#8B97A9`
· highlight `#B8C1CE` `#DCE3EC` · trim orange `#FF9628` (ombre `#C46618`, clair `#FFB450`)
· accents cyan `#4FC3F7` `#7FE6F0` `#3A96A4`.

**V4 « argenté »** — relevée sur les `mine_*_v4`, réservée au tier haut :
corps `#8A95A4` · ombre `#5E6978` `#4E5866` · clairs `#B8C1CE` `#C2CBD6` · blanc éclatant
`#DCE3EC` · accents violets `#B47CFF` `#E0D0FF` (présents sur **toutes** les mines V4 —
c'est la signature tier‑4).

### Machine claire / bâti sombre

Un objet qui porte les deux natures les sépare visuellement. Sur le Collisionneur :

| | P1 | P2 | P3 |
|---|---|---|---|
| **Machine** (couronnes, cavités RF, cœur, ligne de transfert, détection) | `#404652` → `#8C93A0` | `#4E525C` → `#B8C1CE` | `#5E6978` → `#C2CBD6` + `#DCE3EC` |
| **Bâti** (halls, coques, dalles, passerelles) | slate V2 `#2A303C` → `#646B78` | slate V2 | `#414957` → `#808894` |

Luminance moyenne mesurée, contours exclus : P1 bâti 55 < machine 76 · P2 61 < 93 · P3 88 < 121.
La même règle s'applique à la foreuse (carter V2, trépan V4) et au cryostat (socle éclairci,
cuve argentée).

### Animation

- **La frame 0 de toute sheet est pixel pour pixel identique au sprite statique** — c'est ce
  qui rend la transition statique → animé invisible. Vérifié sur les 15 sheets du pack v3.0.
- Sheets horizontales, lecture gauche → droite en boucle.
- 4 frames par défaut ; `logic_vanne_penalite` en compte 3.

### Divers

- Contour 1 px `#161A22` sur les silhouettes.
- Bâtiment 1×1 = **32 × 32** strict. Les exceptions actuelles : bâtiments 2×2 (64 × 64),
  collisionneur (96 × 64), foreuse (32 × 48 / 48 × 32).
- Densité utile d'un bâtiment 32 × 32 : ~540 à 650 px opaques sur 1 024. En dessous le sprite
  paraît maigre, au-dessus il sature la case.
- PNG palettisés, palette **exacte** (pas de quantification approchée — elle décalait
  `#8A95A4` en `#8A95A3`), puis passe `oxipng` sans perte.

---

## Cas particuliers du pack v3.2

### Collisionneur

L'art est désormais **nativement en paysage 96 × 64**. L'ancien pipeline dessinait en portrait
64 × 96 puis appliquait `ROTATE_270` — c'est fini.

`sprites/terrain/tile_i6_collisionneur[_pN]_0..5` : les 24 tranches 32 × 32 prêtes à l'emploi,
découpe `idx = ligne * 3 + colonne`, identique au rendu du terrain `collider`. La
recomposition des 6 tranches redonne le maître au pixel près.

Les sheets `_boot` (charge : seul le petit anneau) et `_actif` (fonctionnement : les deux
anneaux) sont **dormantes** : le rendu du landmark n'appelle que `drawSprite` sur les tranches.

### Foreuse

Le carter occupe la case, le foret déborde d'une **demi-case dans le sens de forage** :

| Clé | Taille | Offset de dessin |
|---|---|---|
| `bat_foreuse_n` | 32 × 48 | `(x, y - 16)` |
| `bat_foreuse_s` | 32 × 48 | `(x, y)` |
| `bat_foreuse_o` | 48 × 32 | `(x - 16, y)` |
| `bat_foreuse_e` | 48 × 32 | `(x, y)` |
| `bat_foreuse` | 32 × 32 | icône de menu, foret tronqué |

Ces cinq clés **ne sont pas encore injectées** dans le HTML : le rendu dessine en
`tile × tile` et les écraserait. Elles attendent le lot de rendu correspondant.

### Émetteur α β γ

Rose des vents, mapping fixe conforme au moteur : **α nord, β sud, γ ouest, VALIDE est**
(`dir 0→α, 1→β, 2→γ, 3→VALIDE`, ordre `[N, S, O, E]`). Accent par signal : orange, cyan,
violet, vert.

Deux jeux cohabitent :

- `logic_emetteur_{alpha,beta,gamma}[_on]` + `_inactif` — **utilisés par le rendu actuel**,
  cumul par palier (α seul → α+β → α+β+γ).
- `logic_emetteur_p{1,2,3}_<bits>` — **un sprite par combinaison** (2 + 4 + 8), dormants en
  attendant le sélecteur.
- `logic_emetteur_dc_*` — variante Data Center (liseré et noyau violets), dormante.

### Famille quantique + antenne V2 → coloris mine V4

Quatre sprites alignés sur le langage V4 :

| Clé | Méthode | Luminance moyenne (contour exclu) |
|---|---|---|
| `bat_usine_moteur_quantique` | redessiné | 122 |
| `bat_fab_ordi_quantique` | remappage de palette | 115 → **167** |
| `bat_stabilisateur_quantique` | remappage de palette | 81 → **143** |
| `bat_antenne_v2` | remappage de palette | 142 → **172** |

Référence : les `mine_*_v4` sont à 150–157 avec `#8A95A4` en gris dominant.

**Le remappage conserve la géométrie au pixel près.** Les gris neutres de chaque sprite sont
triés par luminance, le **plus fréquent est forcé sur `#8A95A4`** (c'est ce qui fait lire
« V4 »), les plus sombres se répartissent sous lui et les plus clairs au-dessus, ordre
préservé. Les couleurs signature — contour, trim orange, violets, cyans, or, verts — ne sont
jamais touchées. Le même mapping est appliqué au statique et à sa sheet, donc frame 0 reste
identique par construction.

L'échelle compte deux intermédiaires interpolés dans la famille (`#74808F` entre `#5E6978` et
`#8A95A4`, `#A1ABBB` entre `#8A95A4` et `#B8C1CE`) pour éviter les sauts de ton sur les
sprites qui n'avaient que trois ou quatre gris.

`bat_antenne` (V1) reste volontairement en slate V2 : c'est le tier bas.

### Clés dormantes du pack

`tile_i7_land_clair` (anneaux de coût de la foreuse), `bat_cryostat` (pas encore dans
`BUILDINGS`), `bat_refroidisseur` (idem), les sheets collisionneur, les émetteurs par
combinaison et la variante DC. Elles sont dans l'archive et dans le HTML, mais aucun code ne
les appelle encore.



---

## Journal du pack v3.2

Détail complet dans `MANIFEST.csv` (colonne `etat`).

### Nouveaux (41)

- **batiments** (4) : `bat_collisionneur_p1_actif`, `bat_collisionneur_p2_actif`, `bat_collisionneur_p3_actif`, `bat_cryostat`
- **logique** (35) : `logic_emetteur_dc_alpha`, `logic_emetteur_dc_alpha_on`, `logic_emetteur_dc_beta`, `logic_emetteur_dc_beta_on`, `logic_emetteur_dc_gamma`, `logic_emetteur_dc_gamma_on` … +29
- **machines** (1) : `cryostat`
- **terrain** (1) : `tile_i7_land_clair`

### Remplacés (79)

- **batiments** (35) : `bat_antenne_v2`, `bat_antenne_v2`, `bat_centrale_enrichissement_v2`, `bat_collisionneur`, `bat_collisionneur_p1`, `bat_collisionneur_p1_actif` … +29
- **items** (1) : `item_moteur_quantique`
- **logique** (15) : `logic_actionneur_e_0`, `logic_actionneur_e_1`, `logic_actionneur_n_0`, `logic_actionneur_n_1`, `logic_actionneur_o_0`, `logic_actionneur_o_1` … +9
- **machines** (4) : `centrale_enrichissement_v2`, `fonderie_or_v2`, `raffineur_silicium_v2`, `refroidisseur`
- **terrain** (24) : `tile_i6_collisionneur_0`, `tile_i6_collisionneur_1`, `tile_i6_collisionneur_2`, `tile_i6_collisionneur_3`, `tile_i6_collisionneur_4`, `tile_i6_collisionneur_5` … +18

### Supprimés (24)

- **logique** : `logic_bloc_alpha[_beta][_gamma]_<n|s|o|e>_<0|1>` — zéro référence dans le code, doublon de `logic_emetteur_*`.
