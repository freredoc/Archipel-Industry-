#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Animations manquantes
=========================================

VERIFICATION FAITE AVANT PRODUCTION
-----------------------------------
Le pack officiel contient un dossier anim/ de 179 sheets. Il ne fallait donc
surtout pas redessiner ce qui existe. Etat releve :

  four_arc_acier_sheet   OFFICIEL
  four_arc_cable_sheet   OFFICIEL
  four_arc_meca_sheet    OFFICIEL
  four_arc_fer_sheet     MANQUANT   <- demande
  four_arc_cuivre_sheet  MANQUANT   <- demande
  mine_*_v1/v2/v3_sheet  OFFICIELS (les 7 minerais)
  antenne_sheet          OFFICIEL
  usine_moteur_nucleaire_sheet OFFICIEL

DERIVATIONS (pas de redessin)
-----------------------------
  four_arc_fer    : four_arc_acier et four_arc_fer sont des sprites IDENTIQUES
                    (bijection verifiee, 0 couleur differente). Le sheet est
                    donc une copie exacte du sheet acier.
  four_arc_cuivre : palette-swap de 8 couleurs depuis acier, extrait des
                    sprites statiques (purete 95-100%). On applique le meme
                    swap aux 4 frames -> le rythme d'animation reste
                    exactement celui de la famille officielle.
  mine_*_v4       : recoloration SUPERIEUR du sheet v3 officiel. Comme le v4
                    statique est lui aussi recolor(v3), la frame 0 du sheet
                    coincide automatiquement avec le sprite statique.
  bat_antenne_v2  : recoloration V2 du sheet antenne officiel, meme logique.

ANIMATIONS NEUVES (aucun officiel a deriver)
--------------------------------------------
  bat_foreuse_<dir>            tete de forage qui tourne, orientee
  bat_stabilisateur_quantique  cristal en levitation qui pulse
  bat_usine_moteur_quantique   rotor torique qui tourne

INVARIANT : frame 0 == sprite statique exact. Verifie sur chaque sheet produit.
Les sheets officiels ne respectent pas toujours cet invariant ; quand on derive
d'un sheet officiel, on FORCE la frame 0 au sprite statique recolore.
"""
from PIL import Image
import numpy as np, os, sys

sys.path.insert(0, '.')
from gen_paliers import recolor, RAMP_V2, RAMP_SUP, load, hx

SRC, OUT, OANIM = 'sprites', 'out/sprites', 'out/anim'
OFF_ANIM = 'anim'
os.makedirs(OANIM, exist_ok=True)


def arr(p):
    return np.array(Image.open(p).convert('RGBA'))


def save_sheet(frames, name, fw=32):
    h = frames[0].shape[0]
    sheet = np.zeros((h, fw * len(frames), 4), np.uint8)
    for i, f in enumerate(frames):
        sheet[:, i * fw:(i + 1) * fw] = f
    Image.fromarray(sheet, 'RGBA').save(f'{OANIM}/{name}')
    return name


def split(sheet_path, fw=32):
    a = arr(sheet_path)
    n = a.shape[1] // fw
    return [a[:, i * fw:(i + 1) * fw].copy() for i in range(n)]


# ------------------------------------------------------------ four arc family
ARC_SWAP_CUIVRE = {
    hx('#6E7684'): hx('#846850'),
    hx('#48505E'): hx('#604834'),
    hx('#5D6470'): hx('#705844'),
    hx('#969EAC'): hx('#A68668'),
    hx('#585E69'): hx('#695340'),
    hx('#7D8696'): hx('#96765B'),
    hx('#96AAC8'): hx('#D7873C'),
    hx('#ACC3E5'): hx('#D7873C'),
}


def swap_palette(f, mapping):
    out = f.copy()
    for y in range(f.shape[0]):
        for x in range(f.shape[1]):
            if f[y, x, 3] == 0:
                continue
            c = tuple(int(v) for v in f[y, x][:3])
            if c in mapping:
                out[y, x, :3] = mapping[c]
    return out


def four_arc_anims():
    made = []
    frames = split(f'{OFF_ANIM}/four_arc_acier_sheet.png')
    # fer : sprite identique a acier -> copie exacte du sheet
    ff = [f.copy() for f in frames]
    ff[0] = arr(f'{SRC}/four_arc_fer.png')
    made.append(save_sheet(ff, 'four_arc_fer_sheet.png'))
    # cuivre : palette-swap des 4 frames
    cf = [swap_palette(f, ARC_SWAP_CUIVRE) for f in frames]
    cf[0] = arr(f'{SRC}/four_arc_cuivre.png')
    made.append(save_sheet(cf, 'four_arc_cuivre_sheet.png'))
    return made


# ---------------------------------------------------------------- mines v4
MINES = ['fer', 'cuivre', 'charbon', 'or', 'pierre', 'uranium', 'tungstene']


def mine_v4_anims():
    made = []
    for m in MINES:
        sp = f'{OFF_ANIM}/mine_{m}_v3_sheet.png'
        if not os.path.exists(sp):
            print(f'    (pas de sheet officiel pour mine_{m}_v3, saute)')
            continue
        frames = split(sp)
        rec = []
        for f in frames:
            g, _ = recolor(f, RAMP_SUP, 42, gain=1.12, lift=18.0)
            rec.append(g)
        # frame 0 forcee au statique v4 deja produit (invariant)
        rec[0] = arr(f'{OUT}/mine_{m}_v4.png')
        made.append(save_sheet(rec, f'mine_{m}_v4_sheet.png'))
    return made


def antenne_v2_anim():
    frames = split(f'{OFF_ANIM}/antenne_sheet.png')
    rec = []
    for f in frames:
        g, _ = recolor(f, RAMP_V2, 42, gain=1.0, lift=0.0)
        rec.append(g)
    rec[0] = arr(f'{OUT}/bat_antenne_v2.png')
    return [save_sheet(rec, 'bat_antenne_v2_sheet.png')]


# ------------------------------------------------------- animations neuves
L4 = hx('#C2CBD6')
L3 = hx('#A5A8B2')
GOLD, GOLDL = hx('#BEA046'), hx('#E8D07A')
VIO, VIOL, VIOD = hx('#B47CFF'), hx('#E0D0FF'), hx('#6E4AA8')
WHITE = hx('#FFFFFF')
SPARK = hx('#FFD166')


def px(f, x, y, c):
    if 0 <= x < f.shape[1] and 0 <= y < f.shape[0]:
        f[y, x] = (c[0], c[1], c[2], 255)


def foreuse_anims():
    """Filetage qui defile le long du mat (lecture "vis qui tourne") + etincelles.

    Premiere version : des chevrons positionnes par (k+i)%3 sur 3 rangees. Les
    motifs se recouvraient et les frames 1 et 3 ressortaient IDENTIQUES (0 px
    d'ecart) - donc un clignotement, pas une rotation.
    Version correcte : on parcourt toute la longueur du mat et on allume un
    pixel tous les 4, avec un decalage de phase de 1 par frame. Periode 4 =
    4 frames garanties distinctes, et le motif "monte" visiblement.
    """
    made = []
    # (axe, coord fixe, depart, fin, sens de la pointe)
    geo = {'n': ('v', 1, 11, -1), 's': ('v', 20, 30, +1),
           'o': ('h', 1, 11, -1), 'e': ('h', 20, 30, +1)}
    for d, (axis, a0, a1, tipdir) in geo.items():
        base = arr(f'{OUT}/bat_foreuse_{d}.png')
        frames = [base.copy() for _ in range(4)]
        for i in range(1, 4):
            f = frames[i]
            span = list(range(a0, a1 + 1))
            for n, p in enumerate(span):
                if (n + i) % 4 == 0:
                    if axis == 'v':
                        px(f, 15, p, L4); px(f, 16, p, L4)
                    else:
                        px(f, p, 15, L4); px(f, p, 16, L4)
                elif (n + i) % 4 == 2:
                    if axis == 'v':
                        px(f, 15, p, L3); px(f, 16, p, L3)
                    else:
                        px(f, p, 15, L3); px(f, p, 16, L3)
            # etincelles a la pointe, alternees
            tip = a0 - 1 if tipdir < 0 else a1 + 1
            if i % 2:
                if axis == 'v':
                    px(f, 13, tip + (1 if tipdir < 0 else -1), SPARK)
                    px(f, 18, tip + (1 if tipdir < 0 else -1), SPARK)
                else:
                    px(f, tip + (1 if tipdir < 0 else -1), 13, SPARK)
                    px(f, tip + (1 if tipdir < 0 else -1), 18, SPARK)
        made.append(save_sheet(frames, f'bat_foreuse_{d}_sheet.png'))
    return made


def stabilisateur_anim():
    """Cristal en levitation : respiration + halo de confinement qui tourne.

    Premiere version : halo indexe par (k+i)%8 avec k pair puis impair. Pour
    i=1 et i=3 l'ensemble des positions eclairees etait le MEME ({1,3,5,7}
    dans les deux cas) -> frames 1 et 3 identiques.
    Version correcte : un seul point vif qui avance d'un cran par frame, plus
    une traine de 2 points degressifs derriere. 8 positions, decalage 1 :
    4 frames forcement distinctes, et on lit le sens de rotation.
    """
    base = arr(f'{OUT}/bat_stabilisateur_quantique.png')
    frames = [base.copy() for _ in range(4)]
    ccx, ccy = 16, 16
    halo = [(0, -7), (5, -5), (7, 0), (5, 5), (0, 7), (-5, 5), (-7, 0), (-5, -5)]
    radii = [3, 4, 3, 2]          # 4 valeurs, la respiration ne se repete pas
    for i in range(1, 4):
        f = frames[i]
        r = radii[i]
        for y in range(ccy - 6, ccy + 7):
            for x in range(ccx - 6, ccx + 7):
                dd = abs(x - ccx) + abs(y - ccy)
                if dd <= r:
                    px(f, x, y, VIOL if (x + y) < ccx + ccy else VIO)
                elif dd == r + 1:
                    px(f, x, y, VIOD)
        px(f, ccx, ccy, WHITE)
        # tete vive + traine : avance d'un cran par frame
        for t, col in enumerate((VIOL, VIO, VIOD)):
            dx, dy = halo[(i * 2 - t) % 8]
            px(f, ccx + dx, ccy + dy, col)
    return [save_sheet(frames, 'bat_stabilisateur_quantique_sheet.png')]


def usine_moteur_quantique_anim():
    """Rotor torique qui tourne + bras qui descend poser l'element."""
    base = arr(f'{OUT}/bat_usine_moteur_quantique.png')
    frames = [base.copy() for _ in range(4)]
    rcx, rcy = 11, 18
    mag = [(0, -6), (4, -4), (6, 0), (4, 4), (0, 6), (-4, 4), (-6, 0), (-4, -4)]
    for i in range(1, 4):
        f = frames[i]
        # aimants du rotor qui avancent
        for k in range(0, 8, 2):
            dx, dy = mag[(k + i * 2) % 8]
            px(f, rcx + dx, rcy + dy, L3)
        for k in range(1, 8, 2):
            dx, dy = mag[(k + i * 2) % 8]
            px(f, rcx + dx, rcy + dy, VIO)
        px(f, rcx, rcy, VIOL if i % 2 else WHITE)
        # bras : l'element moteur descend vers la chaine
        ey = 16 + i
        for yy in range(16, 19):
            for xx in range(21, 24):
                px(f, xx, yy, tuple(base[yy, xx][:3]))
        for yy in range(ey, min(ey + 3, 22)):
            for xx in range(21, 24):
                px(f, xx, yy, GOLD)
        px(f, 22, min(ey + 1, 21), GOLDL)
    return [save_sheet(frames, 'bat_usine_moteur_quantique_sheet.png')]


# ------------------------------------------------------ collisionneur p0..p3
def fix_collisionneur():
    """Le code lit bat_collisionneur pour l'etat FINAL et _p1/_p2 pour les
    intermediaires ; il n'y a pas de cle _p3. Dans le build, _p1 et _p2 sont
    des COPIES de bat_collisionneur (4039 px les trois) : aucune progression
    visuelle n'est donc visible en jeu.

    On aligne : bat_collisionneur recoit le contenu du p3 (le plus equipe), et
    bat_collisionneur_p3 reste comme alias.
    """
    p3 = arr(f'{OUT}/bat_collisionneur_p3.png')
    Image.fromarray(p3, 'RGBA').save(f'{OUT}/bat_collisionneur.png')
    seq = ['bat_collisionneur_ruine', 'bat_collisionneur_p1',
           'bat_collisionneur_p2', 'bat_collisionneur']
    return [(k, int((arr(f'{OUT}/{k}.png')[:, :, 3] > 0).sum())) for k in seq]


if __name__ == '__main__':
    print('=== four arc (derives de l\'officiel acier) ===')
    for m in four_arc_anims():
        print('  ', m)
    print('=== mines v4 (recolor SUPERIEUR des sheets v3 officiels) ===')
    for m in mine_v4_anims():
        print('  ', m)
    print('=== antenne v2 (recolor V2 du sheet officiel) ===')
    for m in antenne_v2_anim():
        print('  ', m)
    print('=== animations neuves ===')
    for m in foreuse_anims() + stabilisateur_anim() + usine_moteur_quantique_anim():
        print('  ', m)
    print('=== collisionneur p0..p3 ===')
    for k, n in fix_collisionneur():
        print(f'   {k:28s} {n} px')
