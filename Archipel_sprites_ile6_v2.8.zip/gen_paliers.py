#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Moteur de paliers visuels (V2 + coloris SUPERIEUR)
=====================================================================

DEUX LANGAGES D'UPGRADE, decodes sur le pack officiel
----------------------------------------------------
Le jeu a DEUX conventions distinctes, il ne faut pas les confondre :

  A) BATIMENTS v1 -> v2 : RECOLORATION.
     Les gris neutres glissent vers un bleu-acier, les couleurs signature ne
     bougent pas, + un lisere orange #FF9628 sur UNE rangee pleine largeur,
     + 6-8 px de cyan #4FC3F7. Le masque peut rester identique
     (betonniere, cimenterie, centrale_charbon) ou grossir un peu
     (four_fer 354->541, pompe_eau 432->512).

  B) MINES v1 -> v2 -> v3 : CROISSANCE STRUCTURELLE PURE.
     Verifie sur mine_fer/cuivre/charbon : 224 -> 348 -> 470 px, soit
     +124 px a chaque palier, et la PALETTE NE CHANGE PAS (v3 n'ajoute
     aucune couleur par rapport a v2). Le corps s'elargit de 2 px par cote
     (16 -> 20 -> 24 px de large), la cheminee monte, le puits s'allonge.

POURQUOI UN "COLORIS SUPERIEUR" EST NECESSAIRE POUR LE V4
--------------------------------------------------------
La mine v3 occupe deja y=0..28 et x=4..27. Un v4 qui continuerait la
croissance (+2 px par cote) sortirait de la tuile 32x32. La croissance
structurelle est donc ARRIVEE EN BUTEE.

Le palier 4 change donc de MATIERE au lieu de changer de taille : c'est
exactement le role du "coloris superieur". Convention retenue :

     V1  materiaux bruts (brun, gris naturel)
     V2  slate-steel  + trim ORANGE  + accent CYAN
     V3  slate-steel, structure plus grande (meme palette que V2)
     V4  TUNGSTENE POLI + trim OR + accent VIOLET      <-- "superieur"

Verification anti-collision faite sur les 500+ sprites officiels :
     #B47CFF violet   0 px      -> libre
     #C2CBD6 tungstene 0 px     -> libre
     #E8D07A or clair  0 px     -> libre
     #BEA046 or       39 px / 1 fichier -> quasi libre
     (#FF9628 orange 202 px / 17 fichiers et #4FC3F7 cyan 22 px / 3 fichiers
      sont bien les marqueurs V2 deja en service)

Le coloris superieur est donc lisible comme "au-dessus du V2" sans jamais
entrer en conflit avec un marqueur existant. L'or est le signal d'upgrade le
plus universellement lu, et le violet est deja l'accent de l'endgame (ile 6 :
collisionneur, data center, matiere exotique).
"""
from PIL import Image
import numpy as np, os

SRC = 'sprites'
OUT = 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def arr(path):
    return np.array(Image.open(path).convert('RGBA'))


def load(name):
    for d in (OUT, SRC):
        p = f'{d}/{name}.png'
        if os.path.exists(p):
            return arr(p)
    raise FileNotFoundError(name)


OUTL = hx('#161A22')
ORA, ORAD = hx('#FF9628'), hx('#C46A12')
CYAN, CYANL, CYAND = hx('#4FC3F7'), hx('#BFEFFF'), hx('#2A7FA8')
GOLD, GOLDL, GOLDD = hx('#BEA046'), hx('#E8D07A'), hx('#8A7028')
VIO, VIOL, VIOD = hx('#B47CFF'), hx('#E0D0FF'), hx('#6E4AA8')
WHITE = hx('#FFFFFF')

# --- rampes de destination, du plus sombre au plus clair ---------------------
# V2 : slate-steel. Rampe relevee sur les V2 officielles.
RAMP_V2 = [hx('#1E2430'), hx('#262E3A'), hx('#2A3240'), hx('#36404E'),
           hx('#3C4654'), hx('#444A56'), hx('#566272'), hx('#686E7A'),
           hx('#788596'), hx('#9096A2'), hx('#9EAAB9'), hx('#B4BECC')]

# SUPERIEUR : tungstene poli. Plus clair et plus froid que le slate, avec un
# haut de rampe presque blanc -> lecture "metal polie" plutot que "acier brut".
RAMP_SUP = [hx('#232830'), hx('#2C323C'), hx('#343B47'), hx('#404955'),
            hx('#4E5866'), hx('#5E6978'), hx('#727E8E'), hx('#8A95A4'),
            hx('#A2ACBA'), hx('#B8C1CE'), hx('#C2CBD6'), hx('#DCE3EC')]

# Couleurs jamais touchees : le contour + tout ce qui est "signature".
# Regle decodee sur betonniere_v2 : seuls les gris NEUTRES bougent. On detecte
# donc la neutralite par la saturation, ce qui est plus robuste qu'une liste.
KEEP_ALWAYS = {OUTL}


def is_neutral(c, sat_max=42):
    """Un gris neutre a un ecart max-min faible entre ses canaux.

    betonniere : #929496 (ecart 4) -> recolore
                 #78B4C8 (ecart 80) -> preserve  (signature)
                 #967846 (ecart 80) -> preserve  (bois)
    Le seuil de 42 laisse passer les gris legerement bleutes du pack
    (#585E6C, ecart 20) tout en protegeant les vraies couleurs.
    """
    return (max(c) - min(c)) <= sat_max


def recolor(a, ramp, sat_max=42, keep=(), gain=1.0, lift=0.0):
    """Remappe les gris neutres sur 'ramp' EN PRESERVANT LEUR LUMINANCE.

    Premiere version (abandonnee) : je repartissais les gris par RANG sur la
    rampe. Erreur — ca normalise chaque sprite pour qu'il occupe toute la
    rampe, donc un batiment clair devenait moyen. Constate sur mine_fer_v4 :
    86 de luminance contre 98 pour son v3, alors que le coloris superieur doit
    etre PLUS clair (metal poli).

    Version correcte : chaque gris est mappe sur l'entree de rampe dont la
    luminance est la plus proche de sa luminance cible. Le modele d'ombrage et
    la clarte generale du sprite d'origine sont donc conserves.

    gain/lift permettent de decaler volontairement la clarte :
        V2         gain=1.00 lift=0    (meme clarte, teinte plus froide)
        SUPERIEUR  gain=1.12 lift=18   (plus clair = poli)
    """
    out = a.copy()
    keepset = set(KEEP_ALWAYS) | set(keep)
    ramp_lum = [sum(c) / 3.0 for c in ramp]

    mapping = {}
    for y in range(a.shape[0]):
        for x in range(a.shape[1]):
            if a[y, x, 3] == 0:
                continue
            c = tuple(int(v) for v in a[y, x][:3])
            if c in keepset or not is_neutral(c, sat_max) or c in mapping:
                continue
            target = min(255.0, (sum(c) / 3.0) * gain + lift)
            j = min(range(len(ramp)), key=lambda k: abs(ramp_lum[k] - target))
            mapping[c] = ramp[j]

    for y in range(a.shape[0]):
        for x in range(a.shape[1]):
            if a[y, x, 3] == 0:
                continue
            c = tuple(int(v) for v in a[y, x][:3])
            if c in mapping:
                out[y, x, :3] = mapping[c]
    return out, mapping


# ---------------------------------------------------------------- marqueurs
def body_rows(a):
    """Rangees du corps principal (celles qui sont larges et pleines).
    Sert a poser le trim sur une rangee uniforme, pas au milieu d'un detail."""
    rows = []
    for y in range(a.shape[0]):
        op = int((a[y, :, 3] > 0).sum())
        if op >= a.shape[1] * 0.55:
            uniq = len(set(tuple(int(v) for v in a[y, x][:3])
                           for x in range(a.shape[1]) if a[y, x, 3] > 0))
            rows.append((y, op, uniq))
    return rows


def paintable(a, y):
    """Pixels d'une rangee qu'on peut repeindre (opaques, hors contour)."""
    return [x for x in range(a.shape[1])
            if a[y, x, 3] > 0 and tuple(int(v) for v in a[y, x][:3]) != OUTL]


def add_trim(a, col=ORA, cold=ORAD, prefer='top'):
    """Pose un lisere sur la rangee de corps la plus UNIFORME.

    Convention officielle : betonniere_v2 = 22 px sur une rangee,
    cimenterie_v2 = 20 px. MAIS pompe_eau_v2 n'a que 5 px sur 2 rangees :
    les batiments fins recoivent un petit lisere, pas une bande.

    Deux pieges rencontres et corriges :
      - une rangee peut etre "large" tout en n'etant que du CONTOUR (mine v3
        y=4 : 22 px opaques mais 1 seul repeignable) -> on exige au moins
        10 px repeignables avant de choisir.
      - un batiment fin (antenne : aucune rangee ne fait 55% de la largeur)
        n'a aucune rangee candidate -> repli sur la rangee la plus large
        disponible, avec un lisere court a la pompe_eau_v2.
    """
    h = a.shape[0]
    rows = [(y, op, uniq) for (y, op, uniq) in body_rows(a)
            if len(paintable(a, y)) >= 10]
    if rows:
        if prefer == 'top':
            cand = [r for r in rows if h * 0.15 <= r[0] <= h * 0.55] or rows
        else:
            cand = [r for r in rows if h * 0.45 <= r[0] <= h * 0.85] or rows
        y = min(cand, key=lambda r: (r[2], -r[1]))[0]
        xs = paintable(a, y)
        for x in xs[1:-1]:
            a[y, x, :3] = col
        a[y, xs[0], :3] = cold
        a[y, xs[-1], :3] = cold
        return a

    # --- repli batiment fin : lisere court, facon pompe_eau_v2 (5 px)
    best, bestn = None, 0
    for y in range(h):
        n = len(paintable(a, y))
        if n > bestn:
            best, bestn = y, n
    if best is None or bestn < 3:
        return a
    xs = paintable(a, best)
    mid = len(xs) // 2
    for x in xs[max(0, mid - 2):mid + 3]:
        a[best, x, :3] = col
    return a


def add_accent(a, col, coll, n=8):
    """Sème n px d'accent sur des pixels de corps clairs, repartis.
    Les V2 officielles restent a 6-8 px d'accent : on respecte ce budget."""
    h, w = a.shape[:2]
    lum = a[:, :, :3].astype(int).sum(axis=2)
    cands = [(y, x) for y in range(int(h * 0.2), int(h * 0.8))
             for x in range(int(w * 0.15), int(w * 0.85))
             if a[y, x, 3] > 0 and tuple(int(v) for v in a[y, x][:3]) != OUTL
             and lum[y, x] > 300]
    if not cands:
        return a
    step = max(1, len(cands) // n)
    for k in range(0, min(len(cands), step * n), step):
        y, x = cands[k]
        a[y, x, :3] = col
        if x + 1 < w and a[y, x + 1, 3] > 0 and tuple(int(v) for v in a[y, x + 1][:3]) != OUTL:
            a[y, x + 1, :3] = coll
    return a


def make_v2(src_name, out_name, sat_max=42, prefer='top'):
    """v1 -> v2 : slate + trim orange + accent cyan."""
    a = load(src_name)
    b, _ = recolor(a, RAMP_V2, sat_max, gain=1.0, lift=0.0)
    b = add_trim(b, ORA, ORAD, prefer)
    b = add_accent(b, CYAN, CYANL, 8)
    Image.fromarray(b, 'RGBA').save(f'{OUT}/{out_name}.png')
    return out_name, int((b[:, :, 3] > 0).sum())


def make_superieur(src_name, out_name, sat_max=42, prefer='top'):
    """-> coloris SUPERIEUR : tungstene poli + trim or + accent violet.

    ORDRE IMPORTANT : la brillance passe AVANT le trim. Elle repeint le premier
    pixel visible de chaque colonne, donc si elle passait apres elle effacerait
    le lisere dore (constate : 22 px d'or reduits a 1 px sur les mines, dont la
    rangee de trim est aussi la premiere rangee peignable).
    """
    a = load(src_name)
    b, _ = recolor(a, RAMP_SUP, sat_max, gain=1.12, lift=18.0)
    # 1. lisere de brillance : 1 px clair sur l'arete superieure du corps
    h, w = b.shape[:2]
    for x in range(w):
        for y in range(h):
            if b[y, x, 3] > 0 and tuple(int(v) for v in b[y, x][:3]) != OUTL:
                if y + 1 < h and b[y + 1, x, 3] > 0:
                    b[y, x, :3] = hx('#DCE3EC')
                break
    # 2. puis le trim dore, qui doit rester visible
    b = add_trim(b, GOLD, GOLDD, prefer)
    # 3. accent violet
    b = add_accent(b, VIO, VIOL, 8)
    Image.fromarray(b, 'RGBA').save(f'{OUT}/{out_name}.png')
    return out_name, int((b[:, :, 3] > 0).sum())


# ============================================================ LISTE DEMANDEE
# VERIFIE DANS LE BUILD (Alpha 13.88) avant de produire : la chaine nucleaire V2
# et les V2 silicium/processeur/or EXISTENT DEJA, sprites ET animations
# (bat_broyeur_uranium_v2, bat_centrale_enrichissement_v2, bat_centrale_nucleaire_v2,
#  bat_raffineur_silicium_v2, bat_fab_processeur_v2, bat_fonderie_or_v2,
#  bat_usine_moteur_nuc_v2). Elles sont plus riches que ce que ce script produit
# mecaniquement (52 couleurs contre 22 sur la centrale nucleaire, et des ajouts
# structurels : fonderie_or 551 -> 570 px). Les regenerer serait une REGRESSION.
# Seule bat_antenne_v2 manque reellement.
V2_JOBS = [
    ('bat_antenne', 'bat_antenne_v2', 'bottom'),
]

MINES = ['fer', 'cuivre', 'charbon', 'or', 'pierre', 'uranium', 'tungstene']

if __name__ == '__main__':
    print('=== V2 (slate + trim orange + accent cyan) ===')
    for s, o, pref in V2_JOBS:
        n, px = make_v2(s, o, prefer=pref)
        base = load(s)
        print(f'  {s:32s} -> {n:34s} {int((base[:,:,3]>0).sum()):4d} -> {px:4d} px')

    print('\n=== MINE V4 : coloris SUPERIEUR sur la silhouette v3 ===')
    for m in MINES:
        src = f'mine_{m}_v3'
        try:
            n, px = make_superieur(src, f'mine_{m}_v4')
            print(f'  {src:24s} -> {n:22s} {px:4d} px')
        except FileNotFoundError:
            print(f'  {src:24s} ABSENT, saute')
