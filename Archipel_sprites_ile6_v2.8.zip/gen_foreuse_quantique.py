#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARCHIPEL INDUSTRY - Foreuse 4 sens + 2 batiments quantiques
===========================================================

FOREUSE 4 SENS
--------------
La foreuse v1 a un mat vertical (y=1..12) plante sur un corps (y=13..28), donc
elle ne "regarde" que vers le nord. Pour l'orienter, deux options :

  - faire tourner le sprite entier de 90 deg : rapide, mais l'eclairage part
    avec, et le pack eclaire TOUJOURS par le haut-gauche. Un sprite tourne
    aurait son ombre en haut a gauche -> incoherent avec tous les voisins.
  - reconstruire avec la direction en parametre : le corps garde son eclairage
    haut-gauche, seul le mat de forage se deplace.

C'est la seconde qui est retenue. Palette reprise telle quelle de bat_foreuse
(#161A22 contour, slate #2A303C..#A5A8B2, trim #FF9628, cyan #4FC3F7).

STABILISATEUR QUANTIQUE (nouveau)
---------------------------------
Role suppose : stabiliser l'information quantique (eviter la decoherence).
Traduction visuelle : une cage de confinement avec un cristal en levitation au
centre et 4 emetteurs de champ aux angles. Le "tell" est la LEVITATION - rien
ne touche le cristal, ce qui dit "on maintient un etat fragile".
Accent violet #B47CFF (langage quantique de l'ile 6).

USINE MOTEUR QUANTIQUE (nouveau)
--------------------------------
Pendant quantique de bat_usine_moteur_nucleaire. Traduction : une chaine de
montage avec un rotor a champ, et un bras qui pose l'element moteur. Le "tell"
est le ROTOR TORIQUE violet, qui reprend la forme de l'anneau du collisionneur
pour dire "meme technologie".
"""
from PIL import Image
import numpy as np, os

SRC, OUT = 'sprites', 'out/sprites'
os.makedirs(OUT, exist_ok=True)


def hx(s):
    s = s.lstrip('#')
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


OUTL = hx('#161A22')
D0, D1, D2 = hx('#1E222C'), hx('#2A303C'), hx('#404652')
M1, M2 = hx('#4E525C'), hx('#646B78')
L1, L2, L3 = hx('#787C86'), hx('#8C93A0'), hx('#A5A8B2')
L4 = hx('#C2CBD6')
ORA, ORAD = hx('#FF9628'), hx('#C46A12')
CYAN, CYANL, CYAND = hx('#4FC3F7'), hx('#BFEFFF'), hx('#2A7FA8')
VIO, VIOL, VIOD = hx('#B47CFF'), hx('#E0D0FF'), hx('#6E4AA8')
GOLD = hx('#BEA046')
WHITE = hx('#FFFFFF')
RUST = hx('#4C423A')


class Cv:
    def __init__(s, w=32, h=32):
        s.w, s.h = w, h
        s.a = np.zeros((h, w, 4), np.uint8)

    def px(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h:
            s.a[y, x] = c

    def rect(s, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                s.px(x, y, c)

    def hline(s, x0, x1, y, c):
        for x in range(x0, x1 + 1):
            s.px(x, y, c)

    def vline(s, x, y0, y1, c):
        for y in range(y0, y1 + 1):
            s.px(x, y, c)

    def frame(s, x0, y0, x1, y1, c):
        s.hline(x0, x1, y0, c); s.hline(x0, x1, y1, c)
        s.vline(x0, y0, y1, c); s.vline(x1, y0, y1, c)

    def box(s, x0, y0, x1, y1, body=M2, light=L2, shade=D2):
        s.rect(x0, y0, x1, y1, body)
        s.frame(x0, y0, x1, y1, OUTL)
        s.hline(x0 + 1, x1 - 1, y0 + 1, light)
        s.vline(x0 + 1, y0 + 1, y1 - 1, light)
        s.hline(x0 + 1, x1 - 1, y1 - 1, shade)
        s.vline(x1 - 1, y0 + 1, y1 - 1, shade)

    def disc(s, cx, cy, r, c):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r // 2:
                    s.px(x, y, c)

    def ring(s, cx, cy, r0, r1, c):
        R = int(r1) + 2
        for y in range(cy - R, cy + R + 1):
            for x in range(cx - R, cx + R + 1):
                d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if r0 <= d <= r1:
                    s.px(x, y, c)

    def save(s, name):
        Image.fromarray(s.a, 'RGBA').save(os.path.join(OUT, name))
        return name


# ================================================================== FOREUSE
def foreuse(side='n'):
    """Foreuse orientable. Le corps garde son eclairage haut-gauche ; seul le
    mat de forage se deplace vers 'side'.

    Le socle est CENTRE et COMPACT (x/y 8..23, soit 16x16). Premiere version :
    un socle de 26 px de large (x=3..28) sur 17 de haut - resultat, le mat
    horizontal etait entierement noyé dedans et ne depassait que de 1 px. Avec
    un socle carre centre, les 4 directions ont la meme marge de 8 px.
    """
    c = Cv()
    B0, B1 = 8, 23          # socle carre centre

    # --- mat de forage EN PREMIER, il passera sous le socle
    def mast_v(y0, y1, tipdir):
        c.rect(14, y0, 17, y1, M2)
        c.frame(14, y0, 17, y1, OUTL)
        c.vline(15, y0 + 1, y1 - 1, L2)
        c.vline(16, y0 + 1, y1 - 1, D2)
        ty = y0 if tipdir < 0 else y1
        c.rect(13, ty if tipdir > 0 else ty, 18, ty + (1 if tipdir > 0 else 0), D2)
        c.frame(13, min(ty, ty + tipdir), 18, max(ty, ty + tipdir), OUTL)
        tip = ty + tipdir * 2
        c.px(15, tip, L4); c.px(16, tip, L4)
        c.px(15, tip + tipdir, L3); c.px(16, tip + tipdir, L3)

    def mast_h(x0, x1, tipdir):
        c.rect(x0, 14, x1, 17, M2)
        c.frame(x0, 14, x1, 17, OUTL)
        c.hline(x0 + 1, x1 - 1, 15, L2)
        c.hline(x0 + 1, x1 - 1, 16, D2)
        tx = x0 if tipdir < 0 else x1
        c.rect(tx, 13, tx + (1 if tipdir > 0 else 0), 18, D2)
        c.frame(min(tx, tx + tipdir), 13, max(tx, tx + tipdir), 18, OUTL)
        tip = tx + tipdir * 2
        c.px(tip, 15, L4); c.px(tip, 16, L4)
        c.px(tip + tipdir, 15, L3); c.px(tip + tipdir, 16, L3)

    if side == 'n':
        mast_v(1, B0 + 3, -1)
    elif side == 's':
        mast_v(B1 - 3, 30, +1)
    elif side == 'o':
        mast_h(1, B0 + 3, -1)
    else:
        mast_h(B1 - 3, 30, +1)

    # --- socle par-dessus, eclairage toujours haut-gauche
    c.box(B0, B0, B1, B1, M2, L2, D2)
    c.rect(B0 + 2, B0 + 3, B1 - 2, B1 - 2, D1)
    c.frame(B0 + 2, B0 + 3, B1 - 2, B1 - 2, D0)
    # rails
    for x in range(B0 + 4, B1 - 2, 4):
        c.vline(x, B0 + 4, B1 - 3, D2)
    # trim V2 + voyants
    c.hline(B0 + 1, B1 - 1, B0 + 1, ORA)
    c.px(B0 + 2, B0 + 2, CYAN); c.px(B0 + 5, B0 + 2, CYAN)
    c.px(B1 - 2, B0 + 2, ORA)
    # tourelle de tete de forage au centre : dit d'ou sort le mat
    c.rect(14, 14, 17, 17, M1)
    c.frame(14, 14, 17, 17, OUTL)
    c.px(15, 15, L3); c.px(16, 16, D0)
    # pieds
    for x in (B0 + 1, 15, B1 - 2):
        c.rect(x, B1 + 1, x + 1, B1 + 2, D0)
    return c


# ==================================================== STABILISATEUR QUANTIQUE
def stabilisateur_quantique():
    """Cage de confinement + cristal en LEVITATION (rien ne le touche) +
    4 emetteurs de champ. La levitation est le tell : on maintient un etat
    fragile."""
    c = Cv()
    # socle
    c.box(2, 22, 29, 29, M2, L2, D2)
    c.rect(4, 24, 27, 27, D1)
    c.hline(3, 28, 23, ORA)
    for x in (4, 15, 26):
        c.rect(x, 30, x + 1, 31, D0)

    # 4 colonnes emettrices
    for cx in (5, 26):
        c.box(cx - 2, 6, cx + 2, 22, M1, L1, D0)
        c.rect(cx - 1, 8, cx + 1, 20, D0)
        for y in range(9, 20, 3):
            c.hline(cx - 1, cx + 1, y, VIOD)
        c.px(cx, 7, VIO)
    # traverse haute
    c.box(3, 3, 28, 8, M2, L2, D2)
    c.rect(5, 5, 26, 6, D1)
    c.hline(4, 27, 4, ORA)
    # bobines de champ sous la traverse
    for cx in (11, 16, 21):
        c.rect(cx - 1, 8, cx + 1, 10, D2)
        c.px(cx, 10, VIO)

    # --- CRISTAL EN LEVITATION : aucun pixel de structure ne le touche
    ccx, ccy = 16, 16
    for y in range(ccy - 5, ccy + 6):
        for x in range(ccx - 5, ccx + 6):
            d = abs(x - ccx) + abs(y - ccy)          # losange
            if d <= 3:
                c.px(x, y, VIOL if (x + y) < ccx + ccy else VIO)
            elif d == 4:
                c.px(x, y, VIOD)
    c.px(ccx, ccy, WHITE)
    c.px(ccx - 1, ccy - 1, WHITE)
    # halo de confinement : pointilles, pour lire "champ" et pas "structure"
    for (dx, dy) in [(0, -7), (0, 7), (-7, 0), (7, 0), (-5, -5), (5, -5), (-5, 5), (5, 5)]:
        c.px(ccx + dx, ccy + dy, VIO)
    for (dx, dy) in [(0, -6), (0, 6), (-6, 0), (6, 0)]:
        c.px(ccx + dx, ccy + dy, VIOD)
    return c


# ==================================================== USINE MOTEUR QUANTIQUE
def usine_moteur_quantique():
    """Pendant quantique de l'usine moteur nucleaire. Le tell est le ROTOR
    TORIQUE violet, qui reprend l'anneau du collisionneur : meme techno."""
    c = Cv()
    # halle
    c.box(1, 8, 30, 27, M2, L2, D2)
    c.hline(2, 29, 9, ORA)
    c.rect(3, 11, 28, 25, D1)
    c.frame(3, 11, 28, 25, D0)
    # toiture en sheds
    for x in range(3, 29, 6):
        c.px(x, 7, L2); c.px(x + 1, 6, L2); c.px(x + 2, 6, L3)
        c.px(x + 3, 7, D2)
    c.hline(1, 30, 8, OUTL)
    # socle
    c.rect(1, 27, 30, 29, D0)
    for x in (3, 15, 27):
        c.rect(x, 30, x + 1, 31, D0)

    # --- ROTOR TORIQUE (le tell)
    c.ring(11, 18, 4.2, 6.2, D2)
    c.ring(11, 18, 5.0, 5.6, VIOD)
    c.ring(11, 18, 2.4, 3.4, VIO)
    c.disc(11, 18, 2, VIOD)
    c.px(11, 18, VIOL)
    # aimants du rotor
    for (dx, dy) in [(0, -6), (0, 6), (-6, 0), (6, 0)]:
        c.px(11 + dx, 18 + dy, L3)

    # --- chaine de montage + bras
    # La chaine doit trancher sur le fond interieur : on la borde en sombre et
    # on pose des taquets clairs, sinon elle se confond avec le remplissage.
    c.rect(18, 20, 27, 23, D2)
    c.frame(18, 20, 27, 23, OUTL)
    c.hline(19, 26, 21, M2)
    for x in range(19, 27, 3):
        c.px(x, 22, L3)
    # bras qui pose l'element moteur
    c.vline(22, 12, 15, M2)
    c.px(21, 12, L2); c.px(23, 12, D2)
    c.rect(20, 11, 24, 12, M1)
    c.frame(20, 11, 24, 12, OUTL)
    # element moteur en cours de pose : 4x4 pour rester lisible.
    # Premiere version : un rect 3x3 + frame -> le cadre mangeait tout sauf le
    # pixel central, l'element etait invisible.
    c.rect(20, 16, 23, 19, GOLD)
    c.hline(21, 22, 16, hx('#E8D07A'))
    c.px(20, 19, hx('#8A7028')); c.px(23, 19, hx('#8A7028'))
    c.frame(19, 15, 24, 20, D0)
    # voyants
    c.px(5, 10, CYAN); c.px(8, 10, VIO); c.px(26, 10, GOLD)
    return c


DIRS = ['n', 'e', 's', 'o']

if __name__ == '__main__':
    made = []
    for d in DIRS:
        made.append(foreuse(d).save(f'bat_foreuse_{d}.png'))
    # la version sans suffixe reste la foreuse nord (compat clef existante)
    made.append(foreuse('n').save('bat_foreuse.png'))
    made.append(stabilisateur_quantique().save('bat_stabilisateur_quantique.png'))
    made.append(usine_moteur_quantique().save('bat_usine_moteur_quantique.png'))

    from PIL import Image as I
    for m in made:
        a = np.array(I.open(f'{OUT}/{m}').convert('RGBA'))
        print(f'  {m:34s} px={int((a[:,:,3]>0).sum()):4d} '
              f'cols={len(set(map(tuple,a[a[:,:,3]>0])))}')
